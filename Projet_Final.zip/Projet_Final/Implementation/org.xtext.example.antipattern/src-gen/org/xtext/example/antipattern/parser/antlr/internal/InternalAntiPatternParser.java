package org.xtext.example.antipattern.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.antipattern.services.AntiPatternGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalAntiPatternParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Prompt'", "'{'", "'}'", "'nbExemples:'", "'Domain:'", "'Classes:'", "'class:'", "'Method_In'", "'conditions:'", "'('", "','", "')'", "'UNION'", "'manners'", "'violates'", "'LOC'", "'CYC'", "'NOP'", "'DEPTHNESTING'", "'COH'", "'EQUAL'", "'LESS'", "'LESS_EQUAL'", "'GREATER'", "'GREATER_EQUAL'", "'NAMING_CONVENTION'", "'Consistent_Parameter_Naming'", "'Single_Responsibility_Principle'", "'Use_of_Comments'", "'Avoid_Magic_Numbers'", "'many'", "'few'", "'Complex_Logical_Expressions'", "'ifNestedStructures'", "'switchNestedStructures'", "'loopNestedStructures'", "'ExecutableStatments'", "'Declare_Variables_Separately'", "'Add_Comments'", "'Exception_Handling'", "'Use_Recursion'", "'Use_Global_Variables'", "'unrelatedFonctionnalities'", "'ATTRIBUTE_USE'", "'method'", "'otherClass'", "'ownClass'", "'/'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalAntiPatternParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalAntiPatternParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalAntiPatternParser.tokenNames; }
    public String getGrammarFileName() { return "InternalAntiPattern.g"; }



     	private AntiPatternGrammarAccess grammarAccess;

        public InternalAntiPatternParser(TokenStream input, AntiPatternGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected AntiPatternGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalAntiPattern.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalAntiPattern.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalAntiPattern.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalAntiPattern.g:71:1: ruleModel returns [EObject current=null] : ( (lv_prompts_0_0= rulePrompt ) )* ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_prompts_0_0 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:77:2: ( ( (lv_prompts_0_0= rulePrompt ) )* )
            // InternalAntiPattern.g:78:2: ( (lv_prompts_0_0= rulePrompt ) )*
            {
            // InternalAntiPattern.g:78:2: ( (lv_prompts_0_0= rulePrompt ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalAntiPattern.g:79:3: (lv_prompts_0_0= rulePrompt )
            	    {
            	    // InternalAntiPattern.g:79:3: (lv_prompts_0_0= rulePrompt )
            	    // InternalAntiPattern.g:80:4: lv_prompts_0_0= rulePrompt
            	    {

            	    				newCompositeNode(grammarAccess.getModelAccess().getPromptsPromptParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_prompts_0_0=rulePrompt();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getModelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"prompts",
            	    					lv_prompts_0_0,
            	    					"org.xtext.example.antipattern.AntiPattern.Prompt");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRulePrompt"
    // InternalAntiPattern.g:100:1: entryRulePrompt returns [EObject current=null] : iv_rulePrompt= rulePrompt EOF ;
    public final EObject entryRulePrompt() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrompt = null;


        try {
            // InternalAntiPattern.g:100:47: (iv_rulePrompt= rulePrompt EOF )
            // InternalAntiPattern.g:101:2: iv_rulePrompt= rulePrompt EOF
            {
             newCompositeNode(grammarAccess.getPromptRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrompt=rulePrompt();

            state._fsp--;

             current =iv_rulePrompt; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrompt"


    // $ANTLR start "rulePrompt"
    // InternalAntiPattern.g:107:1: rulePrompt returns [EObject current=null] : (otherlv_0= 'Prompt' otherlv_1= '{' ( (lv_content_2_0= ruleContentPrompt ) ) otherlv_3= '}' ) ;
    public final EObject rulePrompt() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_content_2_0 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:113:2: ( (otherlv_0= 'Prompt' otherlv_1= '{' ( (lv_content_2_0= ruleContentPrompt ) ) otherlv_3= '}' ) )
            // InternalAntiPattern.g:114:2: (otherlv_0= 'Prompt' otherlv_1= '{' ( (lv_content_2_0= ruleContentPrompt ) ) otherlv_3= '}' )
            {
            // InternalAntiPattern.g:114:2: (otherlv_0= 'Prompt' otherlv_1= '{' ( (lv_content_2_0= ruleContentPrompt ) ) otherlv_3= '}' )
            // InternalAntiPattern.g:115:3: otherlv_0= 'Prompt' otherlv_1= '{' ( (lv_content_2_0= ruleContentPrompt ) ) otherlv_3= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getPromptAccess().getPromptKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getPromptAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalAntiPattern.g:123:3: ( (lv_content_2_0= ruleContentPrompt ) )
            // InternalAntiPattern.g:124:4: (lv_content_2_0= ruleContentPrompt )
            {
            // InternalAntiPattern.g:124:4: (lv_content_2_0= ruleContentPrompt )
            // InternalAntiPattern.g:125:5: lv_content_2_0= ruleContentPrompt
            {

            					newCompositeNode(grammarAccess.getPromptAccess().getContentContentPromptParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_6);
            lv_content_2_0=ruleContentPrompt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPromptRule());
            					}
            					set(
            						current,
            						"content",
            						lv_content_2_0,
            						"org.xtext.example.antipattern.AntiPattern.ContentPrompt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getPromptAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrompt"


    // $ANTLR start "entryRuleContentPrompt"
    // InternalAntiPattern.g:150:1: entryRuleContentPrompt returns [EObject current=null] : iv_ruleContentPrompt= ruleContentPrompt EOF ;
    public final EObject entryRuleContentPrompt() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContentPrompt = null;


        try {
            // InternalAntiPattern.g:150:54: (iv_ruleContentPrompt= ruleContentPrompt EOF )
            // InternalAntiPattern.g:151:2: iv_ruleContentPrompt= ruleContentPrompt EOF
            {
             newCompositeNode(grammarAccess.getContentPromptRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleContentPrompt=ruleContentPrompt();

            state._fsp--;

             current =iv_ruleContentPrompt; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContentPrompt"


    // $ANTLR start "ruleContentPrompt"
    // InternalAntiPattern.g:157:1: ruleContentPrompt returns [EObject current=null] : ( ( (lv_nbexemble_0_0= ruleExemples ) ) ( (lv_domain_1_0= ruleDomain ) ) ( (lv_classe_2_0= ruleClasses ) ) ( (lv_method_3_0= ruleChosenMethod ) ) ) ;
    public final EObject ruleContentPrompt() throws RecognitionException {
        EObject current = null;

        EObject lv_nbexemble_0_0 = null;

        EObject lv_domain_1_0 = null;

        EObject lv_classe_2_0 = null;

        EObject lv_method_3_0 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:163:2: ( ( ( (lv_nbexemble_0_0= ruleExemples ) ) ( (lv_domain_1_0= ruleDomain ) ) ( (lv_classe_2_0= ruleClasses ) ) ( (lv_method_3_0= ruleChosenMethod ) ) ) )
            // InternalAntiPattern.g:164:2: ( ( (lv_nbexemble_0_0= ruleExemples ) ) ( (lv_domain_1_0= ruleDomain ) ) ( (lv_classe_2_0= ruleClasses ) ) ( (lv_method_3_0= ruleChosenMethod ) ) )
            {
            // InternalAntiPattern.g:164:2: ( ( (lv_nbexemble_0_0= ruleExemples ) ) ( (lv_domain_1_0= ruleDomain ) ) ( (lv_classe_2_0= ruleClasses ) ) ( (lv_method_3_0= ruleChosenMethod ) ) )
            // InternalAntiPattern.g:165:3: ( (lv_nbexemble_0_0= ruleExemples ) ) ( (lv_domain_1_0= ruleDomain ) ) ( (lv_classe_2_0= ruleClasses ) ) ( (lv_method_3_0= ruleChosenMethod ) )
            {
            // InternalAntiPattern.g:165:3: ( (lv_nbexemble_0_0= ruleExemples ) )
            // InternalAntiPattern.g:166:4: (lv_nbexemble_0_0= ruleExemples )
            {
            // InternalAntiPattern.g:166:4: (lv_nbexemble_0_0= ruleExemples )
            // InternalAntiPattern.g:167:5: lv_nbexemble_0_0= ruleExemples
            {

            					newCompositeNode(grammarAccess.getContentPromptAccess().getNbexembleExemplesParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_7);
            lv_nbexemble_0_0=ruleExemples();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContentPromptRule());
            					}
            					set(
            						current,
            						"nbexemble",
            						lv_nbexemble_0_0,
            						"org.xtext.example.antipattern.AntiPattern.Exemples");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAntiPattern.g:184:3: ( (lv_domain_1_0= ruleDomain ) )
            // InternalAntiPattern.g:185:4: (lv_domain_1_0= ruleDomain )
            {
            // InternalAntiPattern.g:185:4: (lv_domain_1_0= ruleDomain )
            // InternalAntiPattern.g:186:5: lv_domain_1_0= ruleDomain
            {

            					newCompositeNode(grammarAccess.getContentPromptAccess().getDomainDomainParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_8);
            lv_domain_1_0=ruleDomain();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContentPromptRule());
            					}
            					set(
            						current,
            						"domain",
            						lv_domain_1_0,
            						"org.xtext.example.antipattern.AntiPattern.Domain");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAntiPattern.g:203:3: ( (lv_classe_2_0= ruleClasses ) )
            // InternalAntiPattern.g:204:4: (lv_classe_2_0= ruleClasses )
            {
            // InternalAntiPattern.g:204:4: (lv_classe_2_0= ruleClasses )
            // InternalAntiPattern.g:205:5: lv_classe_2_0= ruleClasses
            {

            					newCompositeNode(grammarAccess.getContentPromptAccess().getClasseClassesParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_9);
            lv_classe_2_0=ruleClasses();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContentPromptRule());
            					}
            					set(
            						current,
            						"classe",
            						lv_classe_2_0,
            						"org.xtext.example.antipattern.AntiPattern.Classes");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAntiPattern.g:222:3: ( (lv_method_3_0= ruleChosenMethod ) )
            // InternalAntiPattern.g:223:4: (lv_method_3_0= ruleChosenMethod )
            {
            // InternalAntiPattern.g:223:4: (lv_method_3_0= ruleChosenMethod )
            // InternalAntiPattern.g:224:5: lv_method_3_0= ruleChosenMethod
            {

            					newCompositeNode(grammarAccess.getContentPromptAccess().getMethodChosenMethodParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_method_3_0=ruleChosenMethod();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContentPromptRule());
            					}
            					set(
            						current,
            						"method",
            						lv_method_3_0,
            						"org.xtext.example.antipattern.AntiPattern.ChosenMethod");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContentPrompt"


    // $ANTLR start "entryRuleExemples"
    // InternalAntiPattern.g:245:1: entryRuleExemples returns [EObject current=null] : iv_ruleExemples= ruleExemples EOF ;
    public final EObject entryRuleExemples() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExemples = null;


        try {
            // InternalAntiPattern.g:245:49: (iv_ruleExemples= ruleExemples EOF )
            // InternalAntiPattern.g:246:2: iv_ruleExemples= ruleExemples EOF
            {
             newCompositeNode(grammarAccess.getExemplesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExemples=ruleExemples();

            state._fsp--;

             current =iv_ruleExemples; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExemples"


    // $ANTLR start "ruleExemples"
    // InternalAntiPattern.g:252:1: ruleExemples returns [EObject current=null] : (otherlv_0= 'nbExemples:' ( (lv_nbExemples_1_0= RULE_INT ) ) ) ;
    public final EObject ruleExemples() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nbExemples_1_0=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:258:2: ( (otherlv_0= 'nbExemples:' ( (lv_nbExemples_1_0= RULE_INT ) ) ) )
            // InternalAntiPattern.g:259:2: (otherlv_0= 'nbExemples:' ( (lv_nbExemples_1_0= RULE_INT ) ) )
            {
            // InternalAntiPattern.g:259:2: (otherlv_0= 'nbExemples:' ( (lv_nbExemples_1_0= RULE_INT ) ) )
            // InternalAntiPattern.g:260:3: otherlv_0= 'nbExemples:' ( (lv_nbExemples_1_0= RULE_INT ) )
            {
            otherlv_0=(Token)match(input,14,FOLLOW_10); 

            			newLeafNode(otherlv_0, grammarAccess.getExemplesAccess().getNbExemplesKeyword_0());
            		
            // InternalAntiPattern.g:264:3: ( (lv_nbExemples_1_0= RULE_INT ) )
            // InternalAntiPattern.g:265:4: (lv_nbExemples_1_0= RULE_INT )
            {
            // InternalAntiPattern.g:265:4: (lv_nbExemples_1_0= RULE_INT )
            // InternalAntiPattern.g:266:5: lv_nbExemples_1_0= RULE_INT
            {
            lv_nbExemples_1_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_nbExemples_1_0, grammarAccess.getExemplesAccess().getNbExemplesINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExemplesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nbExemples",
            						lv_nbExemples_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExemples"


    // $ANTLR start "entryRuleDomain"
    // InternalAntiPattern.g:286:1: entryRuleDomain returns [EObject current=null] : iv_ruleDomain= ruleDomain EOF ;
    public final EObject entryRuleDomain() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDomain = null;


        try {
            // InternalAntiPattern.g:286:47: (iv_ruleDomain= ruleDomain EOF )
            // InternalAntiPattern.g:287:2: iv_ruleDomain= ruleDomain EOF
            {
             newCompositeNode(grammarAccess.getDomainRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDomain=ruleDomain();

            state._fsp--;

             current =iv_ruleDomain; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDomain"


    // $ANTLR start "ruleDomain"
    // InternalAntiPattern.g:293:1: ruleDomain returns [EObject current=null] : (otherlv_0= 'Domain:' ( (lv_DomainName_1_0= RULE_ID ) ) ) ;
    public final EObject ruleDomain() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_DomainName_1_0=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:299:2: ( (otherlv_0= 'Domain:' ( (lv_DomainName_1_0= RULE_ID ) ) ) )
            // InternalAntiPattern.g:300:2: (otherlv_0= 'Domain:' ( (lv_DomainName_1_0= RULE_ID ) ) )
            {
            // InternalAntiPattern.g:300:2: (otherlv_0= 'Domain:' ( (lv_DomainName_1_0= RULE_ID ) ) )
            // InternalAntiPattern.g:301:3: otherlv_0= 'Domain:' ( (lv_DomainName_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,15,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getDomainAccess().getDomainKeyword_0());
            		
            // InternalAntiPattern.g:305:3: ( (lv_DomainName_1_0= RULE_ID ) )
            // InternalAntiPattern.g:306:4: (lv_DomainName_1_0= RULE_ID )
            {
            // InternalAntiPattern.g:306:4: (lv_DomainName_1_0= RULE_ID )
            // InternalAntiPattern.g:307:5: lv_DomainName_1_0= RULE_ID
            {
            lv_DomainName_1_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_DomainName_1_0, grammarAccess.getDomainAccess().getDomainNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDomainRule());
            					}
            					setWithLastConsumed(
            						current,
            						"DomainName",
            						lv_DomainName_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDomain"


    // $ANTLR start "entryRuleClasses"
    // InternalAntiPattern.g:327:1: entryRuleClasses returns [EObject current=null] : iv_ruleClasses= ruleClasses EOF ;
    public final EObject entryRuleClasses() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClasses = null;


        try {
            // InternalAntiPattern.g:327:48: (iv_ruleClasses= ruleClasses EOF )
            // InternalAntiPattern.g:328:2: iv_ruleClasses= ruleClasses EOF
            {
             newCompositeNode(grammarAccess.getClassesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClasses=ruleClasses();

            state._fsp--;

             current =iv_ruleClasses; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClasses"


    // $ANTLR start "ruleClasses"
    // InternalAntiPattern.g:334:1: ruleClasses returns [EObject current=null] : (otherlv_0= 'Classes:' ( (lv_nbClass_1_0= RULE_INT ) ) ( (lv__class_2_0= rule_Class ) )* ) ;
    public final EObject ruleClasses() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nbClass_1_0=null;
        EObject lv__class_2_0 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:340:2: ( (otherlv_0= 'Classes:' ( (lv_nbClass_1_0= RULE_INT ) ) ( (lv__class_2_0= rule_Class ) )* ) )
            // InternalAntiPattern.g:341:2: (otherlv_0= 'Classes:' ( (lv_nbClass_1_0= RULE_INT ) ) ( (lv__class_2_0= rule_Class ) )* )
            {
            // InternalAntiPattern.g:341:2: (otherlv_0= 'Classes:' ( (lv_nbClass_1_0= RULE_INT ) ) ( (lv__class_2_0= rule_Class ) )* )
            // InternalAntiPattern.g:342:3: otherlv_0= 'Classes:' ( (lv_nbClass_1_0= RULE_INT ) ) ( (lv__class_2_0= rule_Class ) )*
            {
            otherlv_0=(Token)match(input,16,FOLLOW_10); 

            			newLeafNode(otherlv_0, grammarAccess.getClassesAccess().getClassesKeyword_0());
            		
            // InternalAntiPattern.g:346:3: ( (lv_nbClass_1_0= RULE_INT ) )
            // InternalAntiPattern.g:347:4: (lv_nbClass_1_0= RULE_INT )
            {
            // InternalAntiPattern.g:347:4: (lv_nbClass_1_0= RULE_INT )
            // InternalAntiPattern.g:348:5: lv_nbClass_1_0= RULE_INT
            {
            lv_nbClass_1_0=(Token)match(input,RULE_INT,FOLLOW_12); 

            					newLeafNode(lv_nbClass_1_0, grammarAccess.getClassesAccess().getNbClassINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClassesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nbClass",
            						lv_nbClass_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalAntiPattern.g:364:3: ( (lv__class_2_0= rule_Class ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==17) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalAntiPattern.g:365:4: (lv__class_2_0= rule_Class )
            	    {
            	    // InternalAntiPattern.g:365:4: (lv__class_2_0= rule_Class )
            	    // InternalAntiPattern.g:366:5: lv__class_2_0= rule_Class
            	    {

            	    					newCompositeNode(grammarAccess.getClassesAccess().get_class_ClassParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_12);
            	    lv__class_2_0=rule_Class();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getClassesRule());
            	    					}
            	    					add(
            	    						current,
            	    						"_class",
            	    						lv__class_2_0,
            	    						"org.xtext.example.antipattern.AntiPattern._Class");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClasses"


    // $ANTLR start "entryRule_Class"
    // InternalAntiPattern.g:387:1: entryRule_Class returns [EObject current=null] : iv_rule_Class= rule_Class EOF ;
    public final EObject entryRule_Class() throws RecognitionException {
        EObject current = null;

        EObject iv_rule_Class = null;


        try {
            // InternalAntiPattern.g:387:47: (iv_rule_Class= rule_Class EOF )
            // InternalAntiPattern.g:388:2: iv_rule_Class= rule_Class EOF
            {
             newCompositeNode(grammarAccess.get_ClassRule()); 
            pushFollow(FOLLOW_1);
            iv_rule_Class=rule_Class();

            state._fsp--;

             current =iv_rule_Class; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRule_Class"


    // $ANTLR start "rule_Class"
    // InternalAntiPattern.g:394:1: rule_Class returns [EObject current=null] : (otherlv_0= 'class:' ( (lv_ClassName_1_0= RULE_ID ) ) ) ;
    public final EObject rule_Class() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_ClassName_1_0=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:400:2: ( (otherlv_0= 'class:' ( (lv_ClassName_1_0= RULE_ID ) ) ) )
            // InternalAntiPattern.g:401:2: (otherlv_0= 'class:' ( (lv_ClassName_1_0= RULE_ID ) ) )
            {
            // InternalAntiPattern.g:401:2: (otherlv_0= 'class:' ( (lv_ClassName_1_0= RULE_ID ) ) )
            // InternalAntiPattern.g:402:3: otherlv_0= 'class:' ( (lv_ClassName_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,17,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.get_ClassAccess().getClassKeyword_0());
            		
            // InternalAntiPattern.g:406:3: ( (lv_ClassName_1_0= RULE_ID ) )
            // InternalAntiPattern.g:407:4: (lv_ClassName_1_0= RULE_ID )
            {
            // InternalAntiPattern.g:407:4: (lv_ClassName_1_0= RULE_ID )
            // InternalAntiPattern.g:408:5: lv_ClassName_1_0= RULE_ID
            {
            lv_ClassName_1_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_ClassName_1_0, grammarAccess.get_ClassAccess().getClassNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.get_ClassRule());
            					}
            					setWithLastConsumed(
            						current,
            						"ClassName",
            						lv_ClassName_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rule_Class"


    // $ANTLR start "entryRuleChosenMethod"
    // InternalAntiPattern.g:428:1: entryRuleChosenMethod returns [EObject current=null] : iv_ruleChosenMethod= ruleChosenMethod EOF ;
    public final EObject entryRuleChosenMethod() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleChosenMethod = null;


        try {
            // InternalAntiPattern.g:428:53: (iv_ruleChosenMethod= ruleChosenMethod EOF )
            // InternalAntiPattern.g:429:2: iv_ruleChosenMethod= ruleChosenMethod EOF
            {
             newCompositeNode(grammarAccess.getChosenMethodRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleChosenMethod=ruleChosenMethod();

            state._fsp--;

             current =iv_ruleChosenMethod; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleChosenMethod"


    // $ANTLR start "ruleChosenMethod"
    // InternalAntiPattern.g:435:1: ruleChosenMethod returns [EObject current=null] : (otherlv_0= 'Method_In' ( (lv_class_1_0= rule_Class ) ) otherlv_2= 'conditions:' otherlv_3= '{' ( (lv_conditions_4_0= ruleCondition ) )* otherlv_5= '}' ) ;
    public final EObject ruleChosenMethod() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_class_1_0 = null;

        EObject lv_conditions_4_0 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:441:2: ( (otherlv_0= 'Method_In' ( (lv_class_1_0= rule_Class ) ) otherlv_2= 'conditions:' otherlv_3= '{' ( (lv_conditions_4_0= ruleCondition ) )* otherlv_5= '}' ) )
            // InternalAntiPattern.g:442:2: (otherlv_0= 'Method_In' ( (lv_class_1_0= rule_Class ) ) otherlv_2= 'conditions:' otherlv_3= '{' ( (lv_conditions_4_0= ruleCondition ) )* otherlv_5= '}' )
            {
            // InternalAntiPattern.g:442:2: (otherlv_0= 'Method_In' ( (lv_class_1_0= rule_Class ) ) otherlv_2= 'conditions:' otherlv_3= '{' ( (lv_conditions_4_0= ruleCondition ) )* otherlv_5= '}' )
            // InternalAntiPattern.g:443:3: otherlv_0= 'Method_In' ( (lv_class_1_0= rule_Class ) ) otherlv_2= 'conditions:' otherlv_3= '{' ( (lv_conditions_4_0= ruleCondition ) )* otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getChosenMethodAccess().getMethod_InKeyword_0());
            		
            // InternalAntiPattern.g:447:3: ( (lv_class_1_0= rule_Class ) )
            // InternalAntiPattern.g:448:4: (lv_class_1_0= rule_Class )
            {
            // InternalAntiPattern.g:448:4: (lv_class_1_0= rule_Class )
            // InternalAntiPattern.g:449:5: lv_class_1_0= rule_Class
            {

            					newCompositeNode(grammarAccess.getChosenMethodAccess().getClass_ClassParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_14);
            lv_class_1_0=rule_Class();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChosenMethodRule());
            					}
            					set(
            						current,
            						"class",
            						lv_class_1_0,
            						"org.xtext.example.antipattern.AntiPattern._Class");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,19,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getChosenMethodAccess().getConditionsKeyword_2());
            		
            otherlv_3=(Token)match(input,12,FOLLOW_15); 

            			newLeafNode(otherlv_3, grammarAccess.getChosenMethodAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalAntiPattern.g:474:3: ( (lv_conditions_4_0= ruleCondition ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==20||LA3_0==23) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalAntiPattern.g:475:4: (lv_conditions_4_0= ruleCondition )
            	    {
            	    // InternalAntiPattern.g:475:4: (lv_conditions_4_0= ruleCondition )
            	    // InternalAntiPattern.g:476:5: lv_conditions_4_0= ruleCondition
            	    {

            	    					newCompositeNode(grammarAccess.getChosenMethodAccess().getConditionsConditionParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_15);
            	    lv_conditions_4_0=ruleCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getChosenMethodRule());
            	    					}
            	    					add(
            	    						current,
            	    						"conditions",
            	    						lv_conditions_4_0,
            	    						"org.xtext.example.antipattern.AntiPattern.Condition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            otherlv_5=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getChosenMethodAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleChosenMethod"


    // $ANTLR start "entryRuleCondition"
    // InternalAntiPattern.g:501:1: entryRuleCondition returns [EObject current=null] : iv_ruleCondition= ruleCondition EOF ;
    public final EObject entryRuleCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCondition = null;


        try {
            // InternalAntiPattern.g:501:50: (iv_ruleCondition= ruleCondition EOF )
            // InternalAntiPattern.g:502:2: iv_ruleCondition= ruleCondition EOF
            {
             newCompositeNode(grammarAccess.getConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCondition=ruleCondition();

            state._fsp--;

             current =iv_ruleCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCondition"


    // $ANTLR start "ruleCondition"
    // InternalAntiPattern.g:508:1: ruleCondition returns [EObject current=null] : ( ( (lv_link_0_0= ruleLink ) )? otherlv_1= '(' ( (lv_rules_2_0= ruleRuleType ) ) (otherlv_3= ',' ( (lv_rules_4_0= ruleRuleType ) ) )* (otherlv_5= ')' )? ) ;
    public final EObject ruleCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_link_0_0 = null;

        EObject lv_rules_2_0 = null;

        EObject lv_rules_4_0 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:514:2: ( ( ( (lv_link_0_0= ruleLink ) )? otherlv_1= '(' ( (lv_rules_2_0= ruleRuleType ) ) (otherlv_3= ',' ( (lv_rules_4_0= ruleRuleType ) ) )* (otherlv_5= ')' )? ) )
            // InternalAntiPattern.g:515:2: ( ( (lv_link_0_0= ruleLink ) )? otherlv_1= '(' ( (lv_rules_2_0= ruleRuleType ) ) (otherlv_3= ',' ( (lv_rules_4_0= ruleRuleType ) ) )* (otherlv_5= ')' )? )
            {
            // InternalAntiPattern.g:515:2: ( ( (lv_link_0_0= ruleLink ) )? otherlv_1= '(' ( (lv_rules_2_0= ruleRuleType ) ) (otherlv_3= ',' ( (lv_rules_4_0= ruleRuleType ) ) )* (otherlv_5= ')' )? )
            // InternalAntiPattern.g:516:3: ( (lv_link_0_0= ruleLink ) )? otherlv_1= '(' ( (lv_rules_2_0= ruleRuleType ) ) (otherlv_3= ',' ( (lv_rules_4_0= ruleRuleType ) ) )* (otherlv_5= ')' )?
            {
            // InternalAntiPattern.g:516:3: ( (lv_link_0_0= ruleLink ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==23) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalAntiPattern.g:517:4: (lv_link_0_0= ruleLink )
                    {
                    // InternalAntiPattern.g:517:4: (lv_link_0_0= ruleLink )
                    // InternalAntiPattern.g:518:5: lv_link_0_0= ruleLink
                    {

                    					newCompositeNode(grammarAccess.getConditionAccess().getLinkLinkParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_16);
                    lv_link_0_0=ruleLink();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getConditionRule());
                    					}
                    					set(
                    						current,
                    						"link",
                    						lv_link_0_0,
                    						"org.xtext.example.antipattern.AntiPattern.Link");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,20,FOLLOW_17); 

            			newLeafNode(otherlv_1, grammarAccess.getConditionAccess().getLeftParenthesisKeyword_1());
            		
            // InternalAntiPattern.g:539:3: ( (lv_rules_2_0= ruleRuleType ) )
            // InternalAntiPattern.g:540:4: (lv_rules_2_0= ruleRuleType )
            {
            // InternalAntiPattern.g:540:4: (lv_rules_2_0= ruleRuleType )
            // InternalAntiPattern.g:541:5: lv_rules_2_0= ruleRuleType
            {

            					newCompositeNode(grammarAccess.getConditionAccess().getRulesRuleTypeParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_18);
            lv_rules_2_0=ruleRuleType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getConditionRule());
            					}
            					add(
            						current,
            						"rules",
            						lv_rules_2_0,
            						"org.xtext.example.antipattern.AntiPattern.RuleType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAntiPattern.g:558:3: (otherlv_3= ',' ( (lv_rules_4_0= ruleRuleType ) ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==21) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalAntiPattern.g:559:4: otherlv_3= ',' ( (lv_rules_4_0= ruleRuleType ) )
            	    {
            	    otherlv_3=(Token)match(input,21,FOLLOW_17); 

            	    				newLeafNode(otherlv_3, grammarAccess.getConditionAccess().getCommaKeyword_3_0());
            	    			
            	    // InternalAntiPattern.g:563:4: ( (lv_rules_4_0= ruleRuleType ) )
            	    // InternalAntiPattern.g:564:5: (lv_rules_4_0= ruleRuleType )
            	    {
            	    // InternalAntiPattern.g:564:5: (lv_rules_4_0= ruleRuleType )
            	    // InternalAntiPattern.g:565:6: lv_rules_4_0= ruleRuleType
            	    {

            	    						newCompositeNode(grammarAccess.getConditionAccess().getRulesRuleTypeParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_18);
            	    lv_rules_4_0=ruleRuleType();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getConditionRule());
            	    						}
            	    						add(
            	    							current,
            	    							"rules",
            	    							lv_rules_4_0,
            	    							"org.xtext.example.antipattern.AntiPattern.RuleType");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // InternalAntiPattern.g:583:3: (otherlv_5= ')' )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==22) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalAntiPattern.g:584:4: otherlv_5= ')'
                    {
                    otherlv_5=(Token)match(input,22,FOLLOW_2); 

                    				newLeafNode(otherlv_5, grammarAccess.getConditionAccess().getRightParenthesisKeyword_4());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCondition"


    // $ANTLR start "entryRuleLink"
    // InternalAntiPattern.g:593:1: entryRuleLink returns [EObject current=null] : iv_ruleLink= ruleLink EOF ;
    public final EObject entryRuleLink() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLink = null;


        try {
            // InternalAntiPattern.g:593:45: (iv_ruleLink= ruleLink EOF )
            // InternalAntiPattern.g:594:2: iv_ruleLink= ruleLink EOF
            {
             newCompositeNode(grammarAccess.getLinkRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLink=ruleLink();

            state._fsp--;

             current =iv_ruleLink; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLink"


    // $ANTLR start "ruleLink"
    // InternalAntiPattern.g:600:1: ruleLink returns [EObject current=null] : ( (lv_op_0_0= 'UNION' ) ) ;
    public final EObject ruleLink() throws RecognitionException {
        EObject current = null;

        Token lv_op_0_0=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:606:2: ( ( (lv_op_0_0= 'UNION' ) ) )
            // InternalAntiPattern.g:607:2: ( (lv_op_0_0= 'UNION' ) )
            {
            // InternalAntiPattern.g:607:2: ( (lv_op_0_0= 'UNION' ) )
            // InternalAntiPattern.g:608:3: (lv_op_0_0= 'UNION' )
            {
            // InternalAntiPattern.g:608:3: (lv_op_0_0= 'UNION' )
            // InternalAntiPattern.g:609:4: lv_op_0_0= 'UNION'
            {
            lv_op_0_0=(Token)match(input,23,FOLLOW_2); 

            				newLeafNode(lv_op_0_0, grammarAccess.getLinkAccess().getOpUNIONKeyword_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getLinkRule());
            				}
            				setWithLastConsumed(current, "op", lv_op_0_0, "UNION");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLink"


    // $ANTLR start "entryRuleRuleType"
    // InternalAntiPattern.g:624:1: entryRuleRuleType returns [EObject current=null] : iv_ruleRuleType= ruleRuleType EOF ;
    public final EObject entryRuleRuleType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRuleType = null;


        try {
            // InternalAntiPattern.g:624:49: (iv_ruleRuleType= ruleRuleType EOF )
            // InternalAntiPattern.g:625:2: iv_ruleRuleType= ruleRuleType EOF
            {
             newCompositeNode(grammarAccess.getRuleTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRuleType=ruleRuleType();

            state._fsp--;

             current =iv_ruleRuleType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRuleType"


    // $ANTLR start "ruleRuleType"
    // InternalAntiPattern.g:631:1: ruleRuleType returns [EObject current=null] : (this_IntraCharacteristic_0= ruleIntraCharacteristic | this_InterCarachteristic_1= ruleInterCarachteristic ) ;
    public final EObject ruleRuleType() throws RecognitionException {
        EObject current = null;

        EObject this_IntraCharacteristic_0 = null;

        EObject this_InterCarachteristic_1 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:637:2: ( (this_IntraCharacteristic_0= ruleIntraCharacteristic | this_InterCarachteristic_1= ruleInterCarachteristic ) )
            // InternalAntiPattern.g:638:2: (this_IntraCharacteristic_0= ruleIntraCharacteristic | this_InterCarachteristic_1= ruleInterCarachteristic )
            {
            // InternalAntiPattern.g:638:2: (this_IntraCharacteristic_0= ruleIntraCharacteristic | this_InterCarachteristic_1= ruleInterCarachteristic )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( ((LA7_0>=25 && LA7_0<=30)) ) {
                alt7=1;
            }
            else if ( (LA7_0==54) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalAntiPattern.g:639:3: this_IntraCharacteristic_0= ruleIntraCharacteristic
                    {

                    			newCompositeNode(grammarAccess.getRuleTypeAccess().getIntraCharacteristicParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_IntraCharacteristic_0=ruleIntraCharacteristic();

                    state._fsp--;


                    			current = this_IntraCharacteristic_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:648:3: this_InterCarachteristic_1= ruleInterCarachteristic
                    {

                    			newCompositeNode(grammarAccess.getRuleTypeAccess().getInterCarachteristicParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_InterCarachteristic_1=ruleInterCarachteristic();

                    state._fsp--;


                    			current = this_InterCarachteristic_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRuleType"


    // $ANTLR start "entryRuleIntraCharacteristic"
    // InternalAntiPattern.g:660:1: entryRuleIntraCharacteristic returns [EObject current=null] : iv_ruleIntraCharacteristic= ruleIntraCharacteristic EOF ;
    public final EObject entryRuleIntraCharacteristic() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIntraCharacteristic = null;


        try {
            // InternalAntiPattern.g:660:60: (iv_ruleIntraCharacteristic= ruleIntraCharacteristic EOF )
            // InternalAntiPattern.g:661:2: iv_ruleIntraCharacteristic= ruleIntraCharacteristic EOF
            {
             newCompositeNode(grammarAccess.getIntraCharacteristicRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIntraCharacteristic=ruleIntraCharacteristic();

            state._fsp--;

             current =iv_ruleIntraCharacteristic; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIntraCharacteristic"


    // $ANTLR start "ruleIntraCharacteristic"
    // InternalAntiPattern.g:667:1: ruleIntraCharacteristic returns [EObject current=null] : ( ( ( (lv_metric_0_0= ruleMetric ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_value_2_0= RULE_INT ) ) (otherlv_3= 'manners' otherlv_4= '(' ( (lv_quantity_5_0= ruleQunatity ) ) ( (lv_m_6_0= ruleManner ) ) (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )* otherlv_10= ')' )? ) | (otherlv_11= 'violates' otherlv_12= '(' ( (lv_convention_13_0= ruleConvention ) ) (otherlv_14= ',' ( (lv_convention_15_0= ruleConvention ) ) )* otherlv_16= ')' ) ) ;
    public final EObject ruleIntraCharacteristic() throws RecognitionException {
        EObject current = null;

        Token lv_value_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_7=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        EObject lv_metric_0_0 = null;

        EObject lv_comparator_1_0 = null;

        EObject lv_quantity_5_0 = null;

        EObject lv_m_6_0 = null;

        EObject lv_quantity_8_0 = null;

        EObject lv_m_9_0 = null;

        EObject lv_convention_13_0 = null;

        EObject lv_convention_15_0 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:673:2: ( ( ( ( (lv_metric_0_0= ruleMetric ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_value_2_0= RULE_INT ) ) (otherlv_3= 'manners' otherlv_4= '(' ( (lv_quantity_5_0= ruleQunatity ) ) ( (lv_m_6_0= ruleManner ) ) (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )* otherlv_10= ')' )? ) | (otherlv_11= 'violates' otherlv_12= '(' ( (lv_convention_13_0= ruleConvention ) ) (otherlv_14= ',' ( (lv_convention_15_0= ruleConvention ) ) )* otherlv_16= ')' ) ) )
            // InternalAntiPattern.g:674:2: ( ( ( (lv_metric_0_0= ruleMetric ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_value_2_0= RULE_INT ) ) (otherlv_3= 'manners' otherlv_4= '(' ( (lv_quantity_5_0= ruleQunatity ) ) ( (lv_m_6_0= ruleManner ) ) (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )* otherlv_10= ')' )? ) | (otherlv_11= 'violates' otherlv_12= '(' ( (lv_convention_13_0= ruleConvention ) ) (otherlv_14= ',' ( (lv_convention_15_0= ruleConvention ) ) )* otherlv_16= ')' ) )
            {
            // InternalAntiPattern.g:674:2: ( ( ( (lv_metric_0_0= ruleMetric ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_value_2_0= RULE_INT ) ) (otherlv_3= 'manners' otherlv_4= '(' ( (lv_quantity_5_0= ruleQunatity ) ) ( (lv_m_6_0= ruleManner ) ) (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )* otherlv_10= ')' )? ) | (otherlv_11= 'violates' otherlv_12= '(' ( (lv_convention_13_0= ruleConvention ) ) (otherlv_14= ',' ( (lv_convention_15_0= ruleConvention ) ) )* otherlv_16= ')' ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( ((LA11_0>=26 && LA11_0<=30)) ) {
                alt11=1;
            }
            else if ( (LA11_0==25) ) {
                alt11=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalAntiPattern.g:675:3: ( ( (lv_metric_0_0= ruleMetric ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_value_2_0= RULE_INT ) ) (otherlv_3= 'manners' otherlv_4= '(' ( (lv_quantity_5_0= ruleQunatity ) ) ( (lv_m_6_0= ruleManner ) ) (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )* otherlv_10= ')' )? )
                    {
                    // InternalAntiPattern.g:675:3: ( ( (lv_metric_0_0= ruleMetric ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_value_2_0= RULE_INT ) ) (otherlv_3= 'manners' otherlv_4= '(' ( (lv_quantity_5_0= ruleQunatity ) ) ( (lv_m_6_0= ruleManner ) ) (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )* otherlv_10= ')' )? )
                    // InternalAntiPattern.g:676:4: ( (lv_metric_0_0= ruleMetric ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_value_2_0= RULE_INT ) ) (otherlv_3= 'manners' otherlv_4= '(' ( (lv_quantity_5_0= ruleQunatity ) ) ( (lv_m_6_0= ruleManner ) ) (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )* otherlv_10= ')' )?
                    {
                    // InternalAntiPattern.g:676:4: ( (lv_metric_0_0= ruleMetric ) )
                    // InternalAntiPattern.g:677:5: (lv_metric_0_0= ruleMetric )
                    {
                    // InternalAntiPattern.g:677:5: (lv_metric_0_0= ruleMetric )
                    // InternalAntiPattern.g:678:6: lv_metric_0_0= ruleMetric
                    {

                    						newCompositeNode(grammarAccess.getIntraCharacteristicAccess().getMetricMetricParserRuleCall_0_0_0());
                    					
                    pushFollow(FOLLOW_19);
                    lv_metric_0_0=ruleMetric();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getIntraCharacteristicRule());
                    						}
                    						set(
                    							current,
                    							"metric",
                    							lv_metric_0_0,
                    							"org.xtext.example.antipattern.AntiPattern.Metric");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalAntiPattern.g:695:4: ( (lv_comparator_1_0= ruleComparator ) )
                    // InternalAntiPattern.g:696:5: (lv_comparator_1_0= ruleComparator )
                    {
                    // InternalAntiPattern.g:696:5: (lv_comparator_1_0= ruleComparator )
                    // InternalAntiPattern.g:697:6: lv_comparator_1_0= ruleComparator
                    {

                    						newCompositeNode(grammarAccess.getIntraCharacteristicAccess().getComparatorComparatorParserRuleCall_0_1_0());
                    					
                    pushFollow(FOLLOW_10);
                    lv_comparator_1_0=ruleComparator();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getIntraCharacteristicRule());
                    						}
                    						set(
                    							current,
                    							"comparator",
                    							lv_comparator_1_0,
                    							"org.xtext.example.antipattern.AntiPattern.Comparator");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalAntiPattern.g:714:4: ( (lv_value_2_0= RULE_INT ) )
                    // InternalAntiPattern.g:715:5: (lv_value_2_0= RULE_INT )
                    {
                    // InternalAntiPattern.g:715:5: (lv_value_2_0= RULE_INT )
                    // InternalAntiPattern.g:716:6: lv_value_2_0= RULE_INT
                    {
                    lv_value_2_0=(Token)match(input,RULE_INT,FOLLOW_20); 

                    						newLeafNode(lv_value_2_0, grammarAccess.getIntraCharacteristicAccess().getValueINTTerminalRuleCall_0_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getIntraCharacteristicRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"value",
                    							lv_value_2_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    // InternalAntiPattern.g:732:4: (otherlv_3= 'manners' otherlv_4= '(' ( (lv_quantity_5_0= ruleQunatity ) ) ( (lv_m_6_0= ruleManner ) ) (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )* otherlv_10= ')' )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==24) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // InternalAntiPattern.g:733:5: otherlv_3= 'manners' otherlv_4= '(' ( (lv_quantity_5_0= ruleQunatity ) ) ( (lv_m_6_0= ruleManner ) ) (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )* otherlv_10= ')'
                            {
                            otherlv_3=(Token)match(input,24,FOLLOW_16); 

                            					newLeafNode(otherlv_3, grammarAccess.getIntraCharacteristicAccess().getMannersKeyword_0_3_0());
                            				
                            otherlv_4=(Token)match(input,20,FOLLOW_21); 

                            					newLeafNode(otherlv_4, grammarAccess.getIntraCharacteristicAccess().getLeftParenthesisKeyword_0_3_1());
                            				
                            // InternalAntiPattern.g:741:5: ( (lv_quantity_5_0= ruleQunatity ) )
                            // InternalAntiPattern.g:742:6: (lv_quantity_5_0= ruleQunatity )
                            {
                            // InternalAntiPattern.g:742:6: (lv_quantity_5_0= ruleQunatity )
                            // InternalAntiPattern.g:743:7: lv_quantity_5_0= ruleQunatity
                            {

                            							newCompositeNode(grammarAccess.getIntraCharacteristicAccess().getQuantityQunatityParserRuleCall_0_3_2_0());
                            						
                            pushFollow(FOLLOW_22);
                            lv_quantity_5_0=ruleQunatity();

                            state._fsp--;


                            							if (current==null) {
                            								current = createModelElementForParent(grammarAccess.getIntraCharacteristicRule());
                            							}
                            							add(
                            								current,
                            								"quantity",
                            								lv_quantity_5_0,
                            								"org.xtext.example.antipattern.AntiPattern.Qunatity");
                            							afterParserOrEnumRuleCall();
                            						

                            }


                            }

                            // InternalAntiPattern.g:760:5: ( (lv_m_6_0= ruleManner ) )
                            // InternalAntiPattern.g:761:6: (lv_m_6_0= ruleManner )
                            {
                            // InternalAntiPattern.g:761:6: (lv_m_6_0= ruleManner )
                            // InternalAntiPattern.g:762:7: lv_m_6_0= ruleManner
                            {

                            							newCompositeNode(grammarAccess.getIntraCharacteristicAccess().getMMannerParserRuleCall_0_3_3_0());
                            						
                            pushFollow(FOLLOW_23);
                            lv_m_6_0=ruleManner();

                            state._fsp--;


                            							if (current==null) {
                            								current = createModelElementForParent(grammarAccess.getIntraCharacteristicRule());
                            							}
                            							add(
                            								current,
                            								"m",
                            								lv_m_6_0,
                            								"org.xtext.example.antipattern.AntiPattern.Manner");
                            							afterParserOrEnumRuleCall();
                            						

                            }


                            }

                            // InternalAntiPattern.g:779:5: (otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) ) )*
                            loop8:
                            do {
                                int alt8=2;
                                int LA8_0 = input.LA(1);

                                if ( (LA8_0==21) ) {
                                    alt8=1;
                                }


                                switch (alt8) {
                            	case 1 :
                            	    // InternalAntiPattern.g:780:6: otherlv_7= ',' ( (lv_quantity_8_0= ruleQunatity ) ) ( (lv_m_9_0= ruleManner ) )
                            	    {
                            	    otherlv_7=(Token)match(input,21,FOLLOW_21); 

                            	    						newLeafNode(otherlv_7, grammarAccess.getIntraCharacteristicAccess().getCommaKeyword_0_3_4_0());
                            	    					
                            	    // InternalAntiPattern.g:784:6: ( (lv_quantity_8_0= ruleQunatity ) )
                            	    // InternalAntiPattern.g:785:7: (lv_quantity_8_0= ruleQunatity )
                            	    {
                            	    // InternalAntiPattern.g:785:7: (lv_quantity_8_0= ruleQunatity )
                            	    // InternalAntiPattern.g:786:8: lv_quantity_8_0= ruleQunatity
                            	    {

                            	    								newCompositeNode(grammarAccess.getIntraCharacteristicAccess().getQuantityQunatityParserRuleCall_0_3_4_1_0());
                            	    							
                            	    pushFollow(FOLLOW_22);
                            	    lv_quantity_8_0=ruleQunatity();

                            	    state._fsp--;


                            	    								if (current==null) {
                            	    									current = createModelElementForParent(grammarAccess.getIntraCharacteristicRule());
                            	    								}
                            	    								add(
                            	    									current,
                            	    									"quantity",
                            	    									lv_quantity_8_0,
                            	    									"org.xtext.example.antipattern.AntiPattern.Qunatity");
                            	    								afterParserOrEnumRuleCall();
                            	    							

                            	    }


                            	    }

                            	    // InternalAntiPattern.g:803:6: ( (lv_m_9_0= ruleManner ) )
                            	    // InternalAntiPattern.g:804:7: (lv_m_9_0= ruleManner )
                            	    {
                            	    // InternalAntiPattern.g:804:7: (lv_m_9_0= ruleManner )
                            	    // InternalAntiPattern.g:805:8: lv_m_9_0= ruleManner
                            	    {

                            	    								newCompositeNode(grammarAccess.getIntraCharacteristicAccess().getMMannerParserRuleCall_0_3_4_2_0());
                            	    							
                            	    pushFollow(FOLLOW_23);
                            	    lv_m_9_0=ruleManner();

                            	    state._fsp--;


                            	    								if (current==null) {
                            	    									current = createModelElementForParent(grammarAccess.getIntraCharacteristicRule());
                            	    								}
                            	    								add(
                            	    									current,
                            	    									"m",
                            	    									lv_m_9_0,
                            	    									"org.xtext.example.antipattern.AntiPattern.Manner");
                            	    								afterParserOrEnumRuleCall();
                            	    							

                            	    }


                            	    }


                            	    }
                            	    break;

                            	default :
                            	    break loop8;
                                }
                            } while (true);

                            otherlv_10=(Token)match(input,22,FOLLOW_2); 

                            					newLeafNode(otherlv_10, grammarAccess.getIntraCharacteristicAccess().getRightParenthesisKeyword_0_3_5());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:830:3: (otherlv_11= 'violates' otherlv_12= '(' ( (lv_convention_13_0= ruleConvention ) ) (otherlv_14= ',' ( (lv_convention_15_0= ruleConvention ) ) )* otherlv_16= ')' )
                    {
                    // InternalAntiPattern.g:830:3: (otherlv_11= 'violates' otherlv_12= '(' ( (lv_convention_13_0= ruleConvention ) ) (otherlv_14= ',' ( (lv_convention_15_0= ruleConvention ) ) )* otherlv_16= ')' )
                    // InternalAntiPattern.g:831:4: otherlv_11= 'violates' otherlv_12= '(' ( (lv_convention_13_0= ruleConvention ) ) (otherlv_14= ',' ( (lv_convention_15_0= ruleConvention ) ) )* otherlv_16= ')'
                    {
                    otherlv_11=(Token)match(input,25,FOLLOW_16); 

                    				newLeafNode(otherlv_11, grammarAccess.getIntraCharacteristicAccess().getViolatesKeyword_1_0());
                    			
                    otherlv_12=(Token)match(input,20,FOLLOW_24); 

                    				newLeafNode(otherlv_12, grammarAccess.getIntraCharacteristicAccess().getLeftParenthesisKeyword_1_1());
                    			
                    // InternalAntiPattern.g:839:4: ( (lv_convention_13_0= ruleConvention ) )
                    // InternalAntiPattern.g:840:5: (lv_convention_13_0= ruleConvention )
                    {
                    // InternalAntiPattern.g:840:5: (lv_convention_13_0= ruleConvention )
                    // InternalAntiPattern.g:841:6: lv_convention_13_0= ruleConvention
                    {

                    						newCompositeNode(grammarAccess.getIntraCharacteristicAccess().getConventionConventionParserRuleCall_1_2_0());
                    					
                    pushFollow(FOLLOW_23);
                    lv_convention_13_0=ruleConvention();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getIntraCharacteristicRule());
                    						}
                    						add(
                    							current,
                    							"convention",
                    							lv_convention_13_0,
                    							"org.xtext.example.antipattern.AntiPattern.Convention");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalAntiPattern.g:858:4: (otherlv_14= ',' ( (lv_convention_15_0= ruleConvention ) ) )*
                    loop10:
                    do {
                        int alt10=2;
                        int LA10_0 = input.LA(1);

                        if ( (LA10_0==21) ) {
                            alt10=1;
                        }


                        switch (alt10) {
                    	case 1 :
                    	    // InternalAntiPattern.g:859:5: otherlv_14= ',' ( (lv_convention_15_0= ruleConvention ) )
                    	    {
                    	    otherlv_14=(Token)match(input,21,FOLLOW_24); 

                    	    					newLeafNode(otherlv_14, grammarAccess.getIntraCharacteristicAccess().getCommaKeyword_1_3_0());
                    	    				
                    	    // InternalAntiPattern.g:863:5: ( (lv_convention_15_0= ruleConvention ) )
                    	    // InternalAntiPattern.g:864:6: (lv_convention_15_0= ruleConvention )
                    	    {
                    	    // InternalAntiPattern.g:864:6: (lv_convention_15_0= ruleConvention )
                    	    // InternalAntiPattern.g:865:7: lv_convention_15_0= ruleConvention
                    	    {

                    	    							newCompositeNode(grammarAccess.getIntraCharacteristicAccess().getConventionConventionParserRuleCall_1_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_23);
                    	    lv_convention_15_0=ruleConvention();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getIntraCharacteristicRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"convention",
                    	    								lv_convention_15_0,
                    	    								"org.xtext.example.antipattern.AntiPattern.Convention");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop10;
                        }
                    } while (true);

                    otherlv_16=(Token)match(input,22,FOLLOW_2); 

                    				newLeafNode(otherlv_16, grammarAccess.getIntraCharacteristicAccess().getRightParenthesisKeyword_1_4());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIntraCharacteristic"


    // $ANTLR start "entryRuleMetric"
    // InternalAntiPattern.g:892:1: entryRuleMetric returns [EObject current=null] : iv_ruleMetric= ruleMetric EOF ;
    public final EObject entryRuleMetric() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMetric = null;


        try {
            // InternalAntiPattern.g:892:47: (iv_ruleMetric= ruleMetric EOF )
            // InternalAntiPattern.g:893:2: iv_ruleMetric= ruleMetric EOF
            {
             newCompositeNode(grammarAccess.getMetricRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMetric=ruleMetric();

            state._fsp--;

             current =iv_ruleMetric; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMetric"


    // $ANTLR start "ruleMetric"
    // InternalAntiPattern.g:899:1: ruleMetric returns [EObject current=null] : (this_MAXMetric_0= ruleMAXMetric | this_MINMetric_1= ruleMINMetric ) ;
    public final EObject ruleMetric() throws RecognitionException {
        EObject current = null;

        EObject this_MAXMetric_0 = null;

        EObject this_MINMetric_1 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:905:2: ( (this_MAXMetric_0= ruleMAXMetric | this_MINMetric_1= ruleMINMetric ) )
            // InternalAntiPattern.g:906:2: (this_MAXMetric_0= ruleMAXMetric | this_MINMetric_1= ruleMINMetric )
            {
            // InternalAntiPattern.g:906:2: (this_MAXMetric_0= ruleMAXMetric | this_MINMetric_1= ruleMINMetric )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( ((LA12_0>=26 && LA12_0<=29)) ) {
                alt12=1;
            }
            else if ( (LA12_0==30) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalAntiPattern.g:907:3: this_MAXMetric_0= ruleMAXMetric
                    {

                    			newCompositeNode(grammarAccess.getMetricAccess().getMAXMetricParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_MAXMetric_0=ruleMAXMetric();

                    state._fsp--;


                    			current = this_MAXMetric_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:916:3: this_MINMetric_1= ruleMINMetric
                    {

                    			newCompositeNode(grammarAccess.getMetricAccess().getMINMetricParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_MINMetric_1=ruleMINMetric();

                    state._fsp--;


                    			current = this_MINMetric_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMetric"


    // $ANTLR start "entryRuleMAXMetric"
    // InternalAntiPattern.g:928:1: entryRuleMAXMetric returns [EObject current=null] : iv_ruleMAXMetric= ruleMAXMetric EOF ;
    public final EObject entryRuleMAXMetric() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMAXMetric = null;


        try {
            // InternalAntiPattern.g:928:50: (iv_ruleMAXMetric= ruleMAXMetric EOF )
            // InternalAntiPattern.g:929:2: iv_ruleMAXMetric= ruleMAXMetric EOF
            {
             newCompositeNode(grammarAccess.getMAXMetricRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMAXMetric=ruleMAXMetric();

            state._fsp--;

             current =iv_ruleMAXMetric; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMAXMetric"


    // $ANTLR start "ruleMAXMetric"
    // InternalAntiPattern.g:935:1: ruleMAXMetric returns [EObject current=null] : ( ( (lv_metric_val_0_1= 'LOC' | lv_metric_val_0_2= 'CYC' | lv_metric_val_0_3= 'NOP' | lv_metric_val_0_4= 'DEPTHNESTING' ) ) ) ;
    public final EObject ruleMAXMetric() throws RecognitionException {
        EObject current = null;

        Token lv_metric_val_0_1=null;
        Token lv_metric_val_0_2=null;
        Token lv_metric_val_0_3=null;
        Token lv_metric_val_0_4=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:941:2: ( ( ( (lv_metric_val_0_1= 'LOC' | lv_metric_val_0_2= 'CYC' | lv_metric_val_0_3= 'NOP' | lv_metric_val_0_4= 'DEPTHNESTING' ) ) ) )
            // InternalAntiPattern.g:942:2: ( ( (lv_metric_val_0_1= 'LOC' | lv_metric_val_0_2= 'CYC' | lv_metric_val_0_3= 'NOP' | lv_metric_val_0_4= 'DEPTHNESTING' ) ) )
            {
            // InternalAntiPattern.g:942:2: ( ( (lv_metric_val_0_1= 'LOC' | lv_metric_val_0_2= 'CYC' | lv_metric_val_0_3= 'NOP' | lv_metric_val_0_4= 'DEPTHNESTING' ) ) )
            // InternalAntiPattern.g:943:3: ( (lv_metric_val_0_1= 'LOC' | lv_metric_val_0_2= 'CYC' | lv_metric_val_0_3= 'NOP' | lv_metric_val_0_4= 'DEPTHNESTING' ) )
            {
            // InternalAntiPattern.g:943:3: ( (lv_metric_val_0_1= 'LOC' | lv_metric_val_0_2= 'CYC' | lv_metric_val_0_3= 'NOP' | lv_metric_val_0_4= 'DEPTHNESTING' ) )
            // InternalAntiPattern.g:944:4: (lv_metric_val_0_1= 'LOC' | lv_metric_val_0_2= 'CYC' | lv_metric_val_0_3= 'NOP' | lv_metric_val_0_4= 'DEPTHNESTING' )
            {
            // InternalAntiPattern.g:944:4: (lv_metric_val_0_1= 'LOC' | lv_metric_val_0_2= 'CYC' | lv_metric_val_0_3= 'NOP' | lv_metric_val_0_4= 'DEPTHNESTING' )
            int alt13=4;
            switch ( input.LA(1) ) {
            case 26:
                {
                alt13=1;
                }
                break;
            case 27:
                {
                alt13=2;
                }
                break;
            case 28:
                {
                alt13=3;
                }
                break;
            case 29:
                {
                alt13=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalAntiPattern.g:945:5: lv_metric_val_0_1= 'LOC'
                    {
                    lv_metric_val_0_1=(Token)match(input,26,FOLLOW_2); 

                    					newLeafNode(lv_metric_val_0_1, grammarAccess.getMAXMetricAccess().getMetric_valLOCKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMAXMetricRule());
                    					}
                    					setWithLastConsumed(current, "metric_val", lv_metric_val_0_1, null);
                    				

                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:956:5: lv_metric_val_0_2= 'CYC'
                    {
                    lv_metric_val_0_2=(Token)match(input,27,FOLLOW_2); 

                    					newLeafNode(lv_metric_val_0_2, grammarAccess.getMAXMetricAccess().getMetric_valCYCKeyword_0_1());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMAXMetricRule());
                    					}
                    					setWithLastConsumed(current, "metric_val", lv_metric_val_0_2, null);
                    				

                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:967:5: lv_metric_val_0_3= 'NOP'
                    {
                    lv_metric_val_0_3=(Token)match(input,28,FOLLOW_2); 

                    					newLeafNode(lv_metric_val_0_3, grammarAccess.getMAXMetricAccess().getMetric_valNOPKeyword_0_2());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMAXMetricRule());
                    					}
                    					setWithLastConsumed(current, "metric_val", lv_metric_val_0_3, null);
                    				

                    }
                    break;
                case 4 :
                    // InternalAntiPattern.g:978:5: lv_metric_val_0_4= 'DEPTHNESTING'
                    {
                    lv_metric_val_0_4=(Token)match(input,29,FOLLOW_2); 

                    					newLeafNode(lv_metric_val_0_4, grammarAccess.getMAXMetricAccess().getMetric_valDEPTHNESTINGKeyword_0_3());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMAXMetricRule());
                    					}
                    					setWithLastConsumed(current, "metric_val", lv_metric_val_0_4, null);
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMAXMetric"


    // $ANTLR start "entryRuleMINMetric"
    // InternalAntiPattern.g:994:1: entryRuleMINMetric returns [EObject current=null] : iv_ruleMINMetric= ruleMINMetric EOF ;
    public final EObject entryRuleMINMetric() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMINMetric = null;


        try {
            // InternalAntiPattern.g:994:50: (iv_ruleMINMetric= ruleMINMetric EOF )
            // InternalAntiPattern.g:995:2: iv_ruleMINMetric= ruleMINMetric EOF
            {
             newCompositeNode(grammarAccess.getMINMetricRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMINMetric=ruleMINMetric();

            state._fsp--;

             current =iv_ruleMINMetric; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMINMetric"


    // $ANTLR start "ruleMINMetric"
    // InternalAntiPattern.g:1001:1: ruleMINMetric returns [EObject current=null] : ( (lv_metric_val_0_0= 'COH' ) ) ;
    public final EObject ruleMINMetric() throws RecognitionException {
        EObject current = null;

        Token lv_metric_val_0_0=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:1007:2: ( ( (lv_metric_val_0_0= 'COH' ) ) )
            // InternalAntiPattern.g:1008:2: ( (lv_metric_val_0_0= 'COH' ) )
            {
            // InternalAntiPattern.g:1008:2: ( (lv_metric_val_0_0= 'COH' ) )
            // InternalAntiPattern.g:1009:3: (lv_metric_val_0_0= 'COH' )
            {
            // InternalAntiPattern.g:1009:3: (lv_metric_val_0_0= 'COH' )
            // InternalAntiPattern.g:1010:4: lv_metric_val_0_0= 'COH'
            {
            lv_metric_val_0_0=(Token)match(input,30,FOLLOW_2); 

            				newLeafNode(lv_metric_val_0_0, grammarAccess.getMINMetricAccess().getMetric_valCOHKeyword_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getMINMetricRule());
            				}
            				setWithLastConsumed(current, "metric_val", lv_metric_val_0_0, "COH");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMINMetric"


    // $ANTLR start "entryRuleComparator"
    // InternalAntiPattern.g:1025:1: entryRuleComparator returns [EObject current=null] : iv_ruleComparator= ruleComparator EOF ;
    public final EObject entryRuleComparator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComparator = null;


        try {
            // InternalAntiPattern.g:1025:51: (iv_ruleComparator= ruleComparator EOF )
            // InternalAntiPattern.g:1026:2: iv_ruleComparator= ruleComparator EOF
            {
             newCompositeNode(grammarAccess.getComparatorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComparator=ruleComparator();

            state._fsp--;

             current =iv_ruleComparator; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComparator"


    // $ANTLR start "ruleComparator"
    // InternalAntiPattern.g:1032:1: ruleComparator returns [EObject current=null] : ( ( (lv_comp_0_1= 'EQUAL' | lv_comp_0_2= 'LESS' | lv_comp_0_3= 'LESS_EQUAL' | lv_comp_0_4= 'GREATER' | lv_comp_0_5= 'GREATER_EQUAL' ) ) ) ;
    public final EObject ruleComparator() throws RecognitionException {
        EObject current = null;

        Token lv_comp_0_1=null;
        Token lv_comp_0_2=null;
        Token lv_comp_0_3=null;
        Token lv_comp_0_4=null;
        Token lv_comp_0_5=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:1038:2: ( ( ( (lv_comp_0_1= 'EQUAL' | lv_comp_0_2= 'LESS' | lv_comp_0_3= 'LESS_EQUAL' | lv_comp_0_4= 'GREATER' | lv_comp_0_5= 'GREATER_EQUAL' ) ) ) )
            // InternalAntiPattern.g:1039:2: ( ( (lv_comp_0_1= 'EQUAL' | lv_comp_0_2= 'LESS' | lv_comp_0_3= 'LESS_EQUAL' | lv_comp_0_4= 'GREATER' | lv_comp_0_5= 'GREATER_EQUAL' ) ) )
            {
            // InternalAntiPattern.g:1039:2: ( ( (lv_comp_0_1= 'EQUAL' | lv_comp_0_2= 'LESS' | lv_comp_0_3= 'LESS_EQUAL' | lv_comp_0_4= 'GREATER' | lv_comp_0_5= 'GREATER_EQUAL' ) ) )
            // InternalAntiPattern.g:1040:3: ( (lv_comp_0_1= 'EQUAL' | lv_comp_0_2= 'LESS' | lv_comp_0_3= 'LESS_EQUAL' | lv_comp_0_4= 'GREATER' | lv_comp_0_5= 'GREATER_EQUAL' ) )
            {
            // InternalAntiPattern.g:1040:3: ( (lv_comp_0_1= 'EQUAL' | lv_comp_0_2= 'LESS' | lv_comp_0_3= 'LESS_EQUAL' | lv_comp_0_4= 'GREATER' | lv_comp_0_5= 'GREATER_EQUAL' ) )
            // InternalAntiPattern.g:1041:4: (lv_comp_0_1= 'EQUAL' | lv_comp_0_2= 'LESS' | lv_comp_0_3= 'LESS_EQUAL' | lv_comp_0_4= 'GREATER' | lv_comp_0_5= 'GREATER_EQUAL' )
            {
            // InternalAntiPattern.g:1041:4: (lv_comp_0_1= 'EQUAL' | lv_comp_0_2= 'LESS' | lv_comp_0_3= 'LESS_EQUAL' | lv_comp_0_4= 'GREATER' | lv_comp_0_5= 'GREATER_EQUAL' )
            int alt14=5;
            switch ( input.LA(1) ) {
            case 31:
                {
                alt14=1;
                }
                break;
            case 32:
                {
                alt14=2;
                }
                break;
            case 33:
                {
                alt14=3;
                }
                break;
            case 34:
                {
                alt14=4;
                }
                break;
            case 35:
                {
                alt14=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }

            switch (alt14) {
                case 1 :
                    // InternalAntiPattern.g:1042:5: lv_comp_0_1= 'EQUAL'
                    {
                    lv_comp_0_1=(Token)match(input,31,FOLLOW_2); 

                    					newLeafNode(lv_comp_0_1, grammarAccess.getComparatorAccess().getCompEQUALKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getComparatorRule());
                    					}
                    					setWithLastConsumed(current, "comp", lv_comp_0_1, null);
                    				

                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:1053:5: lv_comp_0_2= 'LESS'
                    {
                    lv_comp_0_2=(Token)match(input,32,FOLLOW_2); 

                    					newLeafNode(lv_comp_0_2, grammarAccess.getComparatorAccess().getCompLESSKeyword_0_1());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getComparatorRule());
                    					}
                    					setWithLastConsumed(current, "comp", lv_comp_0_2, null);
                    				

                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:1064:5: lv_comp_0_3= 'LESS_EQUAL'
                    {
                    lv_comp_0_3=(Token)match(input,33,FOLLOW_2); 

                    					newLeafNode(lv_comp_0_3, grammarAccess.getComparatorAccess().getCompLESS_EQUALKeyword_0_2());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getComparatorRule());
                    					}
                    					setWithLastConsumed(current, "comp", lv_comp_0_3, null);
                    				

                    }
                    break;
                case 4 :
                    // InternalAntiPattern.g:1075:5: lv_comp_0_4= 'GREATER'
                    {
                    lv_comp_0_4=(Token)match(input,34,FOLLOW_2); 

                    					newLeafNode(lv_comp_0_4, grammarAccess.getComparatorAccess().getCompGREATERKeyword_0_3());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getComparatorRule());
                    					}
                    					setWithLastConsumed(current, "comp", lv_comp_0_4, null);
                    				

                    }
                    break;
                case 5 :
                    // InternalAntiPattern.g:1086:5: lv_comp_0_5= 'GREATER_EQUAL'
                    {
                    lv_comp_0_5=(Token)match(input,35,FOLLOW_2); 

                    					newLeafNode(lv_comp_0_5, grammarAccess.getComparatorAccess().getCompGREATER_EQUALKeyword_0_4());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getComparatorRule());
                    					}
                    					setWithLastConsumed(current, "comp", lv_comp_0_5, null);
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparator"


    // $ANTLR start "entryRuleConvention"
    // InternalAntiPattern.g:1102:1: entryRuleConvention returns [EObject current=null] : iv_ruleConvention= ruleConvention EOF ;
    public final EObject entryRuleConvention() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConvention = null;


        try {
            // InternalAntiPattern.g:1102:51: (iv_ruleConvention= ruleConvention EOF )
            // InternalAntiPattern.g:1103:2: iv_ruleConvention= ruleConvention EOF
            {
             newCompositeNode(grammarAccess.getConventionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConvention=ruleConvention();

            state._fsp--;

             current =iv_ruleConvention; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConvention"


    // $ANTLR start "ruleConvention"
    // InternalAntiPattern.g:1109:1: ruleConvention returns [EObject current=null] : ( ( (lv_c_0_1= 'NAMING_CONVENTION' | lv_c_0_2= 'Consistent_Parameter_Naming' | lv_c_0_3= 'Single_Responsibility_Principle' | lv_c_0_4= 'Use_of_Comments' | lv_c_0_5= 'Avoid_Magic_Numbers' ) ) ) ;
    public final EObject ruleConvention() throws RecognitionException {
        EObject current = null;

        Token lv_c_0_1=null;
        Token lv_c_0_2=null;
        Token lv_c_0_3=null;
        Token lv_c_0_4=null;
        Token lv_c_0_5=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:1115:2: ( ( ( (lv_c_0_1= 'NAMING_CONVENTION' | lv_c_0_2= 'Consistent_Parameter_Naming' | lv_c_0_3= 'Single_Responsibility_Principle' | lv_c_0_4= 'Use_of_Comments' | lv_c_0_5= 'Avoid_Magic_Numbers' ) ) ) )
            // InternalAntiPattern.g:1116:2: ( ( (lv_c_0_1= 'NAMING_CONVENTION' | lv_c_0_2= 'Consistent_Parameter_Naming' | lv_c_0_3= 'Single_Responsibility_Principle' | lv_c_0_4= 'Use_of_Comments' | lv_c_0_5= 'Avoid_Magic_Numbers' ) ) )
            {
            // InternalAntiPattern.g:1116:2: ( ( (lv_c_0_1= 'NAMING_CONVENTION' | lv_c_0_2= 'Consistent_Parameter_Naming' | lv_c_0_3= 'Single_Responsibility_Principle' | lv_c_0_4= 'Use_of_Comments' | lv_c_0_5= 'Avoid_Magic_Numbers' ) ) )
            // InternalAntiPattern.g:1117:3: ( (lv_c_0_1= 'NAMING_CONVENTION' | lv_c_0_2= 'Consistent_Parameter_Naming' | lv_c_0_3= 'Single_Responsibility_Principle' | lv_c_0_4= 'Use_of_Comments' | lv_c_0_5= 'Avoid_Magic_Numbers' ) )
            {
            // InternalAntiPattern.g:1117:3: ( (lv_c_0_1= 'NAMING_CONVENTION' | lv_c_0_2= 'Consistent_Parameter_Naming' | lv_c_0_3= 'Single_Responsibility_Principle' | lv_c_0_4= 'Use_of_Comments' | lv_c_0_5= 'Avoid_Magic_Numbers' ) )
            // InternalAntiPattern.g:1118:4: (lv_c_0_1= 'NAMING_CONVENTION' | lv_c_0_2= 'Consistent_Parameter_Naming' | lv_c_0_3= 'Single_Responsibility_Principle' | lv_c_0_4= 'Use_of_Comments' | lv_c_0_5= 'Avoid_Magic_Numbers' )
            {
            // InternalAntiPattern.g:1118:4: (lv_c_0_1= 'NAMING_CONVENTION' | lv_c_0_2= 'Consistent_Parameter_Naming' | lv_c_0_3= 'Single_Responsibility_Principle' | lv_c_0_4= 'Use_of_Comments' | lv_c_0_5= 'Avoid_Magic_Numbers' )
            int alt15=5;
            switch ( input.LA(1) ) {
            case 36:
                {
                alt15=1;
                }
                break;
            case 37:
                {
                alt15=2;
                }
                break;
            case 38:
                {
                alt15=3;
                }
                break;
            case 39:
                {
                alt15=4;
                }
                break;
            case 40:
                {
                alt15=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalAntiPattern.g:1119:5: lv_c_0_1= 'NAMING_CONVENTION'
                    {
                    lv_c_0_1=(Token)match(input,36,FOLLOW_2); 

                    					newLeafNode(lv_c_0_1, grammarAccess.getConventionAccess().getCNAMING_CONVENTIONKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getConventionRule());
                    					}
                    					setWithLastConsumed(current, "c", lv_c_0_1, null);
                    				

                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:1130:5: lv_c_0_2= 'Consistent_Parameter_Naming'
                    {
                    lv_c_0_2=(Token)match(input,37,FOLLOW_2); 

                    					newLeafNode(lv_c_0_2, grammarAccess.getConventionAccess().getCConsistent_Parameter_NamingKeyword_0_1());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getConventionRule());
                    					}
                    					setWithLastConsumed(current, "c", lv_c_0_2, null);
                    				

                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:1141:5: lv_c_0_3= 'Single_Responsibility_Principle'
                    {
                    lv_c_0_3=(Token)match(input,38,FOLLOW_2); 

                    					newLeafNode(lv_c_0_3, grammarAccess.getConventionAccess().getCSingle_Responsibility_PrincipleKeyword_0_2());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getConventionRule());
                    					}
                    					setWithLastConsumed(current, "c", lv_c_0_3, null);
                    				

                    }
                    break;
                case 4 :
                    // InternalAntiPattern.g:1152:5: lv_c_0_4= 'Use_of_Comments'
                    {
                    lv_c_0_4=(Token)match(input,39,FOLLOW_2); 

                    					newLeafNode(lv_c_0_4, grammarAccess.getConventionAccess().getCUse_of_CommentsKeyword_0_3());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getConventionRule());
                    					}
                    					setWithLastConsumed(current, "c", lv_c_0_4, null);
                    				

                    }
                    break;
                case 5 :
                    // InternalAntiPattern.g:1163:5: lv_c_0_5= 'Avoid_Magic_Numbers'
                    {
                    lv_c_0_5=(Token)match(input,40,FOLLOW_2); 

                    					newLeafNode(lv_c_0_5, grammarAccess.getConventionAccess().getCAvoid_Magic_NumbersKeyword_0_4());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getConventionRule());
                    					}
                    					setWithLastConsumed(current, "c", lv_c_0_5, null);
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConvention"


    // $ANTLR start "entryRuleQunatity"
    // InternalAntiPattern.g:1179:1: entryRuleQunatity returns [EObject current=null] : iv_ruleQunatity= ruleQunatity EOF ;
    public final EObject entryRuleQunatity() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQunatity = null;


        try {
            // InternalAntiPattern.g:1179:49: (iv_ruleQunatity= ruleQunatity EOF )
            // InternalAntiPattern.g:1180:2: iv_ruleQunatity= ruleQunatity EOF
            {
             newCompositeNode(grammarAccess.getQunatityRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQunatity=ruleQunatity();

            state._fsp--;

             current =iv_ruleQunatity; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQunatity"


    // $ANTLR start "ruleQunatity"
    // InternalAntiPattern.g:1186:1: ruleQunatity returns [EObject current=null] : ( ( (lv_q_0_1= 'many' | lv_q_0_2= 'few' ) ) ) ;
    public final EObject ruleQunatity() throws RecognitionException {
        EObject current = null;

        Token lv_q_0_1=null;
        Token lv_q_0_2=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:1192:2: ( ( ( (lv_q_0_1= 'many' | lv_q_0_2= 'few' ) ) ) )
            // InternalAntiPattern.g:1193:2: ( ( (lv_q_0_1= 'many' | lv_q_0_2= 'few' ) ) )
            {
            // InternalAntiPattern.g:1193:2: ( ( (lv_q_0_1= 'many' | lv_q_0_2= 'few' ) ) )
            // InternalAntiPattern.g:1194:3: ( (lv_q_0_1= 'many' | lv_q_0_2= 'few' ) )
            {
            // InternalAntiPattern.g:1194:3: ( (lv_q_0_1= 'many' | lv_q_0_2= 'few' ) )
            // InternalAntiPattern.g:1195:4: (lv_q_0_1= 'many' | lv_q_0_2= 'few' )
            {
            // InternalAntiPattern.g:1195:4: (lv_q_0_1= 'many' | lv_q_0_2= 'few' )
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==41) ) {
                alt16=1;
            }
            else if ( (LA16_0==42) ) {
                alt16=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // InternalAntiPattern.g:1196:5: lv_q_0_1= 'many'
                    {
                    lv_q_0_1=(Token)match(input,41,FOLLOW_2); 

                    					newLeafNode(lv_q_0_1, grammarAccess.getQunatityAccess().getQManyKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getQunatityRule());
                    					}
                    					setWithLastConsumed(current, "q", lv_q_0_1, null);
                    				

                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:1207:5: lv_q_0_2= 'few'
                    {
                    lv_q_0_2=(Token)match(input,42,FOLLOW_2); 

                    					newLeafNode(lv_q_0_2, grammarAccess.getQunatityAccess().getQFewKeyword_0_1());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getQunatityRule());
                    					}
                    					setWithLastConsumed(current, "q", lv_q_0_2, null);
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQunatity"


    // $ANTLR start "entryRuleManner"
    // InternalAntiPattern.g:1223:1: entryRuleManner returns [EObject current=null] : iv_ruleManner= ruleManner EOF ;
    public final EObject entryRuleManner() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleManner = null;


        try {
            // InternalAntiPattern.g:1223:47: (iv_ruleManner= ruleManner EOF )
            // InternalAntiPattern.g:1224:2: iv_ruleManner= ruleManner EOF
            {
             newCompositeNode(grammarAccess.getMannerRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleManner=ruleManner();

            state._fsp--;

             current =iv_ruleManner; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleManner"


    // $ANTLR start "ruleManner"
    // InternalAntiPattern.g:1230:1: ruleManner returns [EObject current=null] : ( ( (lv_manner_0_1= 'Complex_Logical_Expressions' | lv_manner_0_2= 'ifNestedStructures' | lv_manner_0_3= 'switchNestedStructures' | lv_manner_0_4= 'loopNestedStructures' | lv_manner_0_5= 'ExecutableStatments' | lv_manner_0_6= 'Declare_Variables_Separately' | lv_manner_0_7= 'Add_Comments' | lv_manner_0_8= 'Exception_Handling' | lv_manner_0_9= 'Use_Recursion' | lv_manner_0_10= 'Use_Global_Variables' | lv_manner_0_11= 'unrelatedFonctionnalities' ) ) ) ;
    public final EObject ruleManner() throws RecognitionException {
        EObject current = null;

        Token lv_manner_0_1=null;
        Token lv_manner_0_2=null;
        Token lv_manner_0_3=null;
        Token lv_manner_0_4=null;
        Token lv_manner_0_5=null;
        Token lv_manner_0_6=null;
        Token lv_manner_0_7=null;
        Token lv_manner_0_8=null;
        Token lv_manner_0_9=null;
        Token lv_manner_0_10=null;
        Token lv_manner_0_11=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:1236:2: ( ( ( (lv_manner_0_1= 'Complex_Logical_Expressions' | lv_manner_0_2= 'ifNestedStructures' | lv_manner_0_3= 'switchNestedStructures' | lv_manner_0_4= 'loopNestedStructures' | lv_manner_0_5= 'ExecutableStatments' | lv_manner_0_6= 'Declare_Variables_Separately' | lv_manner_0_7= 'Add_Comments' | lv_manner_0_8= 'Exception_Handling' | lv_manner_0_9= 'Use_Recursion' | lv_manner_0_10= 'Use_Global_Variables' | lv_manner_0_11= 'unrelatedFonctionnalities' ) ) ) )
            // InternalAntiPattern.g:1237:2: ( ( (lv_manner_0_1= 'Complex_Logical_Expressions' | lv_manner_0_2= 'ifNestedStructures' | lv_manner_0_3= 'switchNestedStructures' | lv_manner_0_4= 'loopNestedStructures' | lv_manner_0_5= 'ExecutableStatments' | lv_manner_0_6= 'Declare_Variables_Separately' | lv_manner_0_7= 'Add_Comments' | lv_manner_0_8= 'Exception_Handling' | lv_manner_0_9= 'Use_Recursion' | lv_manner_0_10= 'Use_Global_Variables' | lv_manner_0_11= 'unrelatedFonctionnalities' ) ) )
            {
            // InternalAntiPattern.g:1237:2: ( ( (lv_manner_0_1= 'Complex_Logical_Expressions' | lv_manner_0_2= 'ifNestedStructures' | lv_manner_0_3= 'switchNestedStructures' | lv_manner_0_4= 'loopNestedStructures' | lv_manner_0_5= 'ExecutableStatments' | lv_manner_0_6= 'Declare_Variables_Separately' | lv_manner_0_7= 'Add_Comments' | lv_manner_0_8= 'Exception_Handling' | lv_manner_0_9= 'Use_Recursion' | lv_manner_0_10= 'Use_Global_Variables' | lv_manner_0_11= 'unrelatedFonctionnalities' ) ) )
            // InternalAntiPattern.g:1238:3: ( (lv_manner_0_1= 'Complex_Logical_Expressions' | lv_manner_0_2= 'ifNestedStructures' | lv_manner_0_3= 'switchNestedStructures' | lv_manner_0_4= 'loopNestedStructures' | lv_manner_0_5= 'ExecutableStatments' | lv_manner_0_6= 'Declare_Variables_Separately' | lv_manner_0_7= 'Add_Comments' | lv_manner_0_8= 'Exception_Handling' | lv_manner_0_9= 'Use_Recursion' | lv_manner_0_10= 'Use_Global_Variables' | lv_manner_0_11= 'unrelatedFonctionnalities' ) )
            {
            // InternalAntiPattern.g:1238:3: ( (lv_manner_0_1= 'Complex_Logical_Expressions' | lv_manner_0_2= 'ifNestedStructures' | lv_manner_0_3= 'switchNestedStructures' | lv_manner_0_4= 'loopNestedStructures' | lv_manner_0_5= 'ExecutableStatments' | lv_manner_0_6= 'Declare_Variables_Separately' | lv_manner_0_7= 'Add_Comments' | lv_manner_0_8= 'Exception_Handling' | lv_manner_0_9= 'Use_Recursion' | lv_manner_0_10= 'Use_Global_Variables' | lv_manner_0_11= 'unrelatedFonctionnalities' ) )
            // InternalAntiPattern.g:1239:4: (lv_manner_0_1= 'Complex_Logical_Expressions' | lv_manner_0_2= 'ifNestedStructures' | lv_manner_0_3= 'switchNestedStructures' | lv_manner_0_4= 'loopNestedStructures' | lv_manner_0_5= 'ExecutableStatments' | lv_manner_0_6= 'Declare_Variables_Separately' | lv_manner_0_7= 'Add_Comments' | lv_manner_0_8= 'Exception_Handling' | lv_manner_0_9= 'Use_Recursion' | lv_manner_0_10= 'Use_Global_Variables' | lv_manner_0_11= 'unrelatedFonctionnalities' )
            {
            // InternalAntiPattern.g:1239:4: (lv_manner_0_1= 'Complex_Logical_Expressions' | lv_manner_0_2= 'ifNestedStructures' | lv_manner_0_3= 'switchNestedStructures' | lv_manner_0_4= 'loopNestedStructures' | lv_manner_0_5= 'ExecutableStatments' | lv_manner_0_6= 'Declare_Variables_Separately' | lv_manner_0_7= 'Add_Comments' | lv_manner_0_8= 'Exception_Handling' | lv_manner_0_9= 'Use_Recursion' | lv_manner_0_10= 'Use_Global_Variables' | lv_manner_0_11= 'unrelatedFonctionnalities' )
            int alt17=11;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt17=1;
                }
                break;
            case 44:
                {
                alt17=2;
                }
                break;
            case 45:
                {
                alt17=3;
                }
                break;
            case 46:
                {
                alt17=4;
                }
                break;
            case 47:
                {
                alt17=5;
                }
                break;
            case 48:
                {
                alt17=6;
                }
                break;
            case 49:
                {
                alt17=7;
                }
                break;
            case 50:
                {
                alt17=8;
                }
                break;
            case 51:
                {
                alt17=9;
                }
                break;
            case 52:
                {
                alt17=10;
                }
                break;
            case 53:
                {
                alt17=11;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalAntiPattern.g:1240:5: lv_manner_0_1= 'Complex_Logical_Expressions'
                    {
                    lv_manner_0_1=(Token)match(input,43,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_1, grammarAccess.getMannerAccess().getMannerComplex_Logical_ExpressionsKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_1, null);
                    				

                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:1251:5: lv_manner_0_2= 'ifNestedStructures'
                    {
                    lv_manner_0_2=(Token)match(input,44,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_2, grammarAccess.getMannerAccess().getMannerIfNestedStructuresKeyword_0_1());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_2, null);
                    				

                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:1262:5: lv_manner_0_3= 'switchNestedStructures'
                    {
                    lv_manner_0_3=(Token)match(input,45,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_3, grammarAccess.getMannerAccess().getMannerSwitchNestedStructuresKeyword_0_2());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_3, null);
                    				

                    }
                    break;
                case 4 :
                    // InternalAntiPattern.g:1273:5: lv_manner_0_4= 'loopNestedStructures'
                    {
                    lv_manner_0_4=(Token)match(input,46,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_4, grammarAccess.getMannerAccess().getMannerLoopNestedStructuresKeyword_0_3());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_4, null);
                    				

                    }
                    break;
                case 5 :
                    // InternalAntiPattern.g:1284:5: lv_manner_0_5= 'ExecutableStatments'
                    {
                    lv_manner_0_5=(Token)match(input,47,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_5, grammarAccess.getMannerAccess().getMannerExecutableStatmentsKeyword_0_4());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_5, null);
                    				

                    }
                    break;
                case 6 :
                    // InternalAntiPattern.g:1295:5: lv_manner_0_6= 'Declare_Variables_Separately'
                    {
                    lv_manner_0_6=(Token)match(input,48,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_6, grammarAccess.getMannerAccess().getMannerDeclare_Variables_SeparatelyKeyword_0_5());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_6, null);
                    				

                    }
                    break;
                case 7 :
                    // InternalAntiPattern.g:1306:5: lv_manner_0_7= 'Add_Comments'
                    {
                    lv_manner_0_7=(Token)match(input,49,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_7, grammarAccess.getMannerAccess().getMannerAdd_CommentsKeyword_0_6());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_7, null);
                    				

                    }
                    break;
                case 8 :
                    // InternalAntiPattern.g:1317:5: lv_manner_0_8= 'Exception_Handling'
                    {
                    lv_manner_0_8=(Token)match(input,50,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_8, grammarAccess.getMannerAccess().getMannerException_HandlingKeyword_0_7());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_8, null);
                    				

                    }
                    break;
                case 9 :
                    // InternalAntiPattern.g:1328:5: lv_manner_0_9= 'Use_Recursion'
                    {
                    lv_manner_0_9=(Token)match(input,51,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_9, grammarAccess.getMannerAccess().getMannerUse_RecursionKeyword_0_8());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_9, null);
                    				

                    }
                    break;
                case 10 :
                    // InternalAntiPattern.g:1339:5: lv_manner_0_10= 'Use_Global_Variables'
                    {
                    lv_manner_0_10=(Token)match(input,52,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_10, grammarAccess.getMannerAccess().getMannerUse_Global_VariablesKeyword_0_9());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_10, null);
                    				

                    }
                    break;
                case 11 :
                    // InternalAntiPattern.g:1350:5: lv_manner_0_11= 'unrelatedFonctionnalities'
                    {
                    lv_manner_0_11=(Token)match(input,53,FOLLOW_2); 

                    					newLeafNode(lv_manner_0_11, grammarAccess.getMannerAccess().getMannerUnrelatedFonctionnalitiesKeyword_0_10());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getMannerRule());
                    					}
                    					setWithLastConsumed(current, "manner", lv_manner_0_11, null);
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleManner"


    // $ANTLR start "entryRuleInterCarachteristic"
    // InternalAntiPattern.g:1366:1: entryRuleInterCarachteristic returns [EObject current=null] : iv_ruleInterCarachteristic= ruleInterCarachteristic EOF ;
    public final EObject entryRuleInterCarachteristic() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInterCarachteristic = null;


        try {
            // InternalAntiPattern.g:1366:60: (iv_ruleInterCarachteristic= ruleInterCarachteristic EOF )
            // InternalAntiPattern.g:1367:2: iv_ruleInterCarachteristic= ruleInterCarachteristic EOF
            {
             newCompositeNode(grammarAccess.getInterCarachteristicRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInterCarachteristic=ruleInterCarachteristic();

            state._fsp--;

             current =iv_ruleInterCarachteristic; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInterCarachteristic"


    // $ANTLR start "ruleInterCarachteristic"
    // InternalAntiPattern.g:1373:1: ruleInterCarachteristic returns [EObject current=null] : ( ( (lv_e_0_0= 'ATTRIBUTE_USE' ) ) otherlv_1= '(' ( (lv_p_2_0= ruleParam ) ) (otherlv_3= ',' ( (lv_p_4_0= ruleParam ) ) )* otherlv_5= ')' ( (lv_comparator_6_0= ruleComparator ) ) ( (lv_value_7_0= ruleNUMERIC_VALUE ) ) ) ;
    public final EObject ruleInterCarachteristic() throws RecognitionException {
        EObject current = null;

        Token lv_e_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_p_2_0 = null;

        EObject lv_p_4_0 = null;

        EObject lv_comparator_6_0 = null;

        AntlrDatatypeRuleToken lv_value_7_0 = null;



        	enterRule();

        try {
            // InternalAntiPattern.g:1379:2: ( ( ( (lv_e_0_0= 'ATTRIBUTE_USE' ) ) otherlv_1= '(' ( (lv_p_2_0= ruleParam ) ) (otherlv_3= ',' ( (lv_p_4_0= ruleParam ) ) )* otherlv_5= ')' ( (lv_comparator_6_0= ruleComparator ) ) ( (lv_value_7_0= ruleNUMERIC_VALUE ) ) ) )
            // InternalAntiPattern.g:1380:2: ( ( (lv_e_0_0= 'ATTRIBUTE_USE' ) ) otherlv_1= '(' ( (lv_p_2_0= ruleParam ) ) (otherlv_3= ',' ( (lv_p_4_0= ruleParam ) ) )* otherlv_5= ')' ( (lv_comparator_6_0= ruleComparator ) ) ( (lv_value_7_0= ruleNUMERIC_VALUE ) ) )
            {
            // InternalAntiPattern.g:1380:2: ( ( (lv_e_0_0= 'ATTRIBUTE_USE' ) ) otherlv_1= '(' ( (lv_p_2_0= ruleParam ) ) (otherlv_3= ',' ( (lv_p_4_0= ruleParam ) ) )* otherlv_5= ')' ( (lv_comparator_6_0= ruleComparator ) ) ( (lv_value_7_0= ruleNUMERIC_VALUE ) ) )
            // InternalAntiPattern.g:1381:3: ( (lv_e_0_0= 'ATTRIBUTE_USE' ) ) otherlv_1= '(' ( (lv_p_2_0= ruleParam ) ) (otherlv_3= ',' ( (lv_p_4_0= ruleParam ) ) )* otherlv_5= ')' ( (lv_comparator_6_0= ruleComparator ) ) ( (lv_value_7_0= ruleNUMERIC_VALUE ) )
            {
            // InternalAntiPattern.g:1381:3: ( (lv_e_0_0= 'ATTRIBUTE_USE' ) )
            // InternalAntiPattern.g:1382:4: (lv_e_0_0= 'ATTRIBUTE_USE' )
            {
            // InternalAntiPattern.g:1382:4: (lv_e_0_0= 'ATTRIBUTE_USE' )
            // InternalAntiPattern.g:1383:5: lv_e_0_0= 'ATTRIBUTE_USE'
            {
            lv_e_0_0=(Token)match(input,54,FOLLOW_16); 

            					newLeafNode(lv_e_0_0, grammarAccess.getInterCarachteristicAccess().getEATTRIBUTE_USEKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInterCarachteristicRule());
            					}
            					setWithLastConsumed(current, "e", lv_e_0_0, "ATTRIBUTE_USE");
            				

            }


            }

            otherlv_1=(Token)match(input,20,FOLLOW_25); 

            			newLeafNode(otherlv_1, grammarAccess.getInterCarachteristicAccess().getLeftParenthesisKeyword_1());
            		
            // InternalAntiPattern.g:1399:3: ( (lv_p_2_0= ruleParam ) )
            // InternalAntiPattern.g:1400:4: (lv_p_2_0= ruleParam )
            {
            // InternalAntiPattern.g:1400:4: (lv_p_2_0= ruleParam )
            // InternalAntiPattern.g:1401:5: lv_p_2_0= ruleParam
            {

            					newCompositeNode(grammarAccess.getInterCarachteristicAccess().getPParamParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_23);
            lv_p_2_0=ruleParam();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInterCarachteristicRule());
            					}
            					add(
            						current,
            						"p",
            						lv_p_2_0,
            						"org.xtext.example.antipattern.AntiPattern.Param");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAntiPattern.g:1418:3: (otherlv_3= ',' ( (lv_p_4_0= ruleParam ) ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==21) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalAntiPattern.g:1419:4: otherlv_3= ',' ( (lv_p_4_0= ruleParam ) )
            	    {
            	    otherlv_3=(Token)match(input,21,FOLLOW_25); 

            	    				newLeafNode(otherlv_3, grammarAccess.getInterCarachteristicAccess().getCommaKeyword_3_0());
            	    			
            	    // InternalAntiPattern.g:1423:4: ( (lv_p_4_0= ruleParam ) )
            	    // InternalAntiPattern.g:1424:5: (lv_p_4_0= ruleParam )
            	    {
            	    // InternalAntiPattern.g:1424:5: (lv_p_4_0= ruleParam )
            	    // InternalAntiPattern.g:1425:6: lv_p_4_0= ruleParam
            	    {

            	    						newCompositeNode(grammarAccess.getInterCarachteristicAccess().getPParamParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_23);
            	    lv_p_4_0=ruleParam();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getInterCarachteristicRule());
            	    						}
            	    						add(
            	    							current,
            	    							"p",
            	    							lv_p_4_0,
            	    							"org.xtext.example.antipattern.AntiPattern.Param");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            otherlv_5=(Token)match(input,22,FOLLOW_19); 

            			newLeafNode(otherlv_5, grammarAccess.getInterCarachteristicAccess().getRightParenthesisKeyword_4());
            		
            // InternalAntiPattern.g:1447:3: ( (lv_comparator_6_0= ruleComparator ) )
            // InternalAntiPattern.g:1448:4: (lv_comparator_6_0= ruleComparator )
            {
            // InternalAntiPattern.g:1448:4: (lv_comparator_6_0= ruleComparator )
            // InternalAntiPattern.g:1449:5: lv_comparator_6_0= ruleComparator
            {

            					newCompositeNode(grammarAccess.getInterCarachteristicAccess().getComparatorComparatorParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_10);
            lv_comparator_6_0=ruleComparator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInterCarachteristicRule());
            					}
            					set(
            						current,
            						"comparator",
            						lv_comparator_6_0,
            						"org.xtext.example.antipattern.AntiPattern.Comparator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAntiPattern.g:1466:3: ( (lv_value_7_0= ruleNUMERIC_VALUE ) )
            // InternalAntiPattern.g:1467:4: (lv_value_7_0= ruleNUMERIC_VALUE )
            {
            // InternalAntiPattern.g:1467:4: (lv_value_7_0= ruleNUMERIC_VALUE )
            // InternalAntiPattern.g:1468:5: lv_value_7_0= ruleNUMERIC_VALUE
            {

            					newCompositeNode(grammarAccess.getInterCarachteristicAccess().getValueNUMERIC_VALUEParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_2);
            lv_value_7_0=ruleNUMERIC_VALUE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInterCarachteristicRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_7_0,
            						"org.xtext.example.antipattern.AntiPattern.NUMERIC_VALUE");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInterCarachteristic"


    // $ANTLR start "entryRuleParam"
    // InternalAntiPattern.g:1489:1: entryRuleParam returns [EObject current=null] : iv_ruleParam= ruleParam EOF ;
    public final EObject entryRuleParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleParam = null;


        try {
            // InternalAntiPattern.g:1489:46: (iv_ruleParam= ruleParam EOF )
            // InternalAntiPattern.g:1490:2: iv_ruleParam= ruleParam EOF
            {
             newCompositeNode(grammarAccess.getParamRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleParam=ruleParam();

            state._fsp--;

             current =iv_ruleParam; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleParam"


    // $ANTLR start "ruleParam"
    // InternalAntiPattern.g:1496:1: ruleParam returns [EObject current=null] : ( ( (lv_p_0_1= 'method' | lv_p_0_2= 'otherClass' | lv_p_0_3= 'ownClass' ) ) ) ;
    public final EObject ruleParam() throws RecognitionException {
        EObject current = null;

        Token lv_p_0_1=null;
        Token lv_p_0_2=null;
        Token lv_p_0_3=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:1502:2: ( ( ( (lv_p_0_1= 'method' | lv_p_0_2= 'otherClass' | lv_p_0_3= 'ownClass' ) ) ) )
            // InternalAntiPattern.g:1503:2: ( ( (lv_p_0_1= 'method' | lv_p_0_2= 'otherClass' | lv_p_0_3= 'ownClass' ) ) )
            {
            // InternalAntiPattern.g:1503:2: ( ( (lv_p_0_1= 'method' | lv_p_0_2= 'otherClass' | lv_p_0_3= 'ownClass' ) ) )
            // InternalAntiPattern.g:1504:3: ( (lv_p_0_1= 'method' | lv_p_0_2= 'otherClass' | lv_p_0_3= 'ownClass' ) )
            {
            // InternalAntiPattern.g:1504:3: ( (lv_p_0_1= 'method' | lv_p_0_2= 'otherClass' | lv_p_0_3= 'ownClass' ) )
            // InternalAntiPattern.g:1505:4: (lv_p_0_1= 'method' | lv_p_0_2= 'otherClass' | lv_p_0_3= 'ownClass' )
            {
            // InternalAntiPattern.g:1505:4: (lv_p_0_1= 'method' | lv_p_0_2= 'otherClass' | lv_p_0_3= 'ownClass' )
            int alt19=3;
            switch ( input.LA(1) ) {
            case 55:
                {
                alt19=1;
                }
                break;
            case 56:
                {
                alt19=2;
                }
                break;
            case 57:
                {
                alt19=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // InternalAntiPattern.g:1506:5: lv_p_0_1= 'method'
                    {
                    lv_p_0_1=(Token)match(input,55,FOLLOW_2); 

                    					newLeafNode(lv_p_0_1, grammarAccess.getParamAccess().getPMethodKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getParamRule());
                    					}
                    					setWithLastConsumed(current, "p", lv_p_0_1, null);
                    				

                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:1517:5: lv_p_0_2= 'otherClass'
                    {
                    lv_p_0_2=(Token)match(input,56,FOLLOW_2); 

                    					newLeafNode(lv_p_0_2, grammarAccess.getParamAccess().getPOtherClassKeyword_0_1());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getParamRule());
                    					}
                    					setWithLastConsumed(current, "p", lv_p_0_2, null);
                    				

                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:1528:5: lv_p_0_3= 'ownClass'
                    {
                    lv_p_0_3=(Token)match(input,57,FOLLOW_2); 

                    					newLeafNode(lv_p_0_3, grammarAccess.getParamAccess().getPOwnClassKeyword_0_2());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getParamRule());
                    					}
                    					setWithLastConsumed(current, "p", lv_p_0_3, null);
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleParam"


    // $ANTLR start "entryRuleNUMERIC_VALUE"
    // InternalAntiPattern.g:1544:1: entryRuleNUMERIC_VALUE returns [String current=null] : iv_ruleNUMERIC_VALUE= ruleNUMERIC_VALUE EOF ;
    public final String entryRuleNUMERIC_VALUE() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNUMERIC_VALUE = null;


        try {
            // InternalAntiPattern.g:1544:53: (iv_ruleNUMERIC_VALUE= ruleNUMERIC_VALUE EOF )
            // InternalAntiPattern.g:1545:2: iv_ruleNUMERIC_VALUE= ruleNUMERIC_VALUE EOF
            {
             newCompositeNode(grammarAccess.getNUMERIC_VALUERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNUMERIC_VALUE=ruleNUMERIC_VALUE();

            state._fsp--;

             current =iv_ruleNUMERIC_VALUE.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNUMERIC_VALUE"


    // $ANTLR start "ruleNUMERIC_VALUE"
    // InternalAntiPattern.g:1551:1: ruleNUMERIC_VALUE returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (this_INT_0= RULE_INT kw= '/' this_INT_2= RULE_INT ) | this_INT_3= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleNUMERIC_VALUE() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;
        Token kw=null;
        Token this_INT_2=null;
        Token this_INT_3=null;


        	enterRule();

        try {
            // InternalAntiPattern.g:1557:2: ( ( (this_INT_0= RULE_INT kw= '/' this_INT_2= RULE_INT ) | this_INT_3= RULE_INT ) )
            // InternalAntiPattern.g:1558:2: ( (this_INT_0= RULE_INT kw= '/' this_INT_2= RULE_INT ) | this_INT_3= RULE_INT )
            {
            // InternalAntiPattern.g:1558:2: ( (this_INT_0= RULE_INT kw= '/' this_INT_2= RULE_INT ) | this_INT_3= RULE_INT )
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==RULE_INT) ) {
                int LA20_1 = input.LA(2);

                if ( (LA20_1==58) ) {
                    alt20=1;
                }
                else if ( (LA20_1==EOF||LA20_1==13||(LA20_1>=20 && LA20_1<=23)) ) {
                    alt20=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 20, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // InternalAntiPattern.g:1559:3: (this_INT_0= RULE_INT kw= '/' this_INT_2= RULE_INT )
                    {
                    // InternalAntiPattern.g:1559:3: (this_INT_0= RULE_INT kw= '/' this_INT_2= RULE_INT )
                    // InternalAntiPattern.g:1560:4: this_INT_0= RULE_INT kw= '/' this_INT_2= RULE_INT
                    {
                    this_INT_0=(Token)match(input,RULE_INT,FOLLOW_26); 

                    				current.merge(this_INT_0);
                    			

                    				newLeafNode(this_INT_0, grammarAccess.getNUMERIC_VALUEAccess().getINTTerminalRuleCall_0_0());
                    			
                    kw=(Token)match(input,58,FOLLOW_10); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getNUMERIC_VALUEAccess().getSolidusKeyword_0_1());
                    			
                    this_INT_2=(Token)match(input,RULE_INT,FOLLOW_2); 

                    				current.merge(this_INT_2);
                    			

                    				newLeafNode(this_INT_2, grammarAccess.getNUMERIC_VALUEAccess().getINTTerminalRuleCall_0_2());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:1581:3: this_INT_3= RULE_INT
                    {
                    this_INT_3=(Token)match(input,RULE_INT,FOLLOW_2); 

                    			current.merge(this_INT_3);
                    		

                    			newLeafNode(this_INT_3, grammarAccess.getNUMERIC_VALUEAccess().getINTTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNUMERIC_VALUE"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000902000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x004000007E000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000600002L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000F80000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000001000002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000060000000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x003FF80000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000600000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x000001F000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0380000000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0400000000000000L});

}