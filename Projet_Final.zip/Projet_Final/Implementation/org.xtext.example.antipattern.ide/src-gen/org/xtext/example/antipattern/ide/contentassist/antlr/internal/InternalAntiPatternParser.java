package org.xtext.example.antipattern.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.antipattern.services.AntiPatternGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalAntiPatternParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'LOC'", "'CYC'", "'NOP'", "'DEPTHNESTING'", "'EQUAL'", "'LESS'", "'LESS_EQUAL'", "'GREATER'", "'GREATER_EQUAL'", "'NAMING_CONVENTION'", "'Consistent_Parameter_Naming'", "'Single_Responsibility_Principle'", "'Use_of_Comments'", "'Avoid_Magic_Numbers'", "'many'", "'few'", "'Complex_Logical_Expressions'", "'ifNestedStructures'", "'switchNestedStructures'", "'loopNestedStructures'", "'ExecutableStatments'", "'Declare_Variables_Separately'", "'Add_Comments'", "'Exception_Handling'", "'Use_Recursion'", "'Use_Global_Variables'", "'unrelatedFonctionnalities'", "'method'", "'otherClass'", "'ownClass'", "'Prompt'", "'{'", "'}'", "'nbExemples:'", "'Domain:'", "'Classes:'", "'class:'", "'Method_In'", "'conditions:'", "'('", "')'", "','", "'manners'", "'violates'", "'/'", "'UNION'", "'COH'", "'ATTRIBUTE_USE'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalAntiPatternParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalAntiPatternParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalAntiPatternParser.tokenNames; }
    public String getGrammarFileName() { return "InternalAntiPattern.g"; }


    	private AntiPatternGrammarAccess grammarAccess;

    	public void setGrammarAccess(AntiPatternGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalAntiPattern.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalAntiPattern.g:54:1: ( ruleModel EOF )
            // InternalAntiPattern.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalAntiPattern.g:62:1: ruleModel : ( ( rule__Model__PromptsAssignment )* ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:66:2: ( ( ( rule__Model__PromptsAssignment )* ) )
            // InternalAntiPattern.g:67:2: ( ( rule__Model__PromptsAssignment )* )
            {
            // InternalAntiPattern.g:67:2: ( ( rule__Model__PromptsAssignment )* )
            // InternalAntiPattern.g:68:3: ( rule__Model__PromptsAssignment )*
            {
             before(grammarAccess.getModelAccess().getPromptsAssignment()); 
            // InternalAntiPattern.g:69:3: ( rule__Model__PromptsAssignment )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==41) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalAntiPattern.g:69:4: rule__Model__PromptsAssignment
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__Model__PromptsAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getPromptsAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRulePrompt"
    // InternalAntiPattern.g:78:1: entryRulePrompt : rulePrompt EOF ;
    public final void entryRulePrompt() throws RecognitionException {
        try {
            // InternalAntiPattern.g:79:1: ( rulePrompt EOF )
            // InternalAntiPattern.g:80:1: rulePrompt EOF
            {
             before(grammarAccess.getPromptRule()); 
            pushFollow(FOLLOW_1);
            rulePrompt();

            state._fsp--;

             after(grammarAccess.getPromptRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrompt"


    // $ANTLR start "rulePrompt"
    // InternalAntiPattern.g:87:1: rulePrompt : ( ( rule__Prompt__Group__0 ) ) ;
    public final void rulePrompt() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:91:2: ( ( ( rule__Prompt__Group__0 ) ) )
            // InternalAntiPattern.g:92:2: ( ( rule__Prompt__Group__0 ) )
            {
            // InternalAntiPattern.g:92:2: ( ( rule__Prompt__Group__0 ) )
            // InternalAntiPattern.g:93:3: ( rule__Prompt__Group__0 )
            {
             before(grammarAccess.getPromptAccess().getGroup()); 
            // InternalAntiPattern.g:94:3: ( rule__Prompt__Group__0 )
            // InternalAntiPattern.g:94:4: rule__Prompt__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Prompt__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPromptAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrompt"


    // $ANTLR start "entryRuleContentPrompt"
    // InternalAntiPattern.g:103:1: entryRuleContentPrompt : ruleContentPrompt EOF ;
    public final void entryRuleContentPrompt() throws RecognitionException {
        try {
            // InternalAntiPattern.g:104:1: ( ruleContentPrompt EOF )
            // InternalAntiPattern.g:105:1: ruleContentPrompt EOF
            {
             before(grammarAccess.getContentPromptRule()); 
            pushFollow(FOLLOW_1);
            ruleContentPrompt();

            state._fsp--;

             after(grammarAccess.getContentPromptRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleContentPrompt"


    // $ANTLR start "ruleContentPrompt"
    // InternalAntiPattern.g:112:1: ruleContentPrompt : ( ( rule__ContentPrompt__Group__0 ) ) ;
    public final void ruleContentPrompt() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:116:2: ( ( ( rule__ContentPrompt__Group__0 ) ) )
            // InternalAntiPattern.g:117:2: ( ( rule__ContentPrompt__Group__0 ) )
            {
            // InternalAntiPattern.g:117:2: ( ( rule__ContentPrompt__Group__0 ) )
            // InternalAntiPattern.g:118:3: ( rule__ContentPrompt__Group__0 )
            {
             before(grammarAccess.getContentPromptAccess().getGroup()); 
            // InternalAntiPattern.g:119:3: ( rule__ContentPrompt__Group__0 )
            // InternalAntiPattern.g:119:4: rule__ContentPrompt__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ContentPrompt__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getContentPromptAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleContentPrompt"


    // $ANTLR start "entryRuleExemples"
    // InternalAntiPattern.g:128:1: entryRuleExemples : ruleExemples EOF ;
    public final void entryRuleExemples() throws RecognitionException {
        try {
            // InternalAntiPattern.g:129:1: ( ruleExemples EOF )
            // InternalAntiPattern.g:130:1: ruleExemples EOF
            {
             before(grammarAccess.getExemplesRule()); 
            pushFollow(FOLLOW_1);
            ruleExemples();

            state._fsp--;

             after(grammarAccess.getExemplesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExemples"


    // $ANTLR start "ruleExemples"
    // InternalAntiPattern.g:137:1: ruleExemples : ( ( rule__Exemples__Group__0 ) ) ;
    public final void ruleExemples() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:141:2: ( ( ( rule__Exemples__Group__0 ) ) )
            // InternalAntiPattern.g:142:2: ( ( rule__Exemples__Group__0 ) )
            {
            // InternalAntiPattern.g:142:2: ( ( rule__Exemples__Group__0 ) )
            // InternalAntiPattern.g:143:3: ( rule__Exemples__Group__0 )
            {
             before(grammarAccess.getExemplesAccess().getGroup()); 
            // InternalAntiPattern.g:144:3: ( rule__Exemples__Group__0 )
            // InternalAntiPattern.g:144:4: rule__Exemples__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Exemples__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getExemplesAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExemples"


    // $ANTLR start "entryRuleDomain"
    // InternalAntiPattern.g:153:1: entryRuleDomain : ruleDomain EOF ;
    public final void entryRuleDomain() throws RecognitionException {
        try {
            // InternalAntiPattern.g:154:1: ( ruleDomain EOF )
            // InternalAntiPattern.g:155:1: ruleDomain EOF
            {
             before(grammarAccess.getDomainRule()); 
            pushFollow(FOLLOW_1);
            ruleDomain();

            state._fsp--;

             after(grammarAccess.getDomainRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDomain"


    // $ANTLR start "ruleDomain"
    // InternalAntiPattern.g:162:1: ruleDomain : ( ( rule__Domain__Group__0 ) ) ;
    public final void ruleDomain() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:166:2: ( ( ( rule__Domain__Group__0 ) ) )
            // InternalAntiPattern.g:167:2: ( ( rule__Domain__Group__0 ) )
            {
            // InternalAntiPattern.g:167:2: ( ( rule__Domain__Group__0 ) )
            // InternalAntiPattern.g:168:3: ( rule__Domain__Group__0 )
            {
             before(grammarAccess.getDomainAccess().getGroup()); 
            // InternalAntiPattern.g:169:3: ( rule__Domain__Group__0 )
            // InternalAntiPattern.g:169:4: rule__Domain__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Domain__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDomainAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDomain"


    // $ANTLR start "entryRuleClasses"
    // InternalAntiPattern.g:178:1: entryRuleClasses : ruleClasses EOF ;
    public final void entryRuleClasses() throws RecognitionException {
        try {
            // InternalAntiPattern.g:179:1: ( ruleClasses EOF )
            // InternalAntiPattern.g:180:1: ruleClasses EOF
            {
             before(grammarAccess.getClassesRule()); 
            pushFollow(FOLLOW_1);
            ruleClasses();

            state._fsp--;

             after(grammarAccess.getClassesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClasses"


    // $ANTLR start "ruleClasses"
    // InternalAntiPattern.g:187:1: ruleClasses : ( ( rule__Classes__Group__0 ) ) ;
    public final void ruleClasses() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:191:2: ( ( ( rule__Classes__Group__0 ) ) )
            // InternalAntiPattern.g:192:2: ( ( rule__Classes__Group__0 ) )
            {
            // InternalAntiPattern.g:192:2: ( ( rule__Classes__Group__0 ) )
            // InternalAntiPattern.g:193:3: ( rule__Classes__Group__0 )
            {
             before(grammarAccess.getClassesAccess().getGroup()); 
            // InternalAntiPattern.g:194:3: ( rule__Classes__Group__0 )
            // InternalAntiPattern.g:194:4: rule__Classes__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Classes__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClassesAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClasses"


    // $ANTLR start "entryRule_Class"
    // InternalAntiPattern.g:203:1: entryRule_Class : rule_Class EOF ;
    public final void entryRule_Class() throws RecognitionException {
        try {
            // InternalAntiPattern.g:204:1: ( rule_Class EOF )
            // InternalAntiPattern.g:205:1: rule_Class EOF
            {
             before(grammarAccess.get_ClassRule()); 
            pushFollow(FOLLOW_1);
            rule_Class();

            state._fsp--;

             after(grammarAccess.get_ClassRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRule_Class"


    // $ANTLR start "rule_Class"
    // InternalAntiPattern.g:212:1: rule_Class : ( ( rule___Class__Group__0 ) ) ;
    public final void rule_Class() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:216:2: ( ( ( rule___Class__Group__0 ) ) )
            // InternalAntiPattern.g:217:2: ( ( rule___Class__Group__0 ) )
            {
            // InternalAntiPattern.g:217:2: ( ( rule___Class__Group__0 ) )
            // InternalAntiPattern.g:218:3: ( rule___Class__Group__0 )
            {
             before(grammarAccess.get_ClassAccess().getGroup()); 
            // InternalAntiPattern.g:219:3: ( rule___Class__Group__0 )
            // InternalAntiPattern.g:219:4: rule___Class__Group__0
            {
            pushFollow(FOLLOW_2);
            rule___Class__Group__0();

            state._fsp--;


            }

             after(grammarAccess.get_ClassAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule_Class"


    // $ANTLR start "entryRuleChosenMethod"
    // InternalAntiPattern.g:228:1: entryRuleChosenMethod : ruleChosenMethod EOF ;
    public final void entryRuleChosenMethod() throws RecognitionException {
        try {
            // InternalAntiPattern.g:229:1: ( ruleChosenMethod EOF )
            // InternalAntiPattern.g:230:1: ruleChosenMethod EOF
            {
             before(grammarAccess.getChosenMethodRule()); 
            pushFollow(FOLLOW_1);
            ruleChosenMethod();

            state._fsp--;

             after(grammarAccess.getChosenMethodRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleChosenMethod"


    // $ANTLR start "ruleChosenMethod"
    // InternalAntiPattern.g:237:1: ruleChosenMethod : ( ( rule__ChosenMethod__Group__0 ) ) ;
    public final void ruleChosenMethod() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:241:2: ( ( ( rule__ChosenMethod__Group__0 ) ) )
            // InternalAntiPattern.g:242:2: ( ( rule__ChosenMethod__Group__0 ) )
            {
            // InternalAntiPattern.g:242:2: ( ( rule__ChosenMethod__Group__0 ) )
            // InternalAntiPattern.g:243:3: ( rule__ChosenMethod__Group__0 )
            {
             before(grammarAccess.getChosenMethodAccess().getGroup()); 
            // InternalAntiPattern.g:244:3: ( rule__ChosenMethod__Group__0 )
            // InternalAntiPattern.g:244:4: rule__ChosenMethod__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ChosenMethod__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getChosenMethodAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleChosenMethod"


    // $ANTLR start "entryRuleCondition"
    // InternalAntiPattern.g:253:1: entryRuleCondition : ruleCondition EOF ;
    public final void entryRuleCondition() throws RecognitionException {
        try {
            // InternalAntiPattern.g:254:1: ( ruleCondition EOF )
            // InternalAntiPattern.g:255:1: ruleCondition EOF
            {
             before(grammarAccess.getConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleCondition();

            state._fsp--;

             after(grammarAccess.getConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCondition"


    // $ANTLR start "ruleCondition"
    // InternalAntiPattern.g:262:1: ruleCondition : ( ( rule__Condition__Group__0 ) ) ;
    public final void ruleCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:266:2: ( ( ( rule__Condition__Group__0 ) ) )
            // InternalAntiPattern.g:267:2: ( ( rule__Condition__Group__0 ) )
            {
            // InternalAntiPattern.g:267:2: ( ( rule__Condition__Group__0 ) )
            // InternalAntiPattern.g:268:3: ( rule__Condition__Group__0 )
            {
             before(grammarAccess.getConditionAccess().getGroup()); 
            // InternalAntiPattern.g:269:3: ( rule__Condition__Group__0 )
            // InternalAntiPattern.g:269:4: rule__Condition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Condition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCondition"


    // $ANTLR start "entryRuleLink"
    // InternalAntiPattern.g:278:1: entryRuleLink : ruleLink EOF ;
    public final void entryRuleLink() throws RecognitionException {
        try {
            // InternalAntiPattern.g:279:1: ( ruleLink EOF )
            // InternalAntiPattern.g:280:1: ruleLink EOF
            {
             before(grammarAccess.getLinkRule()); 
            pushFollow(FOLLOW_1);
            ruleLink();

            state._fsp--;

             after(grammarAccess.getLinkRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLink"


    // $ANTLR start "ruleLink"
    // InternalAntiPattern.g:287:1: ruleLink : ( ( rule__Link__OpAssignment ) ) ;
    public final void ruleLink() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:291:2: ( ( ( rule__Link__OpAssignment ) ) )
            // InternalAntiPattern.g:292:2: ( ( rule__Link__OpAssignment ) )
            {
            // InternalAntiPattern.g:292:2: ( ( rule__Link__OpAssignment ) )
            // InternalAntiPattern.g:293:3: ( rule__Link__OpAssignment )
            {
             before(grammarAccess.getLinkAccess().getOpAssignment()); 
            // InternalAntiPattern.g:294:3: ( rule__Link__OpAssignment )
            // InternalAntiPattern.g:294:4: rule__Link__OpAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Link__OpAssignment();

            state._fsp--;


            }

             after(grammarAccess.getLinkAccess().getOpAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLink"


    // $ANTLR start "entryRuleRuleType"
    // InternalAntiPattern.g:303:1: entryRuleRuleType : ruleRuleType EOF ;
    public final void entryRuleRuleType() throws RecognitionException {
        try {
            // InternalAntiPattern.g:304:1: ( ruleRuleType EOF )
            // InternalAntiPattern.g:305:1: ruleRuleType EOF
            {
             before(grammarAccess.getRuleTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleRuleType();

            state._fsp--;

             after(grammarAccess.getRuleTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRuleType"


    // $ANTLR start "ruleRuleType"
    // InternalAntiPattern.g:312:1: ruleRuleType : ( ( rule__RuleType__Alternatives ) ) ;
    public final void ruleRuleType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:316:2: ( ( ( rule__RuleType__Alternatives ) ) )
            // InternalAntiPattern.g:317:2: ( ( rule__RuleType__Alternatives ) )
            {
            // InternalAntiPattern.g:317:2: ( ( rule__RuleType__Alternatives ) )
            // InternalAntiPattern.g:318:3: ( rule__RuleType__Alternatives )
            {
             before(grammarAccess.getRuleTypeAccess().getAlternatives()); 
            // InternalAntiPattern.g:319:3: ( rule__RuleType__Alternatives )
            // InternalAntiPattern.g:319:4: rule__RuleType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__RuleType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getRuleTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRuleType"


    // $ANTLR start "entryRuleIntraCharacteristic"
    // InternalAntiPattern.g:328:1: entryRuleIntraCharacteristic : ruleIntraCharacteristic EOF ;
    public final void entryRuleIntraCharacteristic() throws RecognitionException {
        try {
            // InternalAntiPattern.g:329:1: ( ruleIntraCharacteristic EOF )
            // InternalAntiPattern.g:330:1: ruleIntraCharacteristic EOF
            {
             before(grammarAccess.getIntraCharacteristicRule()); 
            pushFollow(FOLLOW_1);
            ruleIntraCharacteristic();

            state._fsp--;

             after(grammarAccess.getIntraCharacteristicRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleIntraCharacteristic"


    // $ANTLR start "ruleIntraCharacteristic"
    // InternalAntiPattern.g:337:1: ruleIntraCharacteristic : ( ( rule__IntraCharacteristic__Alternatives ) ) ;
    public final void ruleIntraCharacteristic() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:341:2: ( ( ( rule__IntraCharacteristic__Alternatives ) ) )
            // InternalAntiPattern.g:342:2: ( ( rule__IntraCharacteristic__Alternatives ) )
            {
            // InternalAntiPattern.g:342:2: ( ( rule__IntraCharacteristic__Alternatives ) )
            // InternalAntiPattern.g:343:3: ( rule__IntraCharacteristic__Alternatives )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getAlternatives()); 
            // InternalAntiPattern.g:344:3: ( rule__IntraCharacteristic__Alternatives )
            // InternalAntiPattern.g:344:4: rule__IntraCharacteristic__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleIntraCharacteristic"


    // $ANTLR start "entryRuleMetric"
    // InternalAntiPattern.g:353:1: entryRuleMetric : ruleMetric EOF ;
    public final void entryRuleMetric() throws RecognitionException {
        try {
            // InternalAntiPattern.g:354:1: ( ruleMetric EOF )
            // InternalAntiPattern.g:355:1: ruleMetric EOF
            {
             before(grammarAccess.getMetricRule()); 
            pushFollow(FOLLOW_1);
            ruleMetric();

            state._fsp--;

             after(grammarAccess.getMetricRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMetric"


    // $ANTLR start "ruleMetric"
    // InternalAntiPattern.g:362:1: ruleMetric : ( ( rule__Metric__Alternatives ) ) ;
    public final void ruleMetric() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:366:2: ( ( ( rule__Metric__Alternatives ) ) )
            // InternalAntiPattern.g:367:2: ( ( rule__Metric__Alternatives ) )
            {
            // InternalAntiPattern.g:367:2: ( ( rule__Metric__Alternatives ) )
            // InternalAntiPattern.g:368:3: ( rule__Metric__Alternatives )
            {
             before(grammarAccess.getMetricAccess().getAlternatives()); 
            // InternalAntiPattern.g:369:3: ( rule__Metric__Alternatives )
            // InternalAntiPattern.g:369:4: rule__Metric__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Metric__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getMetricAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMetric"


    // $ANTLR start "entryRuleMAXMetric"
    // InternalAntiPattern.g:378:1: entryRuleMAXMetric : ruleMAXMetric EOF ;
    public final void entryRuleMAXMetric() throws RecognitionException {
        try {
            // InternalAntiPattern.g:379:1: ( ruleMAXMetric EOF )
            // InternalAntiPattern.g:380:1: ruleMAXMetric EOF
            {
             before(grammarAccess.getMAXMetricRule()); 
            pushFollow(FOLLOW_1);
            ruleMAXMetric();

            state._fsp--;

             after(grammarAccess.getMAXMetricRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMAXMetric"


    // $ANTLR start "ruleMAXMetric"
    // InternalAntiPattern.g:387:1: ruleMAXMetric : ( ( rule__MAXMetric__Metric_valAssignment ) ) ;
    public final void ruleMAXMetric() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:391:2: ( ( ( rule__MAXMetric__Metric_valAssignment ) ) )
            // InternalAntiPattern.g:392:2: ( ( rule__MAXMetric__Metric_valAssignment ) )
            {
            // InternalAntiPattern.g:392:2: ( ( rule__MAXMetric__Metric_valAssignment ) )
            // InternalAntiPattern.g:393:3: ( rule__MAXMetric__Metric_valAssignment )
            {
             before(grammarAccess.getMAXMetricAccess().getMetric_valAssignment()); 
            // InternalAntiPattern.g:394:3: ( rule__MAXMetric__Metric_valAssignment )
            // InternalAntiPattern.g:394:4: rule__MAXMetric__Metric_valAssignment
            {
            pushFollow(FOLLOW_2);
            rule__MAXMetric__Metric_valAssignment();

            state._fsp--;


            }

             after(grammarAccess.getMAXMetricAccess().getMetric_valAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMAXMetric"


    // $ANTLR start "entryRuleMINMetric"
    // InternalAntiPattern.g:403:1: entryRuleMINMetric : ruleMINMetric EOF ;
    public final void entryRuleMINMetric() throws RecognitionException {
        try {
            // InternalAntiPattern.g:404:1: ( ruleMINMetric EOF )
            // InternalAntiPattern.g:405:1: ruleMINMetric EOF
            {
             before(grammarAccess.getMINMetricRule()); 
            pushFollow(FOLLOW_1);
            ruleMINMetric();

            state._fsp--;

             after(grammarAccess.getMINMetricRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMINMetric"


    // $ANTLR start "ruleMINMetric"
    // InternalAntiPattern.g:412:1: ruleMINMetric : ( ( rule__MINMetric__Metric_valAssignment ) ) ;
    public final void ruleMINMetric() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:416:2: ( ( ( rule__MINMetric__Metric_valAssignment ) ) )
            // InternalAntiPattern.g:417:2: ( ( rule__MINMetric__Metric_valAssignment ) )
            {
            // InternalAntiPattern.g:417:2: ( ( rule__MINMetric__Metric_valAssignment ) )
            // InternalAntiPattern.g:418:3: ( rule__MINMetric__Metric_valAssignment )
            {
             before(grammarAccess.getMINMetricAccess().getMetric_valAssignment()); 
            // InternalAntiPattern.g:419:3: ( rule__MINMetric__Metric_valAssignment )
            // InternalAntiPattern.g:419:4: rule__MINMetric__Metric_valAssignment
            {
            pushFollow(FOLLOW_2);
            rule__MINMetric__Metric_valAssignment();

            state._fsp--;


            }

             after(grammarAccess.getMINMetricAccess().getMetric_valAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMINMetric"


    // $ANTLR start "entryRuleComparator"
    // InternalAntiPattern.g:428:1: entryRuleComparator : ruleComparator EOF ;
    public final void entryRuleComparator() throws RecognitionException {
        try {
            // InternalAntiPattern.g:429:1: ( ruleComparator EOF )
            // InternalAntiPattern.g:430:1: ruleComparator EOF
            {
             before(grammarAccess.getComparatorRule()); 
            pushFollow(FOLLOW_1);
            ruleComparator();

            state._fsp--;

             after(grammarAccess.getComparatorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleComparator"


    // $ANTLR start "ruleComparator"
    // InternalAntiPattern.g:437:1: ruleComparator : ( ( rule__Comparator__CompAssignment ) ) ;
    public final void ruleComparator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:441:2: ( ( ( rule__Comparator__CompAssignment ) ) )
            // InternalAntiPattern.g:442:2: ( ( rule__Comparator__CompAssignment ) )
            {
            // InternalAntiPattern.g:442:2: ( ( rule__Comparator__CompAssignment ) )
            // InternalAntiPattern.g:443:3: ( rule__Comparator__CompAssignment )
            {
             before(grammarAccess.getComparatorAccess().getCompAssignment()); 
            // InternalAntiPattern.g:444:3: ( rule__Comparator__CompAssignment )
            // InternalAntiPattern.g:444:4: rule__Comparator__CompAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Comparator__CompAssignment();

            state._fsp--;


            }

             after(grammarAccess.getComparatorAccess().getCompAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparator"


    // $ANTLR start "entryRuleConvention"
    // InternalAntiPattern.g:453:1: entryRuleConvention : ruleConvention EOF ;
    public final void entryRuleConvention() throws RecognitionException {
        try {
            // InternalAntiPattern.g:454:1: ( ruleConvention EOF )
            // InternalAntiPattern.g:455:1: ruleConvention EOF
            {
             before(grammarAccess.getConventionRule()); 
            pushFollow(FOLLOW_1);
            ruleConvention();

            state._fsp--;

             after(grammarAccess.getConventionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleConvention"


    // $ANTLR start "ruleConvention"
    // InternalAntiPattern.g:462:1: ruleConvention : ( ( rule__Convention__CAssignment ) ) ;
    public final void ruleConvention() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:466:2: ( ( ( rule__Convention__CAssignment ) ) )
            // InternalAntiPattern.g:467:2: ( ( rule__Convention__CAssignment ) )
            {
            // InternalAntiPattern.g:467:2: ( ( rule__Convention__CAssignment ) )
            // InternalAntiPattern.g:468:3: ( rule__Convention__CAssignment )
            {
             before(grammarAccess.getConventionAccess().getCAssignment()); 
            // InternalAntiPattern.g:469:3: ( rule__Convention__CAssignment )
            // InternalAntiPattern.g:469:4: rule__Convention__CAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Convention__CAssignment();

            state._fsp--;


            }

             after(grammarAccess.getConventionAccess().getCAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConvention"


    // $ANTLR start "entryRuleQunatity"
    // InternalAntiPattern.g:478:1: entryRuleQunatity : ruleQunatity EOF ;
    public final void entryRuleQunatity() throws RecognitionException {
        try {
            // InternalAntiPattern.g:479:1: ( ruleQunatity EOF )
            // InternalAntiPattern.g:480:1: ruleQunatity EOF
            {
             before(grammarAccess.getQunatityRule()); 
            pushFollow(FOLLOW_1);
            ruleQunatity();

            state._fsp--;

             after(grammarAccess.getQunatityRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQunatity"


    // $ANTLR start "ruleQunatity"
    // InternalAntiPattern.g:487:1: ruleQunatity : ( ( rule__Qunatity__QAssignment ) ) ;
    public final void ruleQunatity() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:491:2: ( ( ( rule__Qunatity__QAssignment ) ) )
            // InternalAntiPattern.g:492:2: ( ( rule__Qunatity__QAssignment ) )
            {
            // InternalAntiPattern.g:492:2: ( ( rule__Qunatity__QAssignment ) )
            // InternalAntiPattern.g:493:3: ( rule__Qunatity__QAssignment )
            {
             before(grammarAccess.getQunatityAccess().getQAssignment()); 
            // InternalAntiPattern.g:494:3: ( rule__Qunatity__QAssignment )
            // InternalAntiPattern.g:494:4: rule__Qunatity__QAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Qunatity__QAssignment();

            state._fsp--;


            }

             after(grammarAccess.getQunatityAccess().getQAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQunatity"


    // $ANTLR start "entryRuleManner"
    // InternalAntiPattern.g:503:1: entryRuleManner : ruleManner EOF ;
    public final void entryRuleManner() throws RecognitionException {
        try {
            // InternalAntiPattern.g:504:1: ( ruleManner EOF )
            // InternalAntiPattern.g:505:1: ruleManner EOF
            {
             before(grammarAccess.getMannerRule()); 
            pushFollow(FOLLOW_1);
            ruleManner();

            state._fsp--;

             after(grammarAccess.getMannerRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleManner"


    // $ANTLR start "ruleManner"
    // InternalAntiPattern.g:512:1: ruleManner : ( ( rule__Manner__MannerAssignment ) ) ;
    public final void ruleManner() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:516:2: ( ( ( rule__Manner__MannerAssignment ) ) )
            // InternalAntiPattern.g:517:2: ( ( rule__Manner__MannerAssignment ) )
            {
            // InternalAntiPattern.g:517:2: ( ( rule__Manner__MannerAssignment ) )
            // InternalAntiPattern.g:518:3: ( rule__Manner__MannerAssignment )
            {
             before(grammarAccess.getMannerAccess().getMannerAssignment()); 
            // InternalAntiPattern.g:519:3: ( rule__Manner__MannerAssignment )
            // InternalAntiPattern.g:519:4: rule__Manner__MannerAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Manner__MannerAssignment();

            state._fsp--;


            }

             after(grammarAccess.getMannerAccess().getMannerAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleManner"


    // $ANTLR start "entryRuleInterCarachteristic"
    // InternalAntiPattern.g:528:1: entryRuleInterCarachteristic : ruleInterCarachteristic EOF ;
    public final void entryRuleInterCarachteristic() throws RecognitionException {
        try {
            // InternalAntiPattern.g:529:1: ( ruleInterCarachteristic EOF )
            // InternalAntiPattern.g:530:1: ruleInterCarachteristic EOF
            {
             before(grammarAccess.getInterCarachteristicRule()); 
            pushFollow(FOLLOW_1);
            ruleInterCarachteristic();

            state._fsp--;

             after(grammarAccess.getInterCarachteristicRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInterCarachteristic"


    // $ANTLR start "ruleInterCarachteristic"
    // InternalAntiPattern.g:537:1: ruleInterCarachteristic : ( ( rule__InterCarachteristic__Group__0 ) ) ;
    public final void ruleInterCarachteristic() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:541:2: ( ( ( rule__InterCarachteristic__Group__0 ) ) )
            // InternalAntiPattern.g:542:2: ( ( rule__InterCarachteristic__Group__0 ) )
            {
            // InternalAntiPattern.g:542:2: ( ( rule__InterCarachteristic__Group__0 ) )
            // InternalAntiPattern.g:543:3: ( rule__InterCarachteristic__Group__0 )
            {
             before(grammarAccess.getInterCarachteristicAccess().getGroup()); 
            // InternalAntiPattern.g:544:3: ( rule__InterCarachteristic__Group__0 )
            // InternalAntiPattern.g:544:4: rule__InterCarachteristic__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInterCarachteristicAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInterCarachteristic"


    // $ANTLR start "entryRuleParam"
    // InternalAntiPattern.g:553:1: entryRuleParam : ruleParam EOF ;
    public final void entryRuleParam() throws RecognitionException {
        try {
            // InternalAntiPattern.g:554:1: ( ruleParam EOF )
            // InternalAntiPattern.g:555:1: ruleParam EOF
            {
             before(grammarAccess.getParamRule()); 
            pushFollow(FOLLOW_1);
            ruleParam();

            state._fsp--;

             after(grammarAccess.getParamRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleParam"


    // $ANTLR start "ruleParam"
    // InternalAntiPattern.g:562:1: ruleParam : ( ( rule__Param__PAssignment ) ) ;
    public final void ruleParam() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:566:2: ( ( ( rule__Param__PAssignment ) ) )
            // InternalAntiPattern.g:567:2: ( ( rule__Param__PAssignment ) )
            {
            // InternalAntiPattern.g:567:2: ( ( rule__Param__PAssignment ) )
            // InternalAntiPattern.g:568:3: ( rule__Param__PAssignment )
            {
             before(grammarAccess.getParamAccess().getPAssignment()); 
            // InternalAntiPattern.g:569:3: ( rule__Param__PAssignment )
            // InternalAntiPattern.g:569:4: rule__Param__PAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Param__PAssignment();

            state._fsp--;


            }

             after(grammarAccess.getParamAccess().getPAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleParam"


    // $ANTLR start "entryRuleNUMERIC_VALUE"
    // InternalAntiPattern.g:578:1: entryRuleNUMERIC_VALUE : ruleNUMERIC_VALUE EOF ;
    public final void entryRuleNUMERIC_VALUE() throws RecognitionException {
        try {
            // InternalAntiPattern.g:579:1: ( ruleNUMERIC_VALUE EOF )
            // InternalAntiPattern.g:580:1: ruleNUMERIC_VALUE EOF
            {
             before(grammarAccess.getNUMERIC_VALUERule()); 
            pushFollow(FOLLOW_1);
            ruleNUMERIC_VALUE();

            state._fsp--;

             after(grammarAccess.getNUMERIC_VALUERule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNUMERIC_VALUE"


    // $ANTLR start "ruleNUMERIC_VALUE"
    // InternalAntiPattern.g:587:1: ruleNUMERIC_VALUE : ( ( rule__NUMERIC_VALUE__Alternatives ) ) ;
    public final void ruleNUMERIC_VALUE() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:591:2: ( ( ( rule__NUMERIC_VALUE__Alternatives ) ) )
            // InternalAntiPattern.g:592:2: ( ( rule__NUMERIC_VALUE__Alternatives ) )
            {
            // InternalAntiPattern.g:592:2: ( ( rule__NUMERIC_VALUE__Alternatives ) )
            // InternalAntiPattern.g:593:3: ( rule__NUMERIC_VALUE__Alternatives )
            {
             before(grammarAccess.getNUMERIC_VALUEAccess().getAlternatives()); 
            // InternalAntiPattern.g:594:3: ( rule__NUMERIC_VALUE__Alternatives )
            // InternalAntiPattern.g:594:4: rule__NUMERIC_VALUE__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__NUMERIC_VALUE__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getNUMERIC_VALUEAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNUMERIC_VALUE"


    // $ANTLR start "rule__RuleType__Alternatives"
    // InternalAntiPattern.g:602:1: rule__RuleType__Alternatives : ( ( ruleIntraCharacteristic ) | ( ruleInterCarachteristic ) );
    public final void rule__RuleType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:606:1: ( ( ruleIntraCharacteristic ) | ( ruleInterCarachteristic ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( ((LA2_0>=11 && LA2_0<=14)||LA2_0==54||LA2_0==57) ) {
                alt2=1;
            }
            else if ( (LA2_0==58) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalAntiPattern.g:607:2: ( ruleIntraCharacteristic )
                    {
                    // InternalAntiPattern.g:607:2: ( ruleIntraCharacteristic )
                    // InternalAntiPattern.g:608:3: ruleIntraCharacteristic
                    {
                     before(grammarAccess.getRuleTypeAccess().getIntraCharacteristicParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleIntraCharacteristic();

                    state._fsp--;

                     after(grammarAccess.getRuleTypeAccess().getIntraCharacteristicParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:613:2: ( ruleInterCarachteristic )
                    {
                    // InternalAntiPattern.g:613:2: ( ruleInterCarachteristic )
                    // InternalAntiPattern.g:614:3: ruleInterCarachteristic
                    {
                     before(grammarAccess.getRuleTypeAccess().getInterCarachteristicParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleInterCarachteristic();

                    state._fsp--;

                     after(grammarAccess.getRuleTypeAccess().getInterCarachteristicParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RuleType__Alternatives"


    // $ANTLR start "rule__IntraCharacteristic__Alternatives"
    // InternalAntiPattern.g:623:1: rule__IntraCharacteristic__Alternatives : ( ( ( rule__IntraCharacteristic__Group_0__0 ) ) | ( ( rule__IntraCharacteristic__Group_1__0 ) ) );
    public final void rule__IntraCharacteristic__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:627:1: ( ( ( rule__IntraCharacteristic__Group_0__0 ) ) | ( ( rule__IntraCharacteristic__Group_1__0 ) ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( ((LA3_0>=11 && LA3_0<=14)||LA3_0==57) ) {
                alt3=1;
            }
            else if ( (LA3_0==54) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalAntiPattern.g:628:2: ( ( rule__IntraCharacteristic__Group_0__0 ) )
                    {
                    // InternalAntiPattern.g:628:2: ( ( rule__IntraCharacteristic__Group_0__0 ) )
                    // InternalAntiPattern.g:629:3: ( rule__IntraCharacteristic__Group_0__0 )
                    {
                     before(grammarAccess.getIntraCharacteristicAccess().getGroup_0()); 
                    // InternalAntiPattern.g:630:3: ( rule__IntraCharacteristic__Group_0__0 )
                    // InternalAntiPattern.g:630:4: rule__IntraCharacteristic__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__IntraCharacteristic__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getIntraCharacteristicAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:634:2: ( ( rule__IntraCharacteristic__Group_1__0 ) )
                    {
                    // InternalAntiPattern.g:634:2: ( ( rule__IntraCharacteristic__Group_1__0 ) )
                    // InternalAntiPattern.g:635:3: ( rule__IntraCharacteristic__Group_1__0 )
                    {
                     before(grammarAccess.getIntraCharacteristicAccess().getGroup_1()); 
                    // InternalAntiPattern.g:636:3: ( rule__IntraCharacteristic__Group_1__0 )
                    // InternalAntiPattern.g:636:4: rule__IntraCharacteristic__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__IntraCharacteristic__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getIntraCharacteristicAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Alternatives"


    // $ANTLR start "rule__Metric__Alternatives"
    // InternalAntiPattern.g:644:1: rule__Metric__Alternatives : ( ( ruleMAXMetric ) | ( ruleMINMetric ) );
    public final void rule__Metric__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:648:1: ( ( ruleMAXMetric ) | ( ruleMINMetric ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( ((LA4_0>=11 && LA4_0<=14)) ) {
                alt4=1;
            }
            else if ( (LA4_0==57) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalAntiPattern.g:649:2: ( ruleMAXMetric )
                    {
                    // InternalAntiPattern.g:649:2: ( ruleMAXMetric )
                    // InternalAntiPattern.g:650:3: ruleMAXMetric
                    {
                     before(grammarAccess.getMetricAccess().getMAXMetricParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleMAXMetric();

                    state._fsp--;

                     after(grammarAccess.getMetricAccess().getMAXMetricParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:655:2: ( ruleMINMetric )
                    {
                    // InternalAntiPattern.g:655:2: ( ruleMINMetric )
                    // InternalAntiPattern.g:656:3: ruleMINMetric
                    {
                     before(grammarAccess.getMetricAccess().getMINMetricParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleMINMetric();

                    state._fsp--;

                     after(grammarAccess.getMetricAccess().getMINMetricParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Alternatives"


    // $ANTLR start "rule__MAXMetric__Metric_valAlternatives_0"
    // InternalAntiPattern.g:665:1: rule__MAXMetric__Metric_valAlternatives_0 : ( ( 'LOC' ) | ( 'CYC' ) | ( 'NOP' ) | ( 'DEPTHNESTING' ) );
    public final void rule__MAXMetric__Metric_valAlternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:669:1: ( ( 'LOC' ) | ( 'CYC' ) | ( 'NOP' ) | ( 'DEPTHNESTING' ) )
            int alt5=4;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt5=1;
                }
                break;
            case 12:
                {
                alt5=2;
                }
                break;
            case 13:
                {
                alt5=3;
                }
                break;
            case 14:
                {
                alt5=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalAntiPattern.g:670:2: ( 'LOC' )
                    {
                    // InternalAntiPattern.g:670:2: ( 'LOC' )
                    // InternalAntiPattern.g:671:3: 'LOC'
                    {
                     before(grammarAccess.getMAXMetricAccess().getMetric_valLOCKeyword_0_0()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getMAXMetricAccess().getMetric_valLOCKeyword_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:676:2: ( 'CYC' )
                    {
                    // InternalAntiPattern.g:676:2: ( 'CYC' )
                    // InternalAntiPattern.g:677:3: 'CYC'
                    {
                     before(grammarAccess.getMAXMetricAccess().getMetric_valCYCKeyword_0_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getMAXMetricAccess().getMetric_valCYCKeyword_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:682:2: ( 'NOP' )
                    {
                    // InternalAntiPattern.g:682:2: ( 'NOP' )
                    // InternalAntiPattern.g:683:3: 'NOP'
                    {
                     before(grammarAccess.getMAXMetricAccess().getMetric_valNOPKeyword_0_2()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getMAXMetricAccess().getMetric_valNOPKeyword_0_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalAntiPattern.g:688:2: ( 'DEPTHNESTING' )
                    {
                    // InternalAntiPattern.g:688:2: ( 'DEPTHNESTING' )
                    // InternalAntiPattern.g:689:3: 'DEPTHNESTING'
                    {
                     before(grammarAccess.getMAXMetricAccess().getMetric_valDEPTHNESTINGKeyword_0_3()); 
                    match(input,14,FOLLOW_2); 
                     after(grammarAccess.getMAXMetricAccess().getMetric_valDEPTHNESTINGKeyword_0_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MAXMetric__Metric_valAlternatives_0"


    // $ANTLR start "rule__Comparator__CompAlternatives_0"
    // InternalAntiPattern.g:698:1: rule__Comparator__CompAlternatives_0 : ( ( 'EQUAL' ) | ( 'LESS' ) | ( 'LESS_EQUAL' ) | ( 'GREATER' ) | ( 'GREATER_EQUAL' ) );
    public final void rule__Comparator__CompAlternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:702:1: ( ( 'EQUAL' ) | ( 'LESS' ) | ( 'LESS_EQUAL' ) | ( 'GREATER' ) | ( 'GREATER_EQUAL' ) )
            int alt6=5;
            switch ( input.LA(1) ) {
            case 15:
                {
                alt6=1;
                }
                break;
            case 16:
                {
                alt6=2;
                }
                break;
            case 17:
                {
                alt6=3;
                }
                break;
            case 18:
                {
                alt6=4;
                }
                break;
            case 19:
                {
                alt6=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalAntiPattern.g:703:2: ( 'EQUAL' )
                    {
                    // InternalAntiPattern.g:703:2: ( 'EQUAL' )
                    // InternalAntiPattern.g:704:3: 'EQUAL'
                    {
                     before(grammarAccess.getComparatorAccess().getCompEQUALKeyword_0_0()); 
                    match(input,15,FOLLOW_2); 
                     after(grammarAccess.getComparatorAccess().getCompEQUALKeyword_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:709:2: ( 'LESS' )
                    {
                    // InternalAntiPattern.g:709:2: ( 'LESS' )
                    // InternalAntiPattern.g:710:3: 'LESS'
                    {
                     before(grammarAccess.getComparatorAccess().getCompLESSKeyword_0_1()); 
                    match(input,16,FOLLOW_2); 
                     after(grammarAccess.getComparatorAccess().getCompLESSKeyword_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:715:2: ( 'LESS_EQUAL' )
                    {
                    // InternalAntiPattern.g:715:2: ( 'LESS_EQUAL' )
                    // InternalAntiPattern.g:716:3: 'LESS_EQUAL'
                    {
                     before(grammarAccess.getComparatorAccess().getCompLESS_EQUALKeyword_0_2()); 
                    match(input,17,FOLLOW_2); 
                     after(grammarAccess.getComparatorAccess().getCompLESS_EQUALKeyword_0_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalAntiPattern.g:721:2: ( 'GREATER' )
                    {
                    // InternalAntiPattern.g:721:2: ( 'GREATER' )
                    // InternalAntiPattern.g:722:3: 'GREATER'
                    {
                     before(grammarAccess.getComparatorAccess().getCompGREATERKeyword_0_3()); 
                    match(input,18,FOLLOW_2); 
                     after(grammarAccess.getComparatorAccess().getCompGREATERKeyword_0_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalAntiPattern.g:727:2: ( 'GREATER_EQUAL' )
                    {
                    // InternalAntiPattern.g:727:2: ( 'GREATER_EQUAL' )
                    // InternalAntiPattern.g:728:3: 'GREATER_EQUAL'
                    {
                     before(grammarAccess.getComparatorAccess().getCompGREATER_EQUALKeyword_0_4()); 
                    match(input,19,FOLLOW_2); 
                     after(grammarAccess.getComparatorAccess().getCompGREATER_EQUALKeyword_0_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comparator__CompAlternatives_0"


    // $ANTLR start "rule__Convention__CAlternatives_0"
    // InternalAntiPattern.g:737:1: rule__Convention__CAlternatives_0 : ( ( 'NAMING_CONVENTION' ) | ( 'Consistent_Parameter_Naming' ) | ( 'Single_Responsibility_Principle' ) | ( 'Use_of_Comments' ) | ( 'Avoid_Magic_Numbers' ) );
    public final void rule__Convention__CAlternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:741:1: ( ( 'NAMING_CONVENTION' ) | ( 'Consistent_Parameter_Naming' ) | ( 'Single_Responsibility_Principle' ) | ( 'Use_of_Comments' ) | ( 'Avoid_Magic_Numbers' ) )
            int alt7=5;
            switch ( input.LA(1) ) {
            case 20:
                {
                alt7=1;
                }
                break;
            case 21:
                {
                alt7=2;
                }
                break;
            case 22:
                {
                alt7=3;
                }
                break;
            case 23:
                {
                alt7=4;
                }
                break;
            case 24:
                {
                alt7=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalAntiPattern.g:742:2: ( 'NAMING_CONVENTION' )
                    {
                    // InternalAntiPattern.g:742:2: ( 'NAMING_CONVENTION' )
                    // InternalAntiPattern.g:743:3: 'NAMING_CONVENTION'
                    {
                     before(grammarAccess.getConventionAccess().getCNAMING_CONVENTIONKeyword_0_0()); 
                    match(input,20,FOLLOW_2); 
                     after(grammarAccess.getConventionAccess().getCNAMING_CONVENTIONKeyword_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:748:2: ( 'Consistent_Parameter_Naming' )
                    {
                    // InternalAntiPattern.g:748:2: ( 'Consistent_Parameter_Naming' )
                    // InternalAntiPattern.g:749:3: 'Consistent_Parameter_Naming'
                    {
                     before(grammarAccess.getConventionAccess().getCConsistent_Parameter_NamingKeyword_0_1()); 
                    match(input,21,FOLLOW_2); 
                     after(grammarAccess.getConventionAccess().getCConsistent_Parameter_NamingKeyword_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:754:2: ( 'Single_Responsibility_Principle' )
                    {
                    // InternalAntiPattern.g:754:2: ( 'Single_Responsibility_Principle' )
                    // InternalAntiPattern.g:755:3: 'Single_Responsibility_Principle'
                    {
                     before(grammarAccess.getConventionAccess().getCSingle_Responsibility_PrincipleKeyword_0_2()); 
                    match(input,22,FOLLOW_2); 
                     after(grammarAccess.getConventionAccess().getCSingle_Responsibility_PrincipleKeyword_0_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalAntiPattern.g:760:2: ( 'Use_of_Comments' )
                    {
                    // InternalAntiPattern.g:760:2: ( 'Use_of_Comments' )
                    // InternalAntiPattern.g:761:3: 'Use_of_Comments'
                    {
                     before(grammarAccess.getConventionAccess().getCUse_of_CommentsKeyword_0_3()); 
                    match(input,23,FOLLOW_2); 
                     after(grammarAccess.getConventionAccess().getCUse_of_CommentsKeyword_0_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalAntiPattern.g:766:2: ( 'Avoid_Magic_Numbers' )
                    {
                    // InternalAntiPattern.g:766:2: ( 'Avoid_Magic_Numbers' )
                    // InternalAntiPattern.g:767:3: 'Avoid_Magic_Numbers'
                    {
                     before(grammarAccess.getConventionAccess().getCAvoid_Magic_NumbersKeyword_0_4()); 
                    match(input,24,FOLLOW_2); 
                     after(grammarAccess.getConventionAccess().getCAvoid_Magic_NumbersKeyword_0_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Convention__CAlternatives_0"


    // $ANTLR start "rule__Qunatity__QAlternatives_0"
    // InternalAntiPattern.g:776:1: rule__Qunatity__QAlternatives_0 : ( ( 'many' ) | ( 'few' ) );
    public final void rule__Qunatity__QAlternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:780:1: ( ( 'many' ) | ( 'few' ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==25) ) {
                alt8=1;
            }
            else if ( (LA8_0==26) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalAntiPattern.g:781:2: ( 'many' )
                    {
                    // InternalAntiPattern.g:781:2: ( 'many' )
                    // InternalAntiPattern.g:782:3: 'many'
                    {
                     before(grammarAccess.getQunatityAccess().getQManyKeyword_0_0()); 
                    match(input,25,FOLLOW_2); 
                     after(grammarAccess.getQunatityAccess().getQManyKeyword_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:787:2: ( 'few' )
                    {
                    // InternalAntiPattern.g:787:2: ( 'few' )
                    // InternalAntiPattern.g:788:3: 'few'
                    {
                     before(grammarAccess.getQunatityAccess().getQFewKeyword_0_1()); 
                    match(input,26,FOLLOW_2); 
                     after(grammarAccess.getQunatityAccess().getQFewKeyword_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qunatity__QAlternatives_0"


    // $ANTLR start "rule__Manner__MannerAlternatives_0"
    // InternalAntiPattern.g:797:1: rule__Manner__MannerAlternatives_0 : ( ( 'Complex_Logical_Expressions' ) | ( 'ifNestedStructures' ) | ( 'switchNestedStructures' ) | ( 'loopNestedStructures' ) | ( 'ExecutableStatments' ) | ( 'Declare_Variables_Separately' ) | ( 'Add_Comments' ) | ( 'Exception_Handling' ) | ( 'Use_Recursion' ) | ( 'Use_Global_Variables' ) | ( 'unrelatedFonctionnalities' ) );
    public final void rule__Manner__MannerAlternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:801:1: ( ( 'Complex_Logical_Expressions' ) | ( 'ifNestedStructures' ) | ( 'switchNestedStructures' ) | ( 'loopNestedStructures' ) | ( 'ExecutableStatments' ) | ( 'Declare_Variables_Separately' ) | ( 'Add_Comments' ) | ( 'Exception_Handling' ) | ( 'Use_Recursion' ) | ( 'Use_Global_Variables' ) | ( 'unrelatedFonctionnalities' ) )
            int alt9=11;
            switch ( input.LA(1) ) {
            case 27:
                {
                alt9=1;
                }
                break;
            case 28:
                {
                alt9=2;
                }
                break;
            case 29:
                {
                alt9=3;
                }
                break;
            case 30:
                {
                alt9=4;
                }
                break;
            case 31:
                {
                alt9=5;
                }
                break;
            case 32:
                {
                alt9=6;
                }
                break;
            case 33:
                {
                alt9=7;
                }
                break;
            case 34:
                {
                alt9=8;
                }
                break;
            case 35:
                {
                alt9=9;
                }
                break;
            case 36:
                {
                alt9=10;
                }
                break;
            case 37:
                {
                alt9=11;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalAntiPattern.g:802:2: ( 'Complex_Logical_Expressions' )
                    {
                    // InternalAntiPattern.g:802:2: ( 'Complex_Logical_Expressions' )
                    // InternalAntiPattern.g:803:3: 'Complex_Logical_Expressions'
                    {
                     before(grammarAccess.getMannerAccess().getMannerComplex_Logical_ExpressionsKeyword_0_0()); 
                    match(input,27,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerComplex_Logical_ExpressionsKeyword_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:808:2: ( 'ifNestedStructures' )
                    {
                    // InternalAntiPattern.g:808:2: ( 'ifNestedStructures' )
                    // InternalAntiPattern.g:809:3: 'ifNestedStructures'
                    {
                     before(grammarAccess.getMannerAccess().getMannerIfNestedStructuresKeyword_0_1()); 
                    match(input,28,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerIfNestedStructuresKeyword_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:814:2: ( 'switchNestedStructures' )
                    {
                    // InternalAntiPattern.g:814:2: ( 'switchNestedStructures' )
                    // InternalAntiPattern.g:815:3: 'switchNestedStructures'
                    {
                     before(grammarAccess.getMannerAccess().getMannerSwitchNestedStructuresKeyword_0_2()); 
                    match(input,29,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerSwitchNestedStructuresKeyword_0_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalAntiPattern.g:820:2: ( 'loopNestedStructures' )
                    {
                    // InternalAntiPattern.g:820:2: ( 'loopNestedStructures' )
                    // InternalAntiPattern.g:821:3: 'loopNestedStructures'
                    {
                     before(grammarAccess.getMannerAccess().getMannerLoopNestedStructuresKeyword_0_3()); 
                    match(input,30,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerLoopNestedStructuresKeyword_0_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalAntiPattern.g:826:2: ( 'ExecutableStatments' )
                    {
                    // InternalAntiPattern.g:826:2: ( 'ExecutableStatments' )
                    // InternalAntiPattern.g:827:3: 'ExecutableStatments'
                    {
                     before(grammarAccess.getMannerAccess().getMannerExecutableStatmentsKeyword_0_4()); 
                    match(input,31,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerExecutableStatmentsKeyword_0_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalAntiPattern.g:832:2: ( 'Declare_Variables_Separately' )
                    {
                    // InternalAntiPattern.g:832:2: ( 'Declare_Variables_Separately' )
                    // InternalAntiPattern.g:833:3: 'Declare_Variables_Separately'
                    {
                     before(grammarAccess.getMannerAccess().getMannerDeclare_Variables_SeparatelyKeyword_0_5()); 
                    match(input,32,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerDeclare_Variables_SeparatelyKeyword_0_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalAntiPattern.g:838:2: ( 'Add_Comments' )
                    {
                    // InternalAntiPattern.g:838:2: ( 'Add_Comments' )
                    // InternalAntiPattern.g:839:3: 'Add_Comments'
                    {
                     before(grammarAccess.getMannerAccess().getMannerAdd_CommentsKeyword_0_6()); 
                    match(input,33,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerAdd_CommentsKeyword_0_6()); 

                    }


                    }
                    break;
                case 8 :
                    // InternalAntiPattern.g:844:2: ( 'Exception_Handling' )
                    {
                    // InternalAntiPattern.g:844:2: ( 'Exception_Handling' )
                    // InternalAntiPattern.g:845:3: 'Exception_Handling'
                    {
                     before(grammarAccess.getMannerAccess().getMannerException_HandlingKeyword_0_7()); 
                    match(input,34,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerException_HandlingKeyword_0_7()); 

                    }


                    }
                    break;
                case 9 :
                    // InternalAntiPattern.g:850:2: ( 'Use_Recursion' )
                    {
                    // InternalAntiPattern.g:850:2: ( 'Use_Recursion' )
                    // InternalAntiPattern.g:851:3: 'Use_Recursion'
                    {
                     before(grammarAccess.getMannerAccess().getMannerUse_RecursionKeyword_0_8()); 
                    match(input,35,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerUse_RecursionKeyword_0_8()); 

                    }


                    }
                    break;
                case 10 :
                    // InternalAntiPattern.g:856:2: ( 'Use_Global_Variables' )
                    {
                    // InternalAntiPattern.g:856:2: ( 'Use_Global_Variables' )
                    // InternalAntiPattern.g:857:3: 'Use_Global_Variables'
                    {
                     before(grammarAccess.getMannerAccess().getMannerUse_Global_VariablesKeyword_0_9()); 
                    match(input,36,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerUse_Global_VariablesKeyword_0_9()); 

                    }


                    }
                    break;
                case 11 :
                    // InternalAntiPattern.g:862:2: ( 'unrelatedFonctionnalities' )
                    {
                    // InternalAntiPattern.g:862:2: ( 'unrelatedFonctionnalities' )
                    // InternalAntiPattern.g:863:3: 'unrelatedFonctionnalities'
                    {
                     before(grammarAccess.getMannerAccess().getMannerUnrelatedFonctionnalitiesKeyword_0_10()); 
                    match(input,37,FOLLOW_2); 
                     after(grammarAccess.getMannerAccess().getMannerUnrelatedFonctionnalitiesKeyword_0_10()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Manner__MannerAlternatives_0"


    // $ANTLR start "rule__Param__PAlternatives_0"
    // InternalAntiPattern.g:872:1: rule__Param__PAlternatives_0 : ( ( 'method' ) | ( 'otherClass' ) | ( 'ownClass' ) );
    public final void rule__Param__PAlternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:876:1: ( ( 'method' ) | ( 'otherClass' ) | ( 'ownClass' ) )
            int alt10=3;
            switch ( input.LA(1) ) {
            case 38:
                {
                alt10=1;
                }
                break;
            case 39:
                {
                alt10=2;
                }
                break;
            case 40:
                {
                alt10=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // InternalAntiPattern.g:877:2: ( 'method' )
                    {
                    // InternalAntiPattern.g:877:2: ( 'method' )
                    // InternalAntiPattern.g:878:3: 'method'
                    {
                     before(grammarAccess.getParamAccess().getPMethodKeyword_0_0()); 
                    match(input,38,FOLLOW_2); 
                     after(grammarAccess.getParamAccess().getPMethodKeyword_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:883:2: ( 'otherClass' )
                    {
                    // InternalAntiPattern.g:883:2: ( 'otherClass' )
                    // InternalAntiPattern.g:884:3: 'otherClass'
                    {
                     before(grammarAccess.getParamAccess().getPOtherClassKeyword_0_1()); 
                    match(input,39,FOLLOW_2); 
                     after(grammarAccess.getParamAccess().getPOtherClassKeyword_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalAntiPattern.g:889:2: ( 'ownClass' )
                    {
                    // InternalAntiPattern.g:889:2: ( 'ownClass' )
                    // InternalAntiPattern.g:890:3: 'ownClass'
                    {
                     before(grammarAccess.getParamAccess().getPOwnClassKeyword_0_2()); 
                    match(input,40,FOLLOW_2); 
                     after(grammarAccess.getParamAccess().getPOwnClassKeyword_0_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Param__PAlternatives_0"


    // $ANTLR start "rule__NUMERIC_VALUE__Alternatives"
    // InternalAntiPattern.g:899:1: rule__NUMERIC_VALUE__Alternatives : ( ( ( rule__NUMERIC_VALUE__Group_0__0 ) ) | ( RULE_INT ) );
    public final void rule__NUMERIC_VALUE__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:903:1: ( ( ( rule__NUMERIC_VALUE__Group_0__0 ) ) | ( RULE_INT ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==RULE_INT) ) {
                int LA11_1 = input.LA(2);

                if ( (LA11_1==EOF||LA11_1==43||(LA11_1>=50 && LA11_1<=52)||LA11_1==56) ) {
                    alt11=2;
                }
                else if ( (LA11_1==55) ) {
                    alt11=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 11, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalAntiPattern.g:904:2: ( ( rule__NUMERIC_VALUE__Group_0__0 ) )
                    {
                    // InternalAntiPattern.g:904:2: ( ( rule__NUMERIC_VALUE__Group_0__0 ) )
                    // InternalAntiPattern.g:905:3: ( rule__NUMERIC_VALUE__Group_0__0 )
                    {
                     before(grammarAccess.getNUMERIC_VALUEAccess().getGroup_0()); 
                    // InternalAntiPattern.g:906:3: ( rule__NUMERIC_VALUE__Group_0__0 )
                    // InternalAntiPattern.g:906:4: rule__NUMERIC_VALUE__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__NUMERIC_VALUE__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getNUMERIC_VALUEAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:910:2: ( RULE_INT )
                    {
                    // InternalAntiPattern.g:910:2: ( RULE_INT )
                    // InternalAntiPattern.g:911:3: RULE_INT
                    {
                     before(grammarAccess.getNUMERIC_VALUEAccess().getINTTerminalRuleCall_1()); 
                    match(input,RULE_INT,FOLLOW_2); 
                     after(grammarAccess.getNUMERIC_VALUEAccess().getINTTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NUMERIC_VALUE__Alternatives"


    // $ANTLR start "rule__Prompt__Group__0"
    // InternalAntiPattern.g:920:1: rule__Prompt__Group__0 : rule__Prompt__Group__0__Impl rule__Prompt__Group__1 ;
    public final void rule__Prompt__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:924:1: ( rule__Prompt__Group__0__Impl rule__Prompt__Group__1 )
            // InternalAntiPattern.g:925:2: rule__Prompt__Group__0__Impl rule__Prompt__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Prompt__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prompt__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prompt__Group__0"


    // $ANTLR start "rule__Prompt__Group__0__Impl"
    // InternalAntiPattern.g:932:1: rule__Prompt__Group__0__Impl : ( 'Prompt' ) ;
    public final void rule__Prompt__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:936:1: ( ( 'Prompt' ) )
            // InternalAntiPattern.g:937:1: ( 'Prompt' )
            {
            // InternalAntiPattern.g:937:1: ( 'Prompt' )
            // InternalAntiPattern.g:938:2: 'Prompt'
            {
             before(grammarAccess.getPromptAccess().getPromptKeyword_0()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getPromptAccess().getPromptKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prompt__Group__0__Impl"


    // $ANTLR start "rule__Prompt__Group__1"
    // InternalAntiPattern.g:947:1: rule__Prompt__Group__1 : rule__Prompt__Group__1__Impl rule__Prompt__Group__2 ;
    public final void rule__Prompt__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:951:1: ( rule__Prompt__Group__1__Impl rule__Prompt__Group__2 )
            // InternalAntiPattern.g:952:2: rule__Prompt__Group__1__Impl rule__Prompt__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Prompt__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prompt__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prompt__Group__1"


    // $ANTLR start "rule__Prompt__Group__1__Impl"
    // InternalAntiPattern.g:959:1: rule__Prompt__Group__1__Impl : ( '{' ) ;
    public final void rule__Prompt__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:963:1: ( ( '{' ) )
            // InternalAntiPattern.g:964:1: ( '{' )
            {
            // InternalAntiPattern.g:964:1: ( '{' )
            // InternalAntiPattern.g:965:2: '{'
            {
             before(grammarAccess.getPromptAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getPromptAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prompt__Group__1__Impl"


    // $ANTLR start "rule__Prompt__Group__2"
    // InternalAntiPattern.g:974:1: rule__Prompt__Group__2 : rule__Prompt__Group__2__Impl rule__Prompt__Group__3 ;
    public final void rule__Prompt__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:978:1: ( rule__Prompt__Group__2__Impl rule__Prompt__Group__3 )
            // InternalAntiPattern.g:979:2: rule__Prompt__Group__2__Impl rule__Prompt__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__Prompt__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prompt__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prompt__Group__2"


    // $ANTLR start "rule__Prompt__Group__2__Impl"
    // InternalAntiPattern.g:986:1: rule__Prompt__Group__2__Impl : ( ( rule__Prompt__ContentAssignment_2 ) ) ;
    public final void rule__Prompt__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:990:1: ( ( ( rule__Prompt__ContentAssignment_2 ) ) )
            // InternalAntiPattern.g:991:1: ( ( rule__Prompt__ContentAssignment_2 ) )
            {
            // InternalAntiPattern.g:991:1: ( ( rule__Prompt__ContentAssignment_2 ) )
            // InternalAntiPattern.g:992:2: ( rule__Prompt__ContentAssignment_2 )
            {
             before(grammarAccess.getPromptAccess().getContentAssignment_2()); 
            // InternalAntiPattern.g:993:2: ( rule__Prompt__ContentAssignment_2 )
            // InternalAntiPattern.g:993:3: rule__Prompt__ContentAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Prompt__ContentAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getPromptAccess().getContentAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prompt__Group__2__Impl"


    // $ANTLR start "rule__Prompt__Group__3"
    // InternalAntiPattern.g:1001:1: rule__Prompt__Group__3 : rule__Prompt__Group__3__Impl ;
    public final void rule__Prompt__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1005:1: ( rule__Prompt__Group__3__Impl )
            // InternalAntiPattern.g:1006:2: rule__Prompt__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Prompt__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prompt__Group__3"


    // $ANTLR start "rule__Prompt__Group__3__Impl"
    // InternalAntiPattern.g:1012:1: rule__Prompt__Group__3__Impl : ( '}' ) ;
    public final void rule__Prompt__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1016:1: ( ( '}' ) )
            // InternalAntiPattern.g:1017:1: ( '}' )
            {
            // InternalAntiPattern.g:1017:1: ( '}' )
            // InternalAntiPattern.g:1018:2: '}'
            {
             before(grammarAccess.getPromptAccess().getRightCurlyBracketKeyword_3()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getPromptAccess().getRightCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prompt__Group__3__Impl"


    // $ANTLR start "rule__ContentPrompt__Group__0"
    // InternalAntiPattern.g:1028:1: rule__ContentPrompt__Group__0 : rule__ContentPrompt__Group__0__Impl rule__ContentPrompt__Group__1 ;
    public final void rule__ContentPrompt__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1032:1: ( rule__ContentPrompt__Group__0__Impl rule__ContentPrompt__Group__1 )
            // InternalAntiPattern.g:1033:2: rule__ContentPrompt__Group__0__Impl rule__ContentPrompt__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__ContentPrompt__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ContentPrompt__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__Group__0"


    // $ANTLR start "rule__ContentPrompt__Group__0__Impl"
    // InternalAntiPattern.g:1040:1: rule__ContentPrompt__Group__0__Impl : ( ( rule__ContentPrompt__NbexembleAssignment_0 ) ) ;
    public final void rule__ContentPrompt__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1044:1: ( ( ( rule__ContentPrompt__NbexembleAssignment_0 ) ) )
            // InternalAntiPattern.g:1045:1: ( ( rule__ContentPrompt__NbexembleAssignment_0 ) )
            {
            // InternalAntiPattern.g:1045:1: ( ( rule__ContentPrompt__NbexembleAssignment_0 ) )
            // InternalAntiPattern.g:1046:2: ( rule__ContentPrompt__NbexembleAssignment_0 )
            {
             before(grammarAccess.getContentPromptAccess().getNbexembleAssignment_0()); 
            // InternalAntiPattern.g:1047:2: ( rule__ContentPrompt__NbexembleAssignment_0 )
            // InternalAntiPattern.g:1047:3: rule__ContentPrompt__NbexembleAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ContentPrompt__NbexembleAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getContentPromptAccess().getNbexembleAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__Group__0__Impl"


    // $ANTLR start "rule__ContentPrompt__Group__1"
    // InternalAntiPattern.g:1055:1: rule__ContentPrompt__Group__1 : rule__ContentPrompt__Group__1__Impl rule__ContentPrompt__Group__2 ;
    public final void rule__ContentPrompt__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1059:1: ( rule__ContentPrompt__Group__1__Impl rule__ContentPrompt__Group__2 )
            // InternalAntiPattern.g:1060:2: rule__ContentPrompt__Group__1__Impl rule__ContentPrompt__Group__2
            {
            pushFollow(FOLLOW_8);
            rule__ContentPrompt__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ContentPrompt__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__Group__1"


    // $ANTLR start "rule__ContentPrompt__Group__1__Impl"
    // InternalAntiPattern.g:1067:1: rule__ContentPrompt__Group__1__Impl : ( ( rule__ContentPrompt__DomainAssignment_1 ) ) ;
    public final void rule__ContentPrompt__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1071:1: ( ( ( rule__ContentPrompt__DomainAssignment_1 ) ) )
            // InternalAntiPattern.g:1072:1: ( ( rule__ContentPrompt__DomainAssignment_1 ) )
            {
            // InternalAntiPattern.g:1072:1: ( ( rule__ContentPrompt__DomainAssignment_1 ) )
            // InternalAntiPattern.g:1073:2: ( rule__ContentPrompt__DomainAssignment_1 )
            {
             before(grammarAccess.getContentPromptAccess().getDomainAssignment_1()); 
            // InternalAntiPattern.g:1074:2: ( rule__ContentPrompt__DomainAssignment_1 )
            // InternalAntiPattern.g:1074:3: rule__ContentPrompt__DomainAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ContentPrompt__DomainAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getContentPromptAccess().getDomainAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__Group__1__Impl"


    // $ANTLR start "rule__ContentPrompt__Group__2"
    // InternalAntiPattern.g:1082:1: rule__ContentPrompt__Group__2 : rule__ContentPrompt__Group__2__Impl rule__ContentPrompt__Group__3 ;
    public final void rule__ContentPrompt__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1086:1: ( rule__ContentPrompt__Group__2__Impl rule__ContentPrompt__Group__3 )
            // InternalAntiPattern.g:1087:2: rule__ContentPrompt__Group__2__Impl rule__ContentPrompt__Group__3
            {
            pushFollow(FOLLOW_9);
            rule__ContentPrompt__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ContentPrompt__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__Group__2"


    // $ANTLR start "rule__ContentPrompt__Group__2__Impl"
    // InternalAntiPattern.g:1094:1: rule__ContentPrompt__Group__2__Impl : ( ( rule__ContentPrompt__ClasseAssignment_2 ) ) ;
    public final void rule__ContentPrompt__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1098:1: ( ( ( rule__ContentPrompt__ClasseAssignment_2 ) ) )
            // InternalAntiPattern.g:1099:1: ( ( rule__ContentPrompt__ClasseAssignment_2 ) )
            {
            // InternalAntiPattern.g:1099:1: ( ( rule__ContentPrompt__ClasseAssignment_2 ) )
            // InternalAntiPattern.g:1100:2: ( rule__ContentPrompt__ClasseAssignment_2 )
            {
             before(grammarAccess.getContentPromptAccess().getClasseAssignment_2()); 
            // InternalAntiPattern.g:1101:2: ( rule__ContentPrompt__ClasseAssignment_2 )
            // InternalAntiPattern.g:1101:3: rule__ContentPrompt__ClasseAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__ContentPrompt__ClasseAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getContentPromptAccess().getClasseAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__Group__2__Impl"


    // $ANTLR start "rule__ContentPrompt__Group__3"
    // InternalAntiPattern.g:1109:1: rule__ContentPrompt__Group__3 : rule__ContentPrompt__Group__3__Impl ;
    public final void rule__ContentPrompt__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1113:1: ( rule__ContentPrompt__Group__3__Impl )
            // InternalAntiPattern.g:1114:2: rule__ContentPrompt__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ContentPrompt__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__Group__3"


    // $ANTLR start "rule__ContentPrompt__Group__3__Impl"
    // InternalAntiPattern.g:1120:1: rule__ContentPrompt__Group__3__Impl : ( ( rule__ContentPrompt__MethodAssignment_3 ) ) ;
    public final void rule__ContentPrompt__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1124:1: ( ( ( rule__ContentPrompt__MethodAssignment_3 ) ) )
            // InternalAntiPattern.g:1125:1: ( ( rule__ContentPrompt__MethodAssignment_3 ) )
            {
            // InternalAntiPattern.g:1125:1: ( ( rule__ContentPrompt__MethodAssignment_3 ) )
            // InternalAntiPattern.g:1126:2: ( rule__ContentPrompt__MethodAssignment_3 )
            {
             before(grammarAccess.getContentPromptAccess().getMethodAssignment_3()); 
            // InternalAntiPattern.g:1127:2: ( rule__ContentPrompt__MethodAssignment_3 )
            // InternalAntiPattern.g:1127:3: rule__ContentPrompt__MethodAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__ContentPrompt__MethodAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getContentPromptAccess().getMethodAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__Group__3__Impl"


    // $ANTLR start "rule__Exemples__Group__0"
    // InternalAntiPattern.g:1136:1: rule__Exemples__Group__0 : rule__Exemples__Group__0__Impl rule__Exemples__Group__1 ;
    public final void rule__Exemples__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1140:1: ( rule__Exemples__Group__0__Impl rule__Exemples__Group__1 )
            // InternalAntiPattern.g:1141:2: rule__Exemples__Group__0__Impl rule__Exemples__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__Exemples__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Exemples__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exemples__Group__0"


    // $ANTLR start "rule__Exemples__Group__0__Impl"
    // InternalAntiPattern.g:1148:1: rule__Exemples__Group__0__Impl : ( 'nbExemples:' ) ;
    public final void rule__Exemples__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1152:1: ( ( 'nbExemples:' ) )
            // InternalAntiPattern.g:1153:1: ( 'nbExemples:' )
            {
            // InternalAntiPattern.g:1153:1: ( 'nbExemples:' )
            // InternalAntiPattern.g:1154:2: 'nbExemples:'
            {
             before(grammarAccess.getExemplesAccess().getNbExemplesKeyword_0()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getExemplesAccess().getNbExemplesKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exemples__Group__0__Impl"


    // $ANTLR start "rule__Exemples__Group__1"
    // InternalAntiPattern.g:1163:1: rule__Exemples__Group__1 : rule__Exemples__Group__1__Impl ;
    public final void rule__Exemples__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1167:1: ( rule__Exemples__Group__1__Impl )
            // InternalAntiPattern.g:1168:2: rule__Exemples__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Exemples__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exemples__Group__1"


    // $ANTLR start "rule__Exemples__Group__1__Impl"
    // InternalAntiPattern.g:1174:1: rule__Exemples__Group__1__Impl : ( ( rule__Exemples__NbExemplesAssignment_1 ) ) ;
    public final void rule__Exemples__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1178:1: ( ( ( rule__Exemples__NbExemplesAssignment_1 ) ) )
            // InternalAntiPattern.g:1179:1: ( ( rule__Exemples__NbExemplesAssignment_1 ) )
            {
            // InternalAntiPattern.g:1179:1: ( ( rule__Exemples__NbExemplesAssignment_1 ) )
            // InternalAntiPattern.g:1180:2: ( rule__Exemples__NbExemplesAssignment_1 )
            {
             before(grammarAccess.getExemplesAccess().getNbExemplesAssignment_1()); 
            // InternalAntiPattern.g:1181:2: ( rule__Exemples__NbExemplesAssignment_1 )
            // InternalAntiPattern.g:1181:3: rule__Exemples__NbExemplesAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Exemples__NbExemplesAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getExemplesAccess().getNbExemplesAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exemples__Group__1__Impl"


    // $ANTLR start "rule__Domain__Group__0"
    // InternalAntiPattern.g:1190:1: rule__Domain__Group__0 : rule__Domain__Group__0__Impl rule__Domain__Group__1 ;
    public final void rule__Domain__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1194:1: ( rule__Domain__Group__0__Impl rule__Domain__Group__1 )
            // InternalAntiPattern.g:1195:2: rule__Domain__Group__0__Impl rule__Domain__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__Domain__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Domain__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Domain__Group__0"


    // $ANTLR start "rule__Domain__Group__0__Impl"
    // InternalAntiPattern.g:1202:1: rule__Domain__Group__0__Impl : ( 'Domain:' ) ;
    public final void rule__Domain__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1206:1: ( ( 'Domain:' ) )
            // InternalAntiPattern.g:1207:1: ( 'Domain:' )
            {
            // InternalAntiPattern.g:1207:1: ( 'Domain:' )
            // InternalAntiPattern.g:1208:2: 'Domain:'
            {
             before(grammarAccess.getDomainAccess().getDomainKeyword_0()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getDomainAccess().getDomainKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Domain__Group__0__Impl"


    // $ANTLR start "rule__Domain__Group__1"
    // InternalAntiPattern.g:1217:1: rule__Domain__Group__1 : rule__Domain__Group__1__Impl ;
    public final void rule__Domain__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1221:1: ( rule__Domain__Group__1__Impl )
            // InternalAntiPattern.g:1222:2: rule__Domain__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Domain__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Domain__Group__1"


    // $ANTLR start "rule__Domain__Group__1__Impl"
    // InternalAntiPattern.g:1228:1: rule__Domain__Group__1__Impl : ( ( rule__Domain__DomainNameAssignment_1 ) ) ;
    public final void rule__Domain__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1232:1: ( ( ( rule__Domain__DomainNameAssignment_1 ) ) )
            // InternalAntiPattern.g:1233:1: ( ( rule__Domain__DomainNameAssignment_1 ) )
            {
            // InternalAntiPattern.g:1233:1: ( ( rule__Domain__DomainNameAssignment_1 ) )
            // InternalAntiPattern.g:1234:2: ( rule__Domain__DomainNameAssignment_1 )
            {
             before(grammarAccess.getDomainAccess().getDomainNameAssignment_1()); 
            // InternalAntiPattern.g:1235:2: ( rule__Domain__DomainNameAssignment_1 )
            // InternalAntiPattern.g:1235:3: rule__Domain__DomainNameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Domain__DomainNameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getDomainAccess().getDomainNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Domain__Group__1__Impl"


    // $ANTLR start "rule__Classes__Group__0"
    // InternalAntiPattern.g:1244:1: rule__Classes__Group__0 : rule__Classes__Group__0__Impl rule__Classes__Group__1 ;
    public final void rule__Classes__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1248:1: ( rule__Classes__Group__0__Impl rule__Classes__Group__1 )
            // InternalAntiPattern.g:1249:2: rule__Classes__Group__0__Impl rule__Classes__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__Classes__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Classes__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Classes__Group__0"


    // $ANTLR start "rule__Classes__Group__0__Impl"
    // InternalAntiPattern.g:1256:1: rule__Classes__Group__0__Impl : ( 'Classes:' ) ;
    public final void rule__Classes__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1260:1: ( ( 'Classes:' ) )
            // InternalAntiPattern.g:1261:1: ( 'Classes:' )
            {
            // InternalAntiPattern.g:1261:1: ( 'Classes:' )
            // InternalAntiPattern.g:1262:2: 'Classes:'
            {
             before(grammarAccess.getClassesAccess().getClassesKeyword_0()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getClassesAccess().getClassesKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Classes__Group__0__Impl"


    // $ANTLR start "rule__Classes__Group__1"
    // InternalAntiPattern.g:1271:1: rule__Classes__Group__1 : rule__Classes__Group__1__Impl rule__Classes__Group__2 ;
    public final void rule__Classes__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1275:1: ( rule__Classes__Group__1__Impl rule__Classes__Group__2 )
            // InternalAntiPattern.g:1276:2: rule__Classes__Group__1__Impl rule__Classes__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__Classes__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Classes__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Classes__Group__1"


    // $ANTLR start "rule__Classes__Group__1__Impl"
    // InternalAntiPattern.g:1283:1: rule__Classes__Group__1__Impl : ( ( rule__Classes__NbClassAssignment_1 ) ) ;
    public final void rule__Classes__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1287:1: ( ( ( rule__Classes__NbClassAssignment_1 ) ) )
            // InternalAntiPattern.g:1288:1: ( ( rule__Classes__NbClassAssignment_1 ) )
            {
            // InternalAntiPattern.g:1288:1: ( ( rule__Classes__NbClassAssignment_1 ) )
            // InternalAntiPattern.g:1289:2: ( rule__Classes__NbClassAssignment_1 )
            {
             before(grammarAccess.getClassesAccess().getNbClassAssignment_1()); 
            // InternalAntiPattern.g:1290:2: ( rule__Classes__NbClassAssignment_1 )
            // InternalAntiPattern.g:1290:3: rule__Classes__NbClassAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Classes__NbClassAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getClassesAccess().getNbClassAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Classes__Group__1__Impl"


    // $ANTLR start "rule__Classes__Group__2"
    // InternalAntiPattern.g:1298:1: rule__Classes__Group__2 : rule__Classes__Group__2__Impl ;
    public final void rule__Classes__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1302:1: ( rule__Classes__Group__2__Impl )
            // InternalAntiPattern.g:1303:2: rule__Classes__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Classes__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Classes__Group__2"


    // $ANTLR start "rule__Classes__Group__2__Impl"
    // InternalAntiPattern.g:1309:1: rule__Classes__Group__2__Impl : ( ( rule__Classes___classAssignment_2 )* ) ;
    public final void rule__Classes__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1313:1: ( ( ( rule__Classes___classAssignment_2 )* ) )
            // InternalAntiPattern.g:1314:1: ( ( rule__Classes___classAssignment_2 )* )
            {
            // InternalAntiPattern.g:1314:1: ( ( rule__Classes___classAssignment_2 )* )
            // InternalAntiPattern.g:1315:2: ( rule__Classes___classAssignment_2 )*
            {
             before(grammarAccess.getClassesAccess().get_classAssignment_2()); 
            // InternalAntiPattern.g:1316:2: ( rule__Classes___classAssignment_2 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==47) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalAntiPattern.g:1316:3: rule__Classes___classAssignment_2
            	    {
            	    pushFollow(FOLLOW_13);
            	    rule__Classes___classAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getClassesAccess().get_classAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Classes__Group__2__Impl"


    // $ANTLR start "rule___Class__Group__0"
    // InternalAntiPattern.g:1325:1: rule___Class__Group__0 : rule___Class__Group__0__Impl rule___Class__Group__1 ;
    public final void rule___Class__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1329:1: ( rule___Class__Group__0__Impl rule___Class__Group__1 )
            // InternalAntiPattern.g:1330:2: rule___Class__Group__0__Impl rule___Class__Group__1
            {
            pushFollow(FOLLOW_11);
            rule___Class__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule___Class__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule___Class__Group__0"


    // $ANTLR start "rule___Class__Group__0__Impl"
    // InternalAntiPattern.g:1337:1: rule___Class__Group__0__Impl : ( 'class:' ) ;
    public final void rule___Class__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1341:1: ( ( 'class:' ) )
            // InternalAntiPattern.g:1342:1: ( 'class:' )
            {
            // InternalAntiPattern.g:1342:1: ( 'class:' )
            // InternalAntiPattern.g:1343:2: 'class:'
            {
             before(grammarAccess.get_ClassAccess().getClassKeyword_0()); 
            match(input,47,FOLLOW_2); 
             after(grammarAccess.get_ClassAccess().getClassKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule___Class__Group__0__Impl"


    // $ANTLR start "rule___Class__Group__1"
    // InternalAntiPattern.g:1352:1: rule___Class__Group__1 : rule___Class__Group__1__Impl ;
    public final void rule___Class__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1356:1: ( rule___Class__Group__1__Impl )
            // InternalAntiPattern.g:1357:2: rule___Class__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule___Class__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule___Class__Group__1"


    // $ANTLR start "rule___Class__Group__1__Impl"
    // InternalAntiPattern.g:1363:1: rule___Class__Group__1__Impl : ( ( rule___Class__ClassNameAssignment_1 ) ) ;
    public final void rule___Class__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1367:1: ( ( ( rule___Class__ClassNameAssignment_1 ) ) )
            // InternalAntiPattern.g:1368:1: ( ( rule___Class__ClassNameAssignment_1 ) )
            {
            // InternalAntiPattern.g:1368:1: ( ( rule___Class__ClassNameAssignment_1 ) )
            // InternalAntiPattern.g:1369:2: ( rule___Class__ClassNameAssignment_1 )
            {
             before(grammarAccess.get_ClassAccess().getClassNameAssignment_1()); 
            // InternalAntiPattern.g:1370:2: ( rule___Class__ClassNameAssignment_1 )
            // InternalAntiPattern.g:1370:3: rule___Class__ClassNameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule___Class__ClassNameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.get_ClassAccess().getClassNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule___Class__Group__1__Impl"


    // $ANTLR start "rule__ChosenMethod__Group__0"
    // InternalAntiPattern.g:1379:1: rule__ChosenMethod__Group__0 : rule__ChosenMethod__Group__0__Impl rule__ChosenMethod__Group__1 ;
    public final void rule__ChosenMethod__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1383:1: ( rule__ChosenMethod__Group__0__Impl rule__ChosenMethod__Group__1 )
            // InternalAntiPattern.g:1384:2: rule__ChosenMethod__Group__0__Impl rule__ChosenMethod__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__ChosenMethod__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ChosenMethod__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__0"


    // $ANTLR start "rule__ChosenMethod__Group__0__Impl"
    // InternalAntiPattern.g:1391:1: rule__ChosenMethod__Group__0__Impl : ( 'Method_In' ) ;
    public final void rule__ChosenMethod__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1395:1: ( ( 'Method_In' ) )
            // InternalAntiPattern.g:1396:1: ( 'Method_In' )
            {
            // InternalAntiPattern.g:1396:1: ( 'Method_In' )
            // InternalAntiPattern.g:1397:2: 'Method_In'
            {
             before(grammarAccess.getChosenMethodAccess().getMethod_InKeyword_0()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getChosenMethodAccess().getMethod_InKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__0__Impl"


    // $ANTLR start "rule__ChosenMethod__Group__1"
    // InternalAntiPattern.g:1406:1: rule__ChosenMethod__Group__1 : rule__ChosenMethod__Group__1__Impl rule__ChosenMethod__Group__2 ;
    public final void rule__ChosenMethod__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1410:1: ( rule__ChosenMethod__Group__1__Impl rule__ChosenMethod__Group__2 )
            // InternalAntiPattern.g:1411:2: rule__ChosenMethod__Group__1__Impl rule__ChosenMethod__Group__2
            {
            pushFollow(FOLLOW_14);
            rule__ChosenMethod__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ChosenMethod__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__1"


    // $ANTLR start "rule__ChosenMethod__Group__1__Impl"
    // InternalAntiPattern.g:1418:1: rule__ChosenMethod__Group__1__Impl : ( ( rule__ChosenMethod__ClassAssignment_1 ) ) ;
    public final void rule__ChosenMethod__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1422:1: ( ( ( rule__ChosenMethod__ClassAssignment_1 ) ) )
            // InternalAntiPattern.g:1423:1: ( ( rule__ChosenMethod__ClassAssignment_1 ) )
            {
            // InternalAntiPattern.g:1423:1: ( ( rule__ChosenMethod__ClassAssignment_1 ) )
            // InternalAntiPattern.g:1424:2: ( rule__ChosenMethod__ClassAssignment_1 )
            {
             before(grammarAccess.getChosenMethodAccess().getClassAssignment_1()); 
            // InternalAntiPattern.g:1425:2: ( rule__ChosenMethod__ClassAssignment_1 )
            // InternalAntiPattern.g:1425:3: rule__ChosenMethod__ClassAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ChosenMethod__ClassAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getChosenMethodAccess().getClassAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__1__Impl"


    // $ANTLR start "rule__ChosenMethod__Group__2"
    // InternalAntiPattern.g:1433:1: rule__ChosenMethod__Group__2 : rule__ChosenMethod__Group__2__Impl rule__ChosenMethod__Group__3 ;
    public final void rule__ChosenMethod__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1437:1: ( rule__ChosenMethod__Group__2__Impl rule__ChosenMethod__Group__3 )
            // InternalAntiPattern.g:1438:2: rule__ChosenMethod__Group__2__Impl rule__ChosenMethod__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__ChosenMethod__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ChosenMethod__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__2"


    // $ANTLR start "rule__ChosenMethod__Group__2__Impl"
    // InternalAntiPattern.g:1445:1: rule__ChosenMethod__Group__2__Impl : ( 'conditions:' ) ;
    public final void rule__ChosenMethod__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1449:1: ( ( 'conditions:' ) )
            // InternalAntiPattern.g:1450:1: ( 'conditions:' )
            {
            // InternalAntiPattern.g:1450:1: ( 'conditions:' )
            // InternalAntiPattern.g:1451:2: 'conditions:'
            {
             before(grammarAccess.getChosenMethodAccess().getConditionsKeyword_2()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getChosenMethodAccess().getConditionsKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__2__Impl"


    // $ANTLR start "rule__ChosenMethod__Group__3"
    // InternalAntiPattern.g:1460:1: rule__ChosenMethod__Group__3 : rule__ChosenMethod__Group__3__Impl rule__ChosenMethod__Group__4 ;
    public final void rule__ChosenMethod__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1464:1: ( rule__ChosenMethod__Group__3__Impl rule__ChosenMethod__Group__4 )
            // InternalAntiPattern.g:1465:2: rule__ChosenMethod__Group__3__Impl rule__ChosenMethod__Group__4
            {
            pushFollow(FOLLOW_15);
            rule__ChosenMethod__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ChosenMethod__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__3"


    // $ANTLR start "rule__ChosenMethod__Group__3__Impl"
    // InternalAntiPattern.g:1472:1: rule__ChosenMethod__Group__3__Impl : ( '{' ) ;
    public final void rule__ChosenMethod__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1476:1: ( ( '{' ) )
            // InternalAntiPattern.g:1477:1: ( '{' )
            {
            // InternalAntiPattern.g:1477:1: ( '{' )
            // InternalAntiPattern.g:1478:2: '{'
            {
             before(grammarAccess.getChosenMethodAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getChosenMethodAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__3__Impl"


    // $ANTLR start "rule__ChosenMethod__Group__4"
    // InternalAntiPattern.g:1487:1: rule__ChosenMethod__Group__4 : rule__ChosenMethod__Group__4__Impl rule__ChosenMethod__Group__5 ;
    public final void rule__ChosenMethod__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1491:1: ( rule__ChosenMethod__Group__4__Impl rule__ChosenMethod__Group__5 )
            // InternalAntiPattern.g:1492:2: rule__ChosenMethod__Group__4__Impl rule__ChosenMethod__Group__5
            {
            pushFollow(FOLLOW_15);
            rule__ChosenMethod__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ChosenMethod__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__4"


    // $ANTLR start "rule__ChosenMethod__Group__4__Impl"
    // InternalAntiPattern.g:1499:1: rule__ChosenMethod__Group__4__Impl : ( ( rule__ChosenMethod__ConditionsAssignment_4 )* ) ;
    public final void rule__ChosenMethod__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1503:1: ( ( ( rule__ChosenMethod__ConditionsAssignment_4 )* ) )
            // InternalAntiPattern.g:1504:1: ( ( rule__ChosenMethod__ConditionsAssignment_4 )* )
            {
            // InternalAntiPattern.g:1504:1: ( ( rule__ChosenMethod__ConditionsAssignment_4 )* )
            // InternalAntiPattern.g:1505:2: ( rule__ChosenMethod__ConditionsAssignment_4 )*
            {
             before(grammarAccess.getChosenMethodAccess().getConditionsAssignment_4()); 
            // InternalAntiPattern.g:1506:2: ( rule__ChosenMethod__ConditionsAssignment_4 )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==50||LA13_0==56) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalAntiPattern.g:1506:3: rule__ChosenMethod__ConditionsAssignment_4
            	    {
            	    pushFollow(FOLLOW_16);
            	    rule__ChosenMethod__ConditionsAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

             after(grammarAccess.getChosenMethodAccess().getConditionsAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__4__Impl"


    // $ANTLR start "rule__ChosenMethod__Group__5"
    // InternalAntiPattern.g:1514:1: rule__ChosenMethod__Group__5 : rule__ChosenMethod__Group__5__Impl ;
    public final void rule__ChosenMethod__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1518:1: ( rule__ChosenMethod__Group__5__Impl )
            // InternalAntiPattern.g:1519:2: rule__ChosenMethod__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ChosenMethod__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__5"


    // $ANTLR start "rule__ChosenMethod__Group__5__Impl"
    // InternalAntiPattern.g:1525:1: rule__ChosenMethod__Group__5__Impl : ( '}' ) ;
    public final void rule__ChosenMethod__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1529:1: ( ( '}' ) )
            // InternalAntiPattern.g:1530:1: ( '}' )
            {
            // InternalAntiPattern.g:1530:1: ( '}' )
            // InternalAntiPattern.g:1531:2: '}'
            {
             before(grammarAccess.getChosenMethodAccess().getRightCurlyBracketKeyword_5()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getChosenMethodAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__Group__5__Impl"


    // $ANTLR start "rule__Condition__Group__0"
    // InternalAntiPattern.g:1541:1: rule__Condition__Group__0 : rule__Condition__Group__0__Impl rule__Condition__Group__1 ;
    public final void rule__Condition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1545:1: ( rule__Condition__Group__0__Impl rule__Condition__Group__1 )
            // InternalAntiPattern.g:1546:2: rule__Condition__Group__0__Impl rule__Condition__Group__1
            {
            pushFollow(FOLLOW_17);
            rule__Condition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Condition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__0"


    // $ANTLR start "rule__Condition__Group__0__Impl"
    // InternalAntiPattern.g:1553:1: rule__Condition__Group__0__Impl : ( ( rule__Condition__LinkAssignment_0 )? ) ;
    public final void rule__Condition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1557:1: ( ( ( rule__Condition__LinkAssignment_0 )? ) )
            // InternalAntiPattern.g:1558:1: ( ( rule__Condition__LinkAssignment_0 )? )
            {
            // InternalAntiPattern.g:1558:1: ( ( rule__Condition__LinkAssignment_0 )? )
            // InternalAntiPattern.g:1559:2: ( rule__Condition__LinkAssignment_0 )?
            {
             before(grammarAccess.getConditionAccess().getLinkAssignment_0()); 
            // InternalAntiPattern.g:1560:2: ( rule__Condition__LinkAssignment_0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==56) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalAntiPattern.g:1560:3: rule__Condition__LinkAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Condition__LinkAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getConditionAccess().getLinkAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__0__Impl"


    // $ANTLR start "rule__Condition__Group__1"
    // InternalAntiPattern.g:1568:1: rule__Condition__Group__1 : rule__Condition__Group__1__Impl rule__Condition__Group__2 ;
    public final void rule__Condition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1572:1: ( rule__Condition__Group__1__Impl rule__Condition__Group__2 )
            // InternalAntiPattern.g:1573:2: rule__Condition__Group__1__Impl rule__Condition__Group__2
            {
            pushFollow(FOLLOW_18);
            rule__Condition__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Condition__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__1"


    // $ANTLR start "rule__Condition__Group__1__Impl"
    // InternalAntiPattern.g:1580:1: rule__Condition__Group__1__Impl : ( '(' ) ;
    public final void rule__Condition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1584:1: ( ( '(' ) )
            // InternalAntiPattern.g:1585:1: ( '(' )
            {
            // InternalAntiPattern.g:1585:1: ( '(' )
            // InternalAntiPattern.g:1586:2: '('
            {
             before(grammarAccess.getConditionAccess().getLeftParenthesisKeyword_1()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getConditionAccess().getLeftParenthesisKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__1__Impl"


    // $ANTLR start "rule__Condition__Group__2"
    // InternalAntiPattern.g:1595:1: rule__Condition__Group__2 : rule__Condition__Group__2__Impl rule__Condition__Group__3 ;
    public final void rule__Condition__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1599:1: ( rule__Condition__Group__2__Impl rule__Condition__Group__3 )
            // InternalAntiPattern.g:1600:2: rule__Condition__Group__2__Impl rule__Condition__Group__3
            {
            pushFollow(FOLLOW_19);
            rule__Condition__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Condition__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__2"


    // $ANTLR start "rule__Condition__Group__2__Impl"
    // InternalAntiPattern.g:1607:1: rule__Condition__Group__2__Impl : ( ( rule__Condition__RulesAssignment_2 ) ) ;
    public final void rule__Condition__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1611:1: ( ( ( rule__Condition__RulesAssignment_2 ) ) )
            // InternalAntiPattern.g:1612:1: ( ( rule__Condition__RulesAssignment_2 ) )
            {
            // InternalAntiPattern.g:1612:1: ( ( rule__Condition__RulesAssignment_2 ) )
            // InternalAntiPattern.g:1613:2: ( rule__Condition__RulesAssignment_2 )
            {
             before(grammarAccess.getConditionAccess().getRulesAssignment_2()); 
            // InternalAntiPattern.g:1614:2: ( rule__Condition__RulesAssignment_2 )
            // InternalAntiPattern.g:1614:3: rule__Condition__RulesAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Condition__RulesAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getConditionAccess().getRulesAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__2__Impl"


    // $ANTLR start "rule__Condition__Group__3"
    // InternalAntiPattern.g:1622:1: rule__Condition__Group__3 : rule__Condition__Group__3__Impl rule__Condition__Group__4 ;
    public final void rule__Condition__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1626:1: ( rule__Condition__Group__3__Impl rule__Condition__Group__4 )
            // InternalAntiPattern.g:1627:2: rule__Condition__Group__3__Impl rule__Condition__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__Condition__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Condition__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__3"


    // $ANTLR start "rule__Condition__Group__3__Impl"
    // InternalAntiPattern.g:1634:1: rule__Condition__Group__3__Impl : ( ( rule__Condition__Group_3__0 )* ) ;
    public final void rule__Condition__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1638:1: ( ( ( rule__Condition__Group_3__0 )* ) )
            // InternalAntiPattern.g:1639:1: ( ( rule__Condition__Group_3__0 )* )
            {
            // InternalAntiPattern.g:1639:1: ( ( rule__Condition__Group_3__0 )* )
            // InternalAntiPattern.g:1640:2: ( rule__Condition__Group_3__0 )*
            {
             before(grammarAccess.getConditionAccess().getGroup_3()); 
            // InternalAntiPattern.g:1641:2: ( rule__Condition__Group_3__0 )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==52) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalAntiPattern.g:1641:3: rule__Condition__Group_3__0
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__Condition__Group_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

             after(grammarAccess.getConditionAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__3__Impl"


    // $ANTLR start "rule__Condition__Group__4"
    // InternalAntiPattern.g:1649:1: rule__Condition__Group__4 : rule__Condition__Group__4__Impl ;
    public final void rule__Condition__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1653:1: ( rule__Condition__Group__4__Impl )
            // InternalAntiPattern.g:1654:2: rule__Condition__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Condition__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__4"


    // $ANTLR start "rule__Condition__Group__4__Impl"
    // InternalAntiPattern.g:1660:1: rule__Condition__Group__4__Impl : ( ( ')' )? ) ;
    public final void rule__Condition__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1664:1: ( ( ( ')' )? ) )
            // InternalAntiPattern.g:1665:1: ( ( ')' )? )
            {
            // InternalAntiPattern.g:1665:1: ( ( ')' )? )
            // InternalAntiPattern.g:1666:2: ( ')' )?
            {
             before(grammarAccess.getConditionAccess().getRightParenthesisKeyword_4()); 
            // InternalAntiPattern.g:1667:2: ( ')' )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==51) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalAntiPattern.g:1667:3: ')'
                    {
                    match(input,51,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getConditionAccess().getRightParenthesisKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group__4__Impl"


    // $ANTLR start "rule__Condition__Group_3__0"
    // InternalAntiPattern.g:1676:1: rule__Condition__Group_3__0 : rule__Condition__Group_3__0__Impl rule__Condition__Group_3__1 ;
    public final void rule__Condition__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1680:1: ( rule__Condition__Group_3__0__Impl rule__Condition__Group_3__1 )
            // InternalAntiPattern.g:1681:2: rule__Condition__Group_3__0__Impl rule__Condition__Group_3__1
            {
            pushFollow(FOLLOW_18);
            rule__Condition__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Condition__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group_3__0"


    // $ANTLR start "rule__Condition__Group_3__0__Impl"
    // InternalAntiPattern.g:1688:1: rule__Condition__Group_3__0__Impl : ( ',' ) ;
    public final void rule__Condition__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1692:1: ( ( ',' ) )
            // InternalAntiPattern.g:1693:1: ( ',' )
            {
            // InternalAntiPattern.g:1693:1: ( ',' )
            // InternalAntiPattern.g:1694:2: ','
            {
             before(grammarAccess.getConditionAccess().getCommaKeyword_3_0()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getConditionAccess().getCommaKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group_3__0__Impl"


    // $ANTLR start "rule__Condition__Group_3__1"
    // InternalAntiPattern.g:1703:1: rule__Condition__Group_3__1 : rule__Condition__Group_3__1__Impl ;
    public final void rule__Condition__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1707:1: ( rule__Condition__Group_3__1__Impl )
            // InternalAntiPattern.g:1708:2: rule__Condition__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Condition__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group_3__1"


    // $ANTLR start "rule__Condition__Group_3__1__Impl"
    // InternalAntiPattern.g:1714:1: rule__Condition__Group_3__1__Impl : ( ( rule__Condition__RulesAssignment_3_1 ) ) ;
    public final void rule__Condition__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1718:1: ( ( ( rule__Condition__RulesAssignment_3_1 ) ) )
            // InternalAntiPattern.g:1719:1: ( ( rule__Condition__RulesAssignment_3_1 ) )
            {
            // InternalAntiPattern.g:1719:1: ( ( rule__Condition__RulesAssignment_3_1 ) )
            // InternalAntiPattern.g:1720:2: ( rule__Condition__RulesAssignment_3_1 )
            {
             before(grammarAccess.getConditionAccess().getRulesAssignment_3_1()); 
            // InternalAntiPattern.g:1721:2: ( rule__Condition__RulesAssignment_3_1 )
            // InternalAntiPattern.g:1721:3: rule__Condition__RulesAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Condition__RulesAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getConditionAccess().getRulesAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__Group_3__1__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0__0"
    // InternalAntiPattern.g:1730:1: rule__IntraCharacteristic__Group_0__0 : rule__IntraCharacteristic__Group_0__0__Impl rule__IntraCharacteristic__Group_0__1 ;
    public final void rule__IntraCharacteristic__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1734:1: ( rule__IntraCharacteristic__Group_0__0__Impl rule__IntraCharacteristic__Group_0__1 )
            // InternalAntiPattern.g:1735:2: rule__IntraCharacteristic__Group_0__0__Impl rule__IntraCharacteristic__Group_0__1
            {
            pushFollow(FOLLOW_21);
            rule__IntraCharacteristic__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0__0"


    // $ANTLR start "rule__IntraCharacteristic__Group_0__0__Impl"
    // InternalAntiPattern.g:1742:1: rule__IntraCharacteristic__Group_0__0__Impl : ( ( rule__IntraCharacteristic__MetricAssignment_0_0 ) ) ;
    public final void rule__IntraCharacteristic__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1746:1: ( ( ( rule__IntraCharacteristic__MetricAssignment_0_0 ) ) )
            // InternalAntiPattern.g:1747:1: ( ( rule__IntraCharacteristic__MetricAssignment_0_0 ) )
            {
            // InternalAntiPattern.g:1747:1: ( ( rule__IntraCharacteristic__MetricAssignment_0_0 ) )
            // InternalAntiPattern.g:1748:2: ( rule__IntraCharacteristic__MetricAssignment_0_0 )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getMetricAssignment_0_0()); 
            // InternalAntiPattern.g:1749:2: ( rule__IntraCharacteristic__MetricAssignment_0_0 )
            // InternalAntiPattern.g:1749:3: rule__IntraCharacteristic__MetricAssignment_0_0
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__MetricAssignment_0_0();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getMetricAssignment_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0__0__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0__1"
    // InternalAntiPattern.g:1757:1: rule__IntraCharacteristic__Group_0__1 : rule__IntraCharacteristic__Group_0__1__Impl rule__IntraCharacteristic__Group_0__2 ;
    public final void rule__IntraCharacteristic__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1761:1: ( rule__IntraCharacteristic__Group_0__1__Impl rule__IntraCharacteristic__Group_0__2 )
            // InternalAntiPattern.g:1762:2: rule__IntraCharacteristic__Group_0__1__Impl rule__IntraCharacteristic__Group_0__2
            {
            pushFollow(FOLLOW_10);
            rule__IntraCharacteristic__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0__1"


    // $ANTLR start "rule__IntraCharacteristic__Group_0__1__Impl"
    // InternalAntiPattern.g:1769:1: rule__IntraCharacteristic__Group_0__1__Impl : ( ( rule__IntraCharacteristic__ComparatorAssignment_0_1 ) ) ;
    public final void rule__IntraCharacteristic__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1773:1: ( ( ( rule__IntraCharacteristic__ComparatorAssignment_0_1 ) ) )
            // InternalAntiPattern.g:1774:1: ( ( rule__IntraCharacteristic__ComparatorAssignment_0_1 ) )
            {
            // InternalAntiPattern.g:1774:1: ( ( rule__IntraCharacteristic__ComparatorAssignment_0_1 ) )
            // InternalAntiPattern.g:1775:2: ( rule__IntraCharacteristic__ComparatorAssignment_0_1 )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getComparatorAssignment_0_1()); 
            // InternalAntiPattern.g:1776:2: ( rule__IntraCharacteristic__ComparatorAssignment_0_1 )
            // InternalAntiPattern.g:1776:3: rule__IntraCharacteristic__ComparatorAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__ComparatorAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getComparatorAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0__1__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0__2"
    // InternalAntiPattern.g:1784:1: rule__IntraCharacteristic__Group_0__2 : rule__IntraCharacteristic__Group_0__2__Impl rule__IntraCharacteristic__Group_0__3 ;
    public final void rule__IntraCharacteristic__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1788:1: ( rule__IntraCharacteristic__Group_0__2__Impl rule__IntraCharacteristic__Group_0__3 )
            // InternalAntiPattern.g:1789:2: rule__IntraCharacteristic__Group_0__2__Impl rule__IntraCharacteristic__Group_0__3
            {
            pushFollow(FOLLOW_22);
            rule__IntraCharacteristic__Group_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0__2"


    // $ANTLR start "rule__IntraCharacteristic__Group_0__2__Impl"
    // InternalAntiPattern.g:1796:1: rule__IntraCharacteristic__Group_0__2__Impl : ( ( rule__IntraCharacteristic__ValueAssignment_0_2 ) ) ;
    public final void rule__IntraCharacteristic__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1800:1: ( ( ( rule__IntraCharacteristic__ValueAssignment_0_2 ) ) )
            // InternalAntiPattern.g:1801:1: ( ( rule__IntraCharacteristic__ValueAssignment_0_2 ) )
            {
            // InternalAntiPattern.g:1801:1: ( ( rule__IntraCharacteristic__ValueAssignment_0_2 ) )
            // InternalAntiPattern.g:1802:2: ( rule__IntraCharacteristic__ValueAssignment_0_2 )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getValueAssignment_0_2()); 
            // InternalAntiPattern.g:1803:2: ( rule__IntraCharacteristic__ValueAssignment_0_2 )
            // InternalAntiPattern.g:1803:3: rule__IntraCharacteristic__ValueAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__ValueAssignment_0_2();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getValueAssignment_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0__2__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0__3"
    // InternalAntiPattern.g:1811:1: rule__IntraCharacteristic__Group_0__3 : rule__IntraCharacteristic__Group_0__3__Impl ;
    public final void rule__IntraCharacteristic__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1815:1: ( rule__IntraCharacteristic__Group_0__3__Impl )
            // InternalAntiPattern.g:1816:2: rule__IntraCharacteristic__Group_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0__3"


    // $ANTLR start "rule__IntraCharacteristic__Group_0__3__Impl"
    // InternalAntiPattern.g:1822:1: rule__IntraCharacteristic__Group_0__3__Impl : ( ( rule__IntraCharacteristic__Group_0_3__0 )? ) ;
    public final void rule__IntraCharacteristic__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1826:1: ( ( ( rule__IntraCharacteristic__Group_0_3__0 )? ) )
            // InternalAntiPattern.g:1827:1: ( ( rule__IntraCharacteristic__Group_0_3__0 )? )
            {
            // InternalAntiPattern.g:1827:1: ( ( rule__IntraCharacteristic__Group_0_3__0 )? )
            // InternalAntiPattern.g:1828:2: ( rule__IntraCharacteristic__Group_0_3__0 )?
            {
             before(grammarAccess.getIntraCharacteristicAccess().getGroup_0_3()); 
            // InternalAntiPattern.g:1829:2: ( rule__IntraCharacteristic__Group_0_3__0 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==53) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalAntiPattern.g:1829:3: rule__IntraCharacteristic__Group_0_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__IntraCharacteristic__Group_0_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getIntraCharacteristicAccess().getGroup_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0__3__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__0"
    // InternalAntiPattern.g:1838:1: rule__IntraCharacteristic__Group_0_3__0 : rule__IntraCharacteristic__Group_0_3__0__Impl rule__IntraCharacteristic__Group_0_3__1 ;
    public final void rule__IntraCharacteristic__Group_0_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1842:1: ( rule__IntraCharacteristic__Group_0_3__0__Impl rule__IntraCharacteristic__Group_0_3__1 )
            // InternalAntiPattern.g:1843:2: rule__IntraCharacteristic__Group_0_3__0__Impl rule__IntraCharacteristic__Group_0_3__1
            {
            pushFollow(FOLLOW_23);
            rule__IntraCharacteristic__Group_0_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__0"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__0__Impl"
    // InternalAntiPattern.g:1850:1: rule__IntraCharacteristic__Group_0_3__0__Impl : ( 'manners' ) ;
    public final void rule__IntraCharacteristic__Group_0_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1854:1: ( ( 'manners' ) )
            // InternalAntiPattern.g:1855:1: ( 'manners' )
            {
            // InternalAntiPattern.g:1855:1: ( 'manners' )
            // InternalAntiPattern.g:1856:2: 'manners'
            {
             before(grammarAccess.getIntraCharacteristicAccess().getMannersKeyword_0_3_0()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getIntraCharacteristicAccess().getMannersKeyword_0_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__0__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__1"
    // InternalAntiPattern.g:1865:1: rule__IntraCharacteristic__Group_0_3__1 : rule__IntraCharacteristic__Group_0_3__1__Impl rule__IntraCharacteristic__Group_0_3__2 ;
    public final void rule__IntraCharacteristic__Group_0_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1869:1: ( rule__IntraCharacteristic__Group_0_3__1__Impl rule__IntraCharacteristic__Group_0_3__2 )
            // InternalAntiPattern.g:1870:2: rule__IntraCharacteristic__Group_0_3__1__Impl rule__IntraCharacteristic__Group_0_3__2
            {
            pushFollow(FOLLOW_24);
            rule__IntraCharacteristic__Group_0_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__1"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__1__Impl"
    // InternalAntiPattern.g:1877:1: rule__IntraCharacteristic__Group_0_3__1__Impl : ( '(' ) ;
    public final void rule__IntraCharacteristic__Group_0_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1881:1: ( ( '(' ) )
            // InternalAntiPattern.g:1882:1: ( '(' )
            {
            // InternalAntiPattern.g:1882:1: ( '(' )
            // InternalAntiPattern.g:1883:2: '('
            {
             before(grammarAccess.getIntraCharacteristicAccess().getLeftParenthesisKeyword_0_3_1()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getIntraCharacteristicAccess().getLeftParenthesisKeyword_0_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__1__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__2"
    // InternalAntiPattern.g:1892:1: rule__IntraCharacteristic__Group_0_3__2 : rule__IntraCharacteristic__Group_0_3__2__Impl rule__IntraCharacteristic__Group_0_3__3 ;
    public final void rule__IntraCharacteristic__Group_0_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1896:1: ( rule__IntraCharacteristic__Group_0_3__2__Impl rule__IntraCharacteristic__Group_0_3__3 )
            // InternalAntiPattern.g:1897:2: rule__IntraCharacteristic__Group_0_3__2__Impl rule__IntraCharacteristic__Group_0_3__3
            {
            pushFollow(FOLLOW_25);
            rule__IntraCharacteristic__Group_0_3__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0_3__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__2"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__2__Impl"
    // InternalAntiPattern.g:1904:1: rule__IntraCharacteristic__Group_0_3__2__Impl : ( ( rule__IntraCharacteristic__QuantityAssignment_0_3_2 ) ) ;
    public final void rule__IntraCharacteristic__Group_0_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1908:1: ( ( ( rule__IntraCharacteristic__QuantityAssignment_0_3_2 ) ) )
            // InternalAntiPattern.g:1909:1: ( ( rule__IntraCharacteristic__QuantityAssignment_0_3_2 ) )
            {
            // InternalAntiPattern.g:1909:1: ( ( rule__IntraCharacteristic__QuantityAssignment_0_3_2 ) )
            // InternalAntiPattern.g:1910:2: ( rule__IntraCharacteristic__QuantityAssignment_0_3_2 )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getQuantityAssignment_0_3_2()); 
            // InternalAntiPattern.g:1911:2: ( rule__IntraCharacteristic__QuantityAssignment_0_3_2 )
            // InternalAntiPattern.g:1911:3: rule__IntraCharacteristic__QuantityAssignment_0_3_2
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__QuantityAssignment_0_3_2();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getQuantityAssignment_0_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__2__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__3"
    // InternalAntiPattern.g:1919:1: rule__IntraCharacteristic__Group_0_3__3 : rule__IntraCharacteristic__Group_0_3__3__Impl rule__IntraCharacteristic__Group_0_3__4 ;
    public final void rule__IntraCharacteristic__Group_0_3__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1923:1: ( rule__IntraCharacteristic__Group_0_3__3__Impl rule__IntraCharacteristic__Group_0_3__4 )
            // InternalAntiPattern.g:1924:2: rule__IntraCharacteristic__Group_0_3__3__Impl rule__IntraCharacteristic__Group_0_3__4
            {
            pushFollow(FOLLOW_19);
            rule__IntraCharacteristic__Group_0_3__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0_3__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__3"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__3__Impl"
    // InternalAntiPattern.g:1931:1: rule__IntraCharacteristic__Group_0_3__3__Impl : ( ( rule__IntraCharacteristic__MAssignment_0_3_3 ) ) ;
    public final void rule__IntraCharacteristic__Group_0_3__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1935:1: ( ( ( rule__IntraCharacteristic__MAssignment_0_3_3 ) ) )
            // InternalAntiPattern.g:1936:1: ( ( rule__IntraCharacteristic__MAssignment_0_3_3 ) )
            {
            // InternalAntiPattern.g:1936:1: ( ( rule__IntraCharacteristic__MAssignment_0_3_3 ) )
            // InternalAntiPattern.g:1937:2: ( rule__IntraCharacteristic__MAssignment_0_3_3 )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getMAssignment_0_3_3()); 
            // InternalAntiPattern.g:1938:2: ( rule__IntraCharacteristic__MAssignment_0_3_3 )
            // InternalAntiPattern.g:1938:3: rule__IntraCharacteristic__MAssignment_0_3_3
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__MAssignment_0_3_3();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getMAssignment_0_3_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__3__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__4"
    // InternalAntiPattern.g:1946:1: rule__IntraCharacteristic__Group_0_3__4 : rule__IntraCharacteristic__Group_0_3__4__Impl rule__IntraCharacteristic__Group_0_3__5 ;
    public final void rule__IntraCharacteristic__Group_0_3__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1950:1: ( rule__IntraCharacteristic__Group_0_3__4__Impl rule__IntraCharacteristic__Group_0_3__5 )
            // InternalAntiPattern.g:1951:2: rule__IntraCharacteristic__Group_0_3__4__Impl rule__IntraCharacteristic__Group_0_3__5
            {
            pushFollow(FOLLOW_19);
            rule__IntraCharacteristic__Group_0_3__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0_3__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__4"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__4__Impl"
    // InternalAntiPattern.g:1958:1: rule__IntraCharacteristic__Group_0_3__4__Impl : ( ( rule__IntraCharacteristic__Group_0_3_4__0 )* ) ;
    public final void rule__IntraCharacteristic__Group_0_3__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1962:1: ( ( ( rule__IntraCharacteristic__Group_0_3_4__0 )* ) )
            // InternalAntiPattern.g:1963:1: ( ( rule__IntraCharacteristic__Group_0_3_4__0 )* )
            {
            // InternalAntiPattern.g:1963:1: ( ( rule__IntraCharacteristic__Group_0_3_4__0 )* )
            // InternalAntiPattern.g:1964:2: ( rule__IntraCharacteristic__Group_0_3_4__0 )*
            {
             before(grammarAccess.getIntraCharacteristicAccess().getGroup_0_3_4()); 
            // InternalAntiPattern.g:1965:2: ( rule__IntraCharacteristic__Group_0_3_4__0 )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==52) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalAntiPattern.g:1965:3: rule__IntraCharacteristic__Group_0_3_4__0
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__IntraCharacteristic__Group_0_3_4__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

             after(grammarAccess.getIntraCharacteristicAccess().getGroup_0_3_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__4__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__5"
    // InternalAntiPattern.g:1973:1: rule__IntraCharacteristic__Group_0_3__5 : rule__IntraCharacteristic__Group_0_3__5__Impl ;
    public final void rule__IntraCharacteristic__Group_0_3__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1977:1: ( rule__IntraCharacteristic__Group_0_3__5__Impl )
            // InternalAntiPattern.g:1978:2: rule__IntraCharacteristic__Group_0_3__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0_3__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__5"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3__5__Impl"
    // InternalAntiPattern.g:1984:1: rule__IntraCharacteristic__Group_0_3__5__Impl : ( ')' ) ;
    public final void rule__IntraCharacteristic__Group_0_3__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:1988:1: ( ( ')' ) )
            // InternalAntiPattern.g:1989:1: ( ')' )
            {
            // InternalAntiPattern.g:1989:1: ( ')' )
            // InternalAntiPattern.g:1990:2: ')'
            {
             before(grammarAccess.getIntraCharacteristicAccess().getRightParenthesisKeyword_0_3_5()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getIntraCharacteristicAccess().getRightParenthesisKeyword_0_3_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3__5__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3_4__0"
    // InternalAntiPattern.g:2000:1: rule__IntraCharacteristic__Group_0_3_4__0 : rule__IntraCharacteristic__Group_0_3_4__0__Impl rule__IntraCharacteristic__Group_0_3_4__1 ;
    public final void rule__IntraCharacteristic__Group_0_3_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2004:1: ( rule__IntraCharacteristic__Group_0_3_4__0__Impl rule__IntraCharacteristic__Group_0_3_4__1 )
            // InternalAntiPattern.g:2005:2: rule__IntraCharacteristic__Group_0_3_4__0__Impl rule__IntraCharacteristic__Group_0_3_4__1
            {
            pushFollow(FOLLOW_24);
            rule__IntraCharacteristic__Group_0_3_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0_3_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3_4__0"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3_4__0__Impl"
    // InternalAntiPattern.g:2012:1: rule__IntraCharacteristic__Group_0_3_4__0__Impl : ( ',' ) ;
    public final void rule__IntraCharacteristic__Group_0_3_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2016:1: ( ( ',' ) )
            // InternalAntiPattern.g:2017:1: ( ',' )
            {
            // InternalAntiPattern.g:2017:1: ( ',' )
            // InternalAntiPattern.g:2018:2: ','
            {
             before(grammarAccess.getIntraCharacteristicAccess().getCommaKeyword_0_3_4_0()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getIntraCharacteristicAccess().getCommaKeyword_0_3_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3_4__0__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3_4__1"
    // InternalAntiPattern.g:2027:1: rule__IntraCharacteristic__Group_0_3_4__1 : rule__IntraCharacteristic__Group_0_3_4__1__Impl rule__IntraCharacteristic__Group_0_3_4__2 ;
    public final void rule__IntraCharacteristic__Group_0_3_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2031:1: ( rule__IntraCharacteristic__Group_0_3_4__1__Impl rule__IntraCharacteristic__Group_0_3_4__2 )
            // InternalAntiPattern.g:2032:2: rule__IntraCharacteristic__Group_0_3_4__1__Impl rule__IntraCharacteristic__Group_0_3_4__2
            {
            pushFollow(FOLLOW_25);
            rule__IntraCharacteristic__Group_0_3_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0_3_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3_4__1"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3_4__1__Impl"
    // InternalAntiPattern.g:2039:1: rule__IntraCharacteristic__Group_0_3_4__1__Impl : ( ( rule__IntraCharacteristic__QuantityAssignment_0_3_4_1 ) ) ;
    public final void rule__IntraCharacteristic__Group_0_3_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2043:1: ( ( ( rule__IntraCharacteristic__QuantityAssignment_0_3_4_1 ) ) )
            // InternalAntiPattern.g:2044:1: ( ( rule__IntraCharacteristic__QuantityAssignment_0_3_4_1 ) )
            {
            // InternalAntiPattern.g:2044:1: ( ( rule__IntraCharacteristic__QuantityAssignment_0_3_4_1 ) )
            // InternalAntiPattern.g:2045:2: ( rule__IntraCharacteristic__QuantityAssignment_0_3_4_1 )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getQuantityAssignment_0_3_4_1()); 
            // InternalAntiPattern.g:2046:2: ( rule__IntraCharacteristic__QuantityAssignment_0_3_4_1 )
            // InternalAntiPattern.g:2046:3: rule__IntraCharacteristic__QuantityAssignment_0_3_4_1
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__QuantityAssignment_0_3_4_1();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getQuantityAssignment_0_3_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3_4__1__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3_4__2"
    // InternalAntiPattern.g:2054:1: rule__IntraCharacteristic__Group_0_3_4__2 : rule__IntraCharacteristic__Group_0_3_4__2__Impl ;
    public final void rule__IntraCharacteristic__Group_0_3_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2058:1: ( rule__IntraCharacteristic__Group_0_3_4__2__Impl )
            // InternalAntiPattern.g:2059:2: rule__IntraCharacteristic__Group_0_3_4__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_0_3_4__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3_4__2"


    // $ANTLR start "rule__IntraCharacteristic__Group_0_3_4__2__Impl"
    // InternalAntiPattern.g:2065:1: rule__IntraCharacteristic__Group_0_3_4__2__Impl : ( ( rule__IntraCharacteristic__MAssignment_0_3_4_2 ) ) ;
    public final void rule__IntraCharacteristic__Group_0_3_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2069:1: ( ( ( rule__IntraCharacteristic__MAssignment_0_3_4_2 ) ) )
            // InternalAntiPattern.g:2070:1: ( ( rule__IntraCharacteristic__MAssignment_0_3_4_2 ) )
            {
            // InternalAntiPattern.g:2070:1: ( ( rule__IntraCharacteristic__MAssignment_0_3_4_2 ) )
            // InternalAntiPattern.g:2071:2: ( rule__IntraCharacteristic__MAssignment_0_3_4_2 )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getMAssignment_0_3_4_2()); 
            // InternalAntiPattern.g:2072:2: ( rule__IntraCharacteristic__MAssignment_0_3_4_2 )
            // InternalAntiPattern.g:2072:3: rule__IntraCharacteristic__MAssignment_0_3_4_2
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__MAssignment_0_3_4_2();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getMAssignment_0_3_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_0_3_4__2__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__0"
    // InternalAntiPattern.g:2081:1: rule__IntraCharacteristic__Group_1__0 : rule__IntraCharacteristic__Group_1__0__Impl rule__IntraCharacteristic__Group_1__1 ;
    public final void rule__IntraCharacteristic__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2085:1: ( rule__IntraCharacteristic__Group_1__0__Impl rule__IntraCharacteristic__Group_1__1 )
            // InternalAntiPattern.g:2086:2: rule__IntraCharacteristic__Group_1__0__Impl rule__IntraCharacteristic__Group_1__1
            {
            pushFollow(FOLLOW_23);
            rule__IntraCharacteristic__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__0"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__0__Impl"
    // InternalAntiPattern.g:2093:1: rule__IntraCharacteristic__Group_1__0__Impl : ( 'violates' ) ;
    public final void rule__IntraCharacteristic__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2097:1: ( ( 'violates' ) )
            // InternalAntiPattern.g:2098:1: ( 'violates' )
            {
            // InternalAntiPattern.g:2098:1: ( 'violates' )
            // InternalAntiPattern.g:2099:2: 'violates'
            {
             before(grammarAccess.getIntraCharacteristicAccess().getViolatesKeyword_1_0()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getIntraCharacteristicAccess().getViolatesKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__0__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__1"
    // InternalAntiPattern.g:2108:1: rule__IntraCharacteristic__Group_1__1 : rule__IntraCharacteristic__Group_1__1__Impl rule__IntraCharacteristic__Group_1__2 ;
    public final void rule__IntraCharacteristic__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2112:1: ( rule__IntraCharacteristic__Group_1__1__Impl rule__IntraCharacteristic__Group_1__2 )
            // InternalAntiPattern.g:2113:2: rule__IntraCharacteristic__Group_1__1__Impl rule__IntraCharacteristic__Group_1__2
            {
            pushFollow(FOLLOW_26);
            rule__IntraCharacteristic__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__1"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__1__Impl"
    // InternalAntiPattern.g:2120:1: rule__IntraCharacteristic__Group_1__1__Impl : ( '(' ) ;
    public final void rule__IntraCharacteristic__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2124:1: ( ( '(' ) )
            // InternalAntiPattern.g:2125:1: ( '(' )
            {
            // InternalAntiPattern.g:2125:1: ( '(' )
            // InternalAntiPattern.g:2126:2: '('
            {
             before(grammarAccess.getIntraCharacteristicAccess().getLeftParenthesisKeyword_1_1()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getIntraCharacteristicAccess().getLeftParenthesisKeyword_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__1__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__2"
    // InternalAntiPattern.g:2135:1: rule__IntraCharacteristic__Group_1__2 : rule__IntraCharacteristic__Group_1__2__Impl rule__IntraCharacteristic__Group_1__3 ;
    public final void rule__IntraCharacteristic__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2139:1: ( rule__IntraCharacteristic__Group_1__2__Impl rule__IntraCharacteristic__Group_1__3 )
            // InternalAntiPattern.g:2140:2: rule__IntraCharacteristic__Group_1__2__Impl rule__IntraCharacteristic__Group_1__3
            {
            pushFollow(FOLLOW_19);
            rule__IntraCharacteristic__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__2"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__2__Impl"
    // InternalAntiPattern.g:2147:1: rule__IntraCharacteristic__Group_1__2__Impl : ( ( rule__IntraCharacteristic__ConventionAssignment_1_2 ) ) ;
    public final void rule__IntraCharacteristic__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2151:1: ( ( ( rule__IntraCharacteristic__ConventionAssignment_1_2 ) ) )
            // InternalAntiPattern.g:2152:1: ( ( rule__IntraCharacteristic__ConventionAssignment_1_2 ) )
            {
            // InternalAntiPattern.g:2152:1: ( ( rule__IntraCharacteristic__ConventionAssignment_1_2 ) )
            // InternalAntiPattern.g:2153:2: ( rule__IntraCharacteristic__ConventionAssignment_1_2 )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getConventionAssignment_1_2()); 
            // InternalAntiPattern.g:2154:2: ( rule__IntraCharacteristic__ConventionAssignment_1_2 )
            // InternalAntiPattern.g:2154:3: rule__IntraCharacteristic__ConventionAssignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__ConventionAssignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getConventionAssignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__2__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__3"
    // InternalAntiPattern.g:2162:1: rule__IntraCharacteristic__Group_1__3 : rule__IntraCharacteristic__Group_1__3__Impl rule__IntraCharacteristic__Group_1__4 ;
    public final void rule__IntraCharacteristic__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2166:1: ( rule__IntraCharacteristic__Group_1__3__Impl rule__IntraCharacteristic__Group_1__4 )
            // InternalAntiPattern.g:2167:2: rule__IntraCharacteristic__Group_1__3__Impl rule__IntraCharacteristic__Group_1__4
            {
            pushFollow(FOLLOW_19);
            rule__IntraCharacteristic__Group_1__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_1__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__3"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__3__Impl"
    // InternalAntiPattern.g:2174:1: rule__IntraCharacteristic__Group_1__3__Impl : ( ( rule__IntraCharacteristic__Group_1_3__0 )* ) ;
    public final void rule__IntraCharacteristic__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2178:1: ( ( ( rule__IntraCharacteristic__Group_1_3__0 )* ) )
            // InternalAntiPattern.g:2179:1: ( ( rule__IntraCharacteristic__Group_1_3__0 )* )
            {
            // InternalAntiPattern.g:2179:1: ( ( rule__IntraCharacteristic__Group_1_3__0 )* )
            // InternalAntiPattern.g:2180:2: ( rule__IntraCharacteristic__Group_1_3__0 )*
            {
             before(grammarAccess.getIntraCharacteristicAccess().getGroup_1_3()); 
            // InternalAntiPattern.g:2181:2: ( rule__IntraCharacteristic__Group_1_3__0 )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==52) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalAntiPattern.g:2181:3: rule__IntraCharacteristic__Group_1_3__0
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__IntraCharacteristic__Group_1_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

             after(grammarAccess.getIntraCharacteristicAccess().getGroup_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__3__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__4"
    // InternalAntiPattern.g:2189:1: rule__IntraCharacteristic__Group_1__4 : rule__IntraCharacteristic__Group_1__4__Impl ;
    public final void rule__IntraCharacteristic__Group_1__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2193:1: ( rule__IntraCharacteristic__Group_1__4__Impl )
            // InternalAntiPattern.g:2194:2: rule__IntraCharacteristic__Group_1__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_1__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__4"


    // $ANTLR start "rule__IntraCharacteristic__Group_1__4__Impl"
    // InternalAntiPattern.g:2200:1: rule__IntraCharacteristic__Group_1__4__Impl : ( ')' ) ;
    public final void rule__IntraCharacteristic__Group_1__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2204:1: ( ( ')' ) )
            // InternalAntiPattern.g:2205:1: ( ')' )
            {
            // InternalAntiPattern.g:2205:1: ( ')' )
            // InternalAntiPattern.g:2206:2: ')'
            {
             before(grammarAccess.getIntraCharacteristicAccess().getRightParenthesisKeyword_1_4()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getIntraCharacteristicAccess().getRightParenthesisKeyword_1_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1__4__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_1_3__0"
    // InternalAntiPattern.g:2216:1: rule__IntraCharacteristic__Group_1_3__0 : rule__IntraCharacteristic__Group_1_3__0__Impl rule__IntraCharacteristic__Group_1_3__1 ;
    public final void rule__IntraCharacteristic__Group_1_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2220:1: ( rule__IntraCharacteristic__Group_1_3__0__Impl rule__IntraCharacteristic__Group_1_3__1 )
            // InternalAntiPattern.g:2221:2: rule__IntraCharacteristic__Group_1_3__0__Impl rule__IntraCharacteristic__Group_1_3__1
            {
            pushFollow(FOLLOW_26);
            rule__IntraCharacteristic__Group_1_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_1_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1_3__0"


    // $ANTLR start "rule__IntraCharacteristic__Group_1_3__0__Impl"
    // InternalAntiPattern.g:2228:1: rule__IntraCharacteristic__Group_1_3__0__Impl : ( ',' ) ;
    public final void rule__IntraCharacteristic__Group_1_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2232:1: ( ( ',' ) )
            // InternalAntiPattern.g:2233:1: ( ',' )
            {
            // InternalAntiPattern.g:2233:1: ( ',' )
            // InternalAntiPattern.g:2234:2: ','
            {
             before(grammarAccess.getIntraCharacteristicAccess().getCommaKeyword_1_3_0()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getIntraCharacteristicAccess().getCommaKeyword_1_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1_3__0__Impl"


    // $ANTLR start "rule__IntraCharacteristic__Group_1_3__1"
    // InternalAntiPattern.g:2243:1: rule__IntraCharacteristic__Group_1_3__1 : rule__IntraCharacteristic__Group_1_3__1__Impl ;
    public final void rule__IntraCharacteristic__Group_1_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2247:1: ( rule__IntraCharacteristic__Group_1_3__1__Impl )
            // InternalAntiPattern.g:2248:2: rule__IntraCharacteristic__Group_1_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__Group_1_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1_3__1"


    // $ANTLR start "rule__IntraCharacteristic__Group_1_3__1__Impl"
    // InternalAntiPattern.g:2254:1: rule__IntraCharacteristic__Group_1_3__1__Impl : ( ( rule__IntraCharacteristic__ConventionAssignment_1_3_1 ) ) ;
    public final void rule__IntraCharacteristic__Group_1_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2258:1: ( ( ( rule__IntraCharacteristic__ConventionAssignment_1_3_1 ) ) )
            // InternalAntiPattern.g:2259:1: ( ( rule__IntraCharacteristic__ConventionAssignment_1_3_1 ) )
            {
            // InternalAntiPattern.g:2259:1: ( ( rule__IntraCharacteristic__ConventionAssignment_1_3_1 ) )
            // InternalAntiPattern.g:2260:2: ( rule__IntraCharacteristic__ConventionAssignment_1_3_1 )
            {
             before(grammarAccess.getIntraCharacteristicAccess().getConventionAssignment_1_3_1()); 
            // InternalAntiPattern.g:2261:2: ( rule__IntraCharacteristic__ConventionAssignment_1_3_1 )
            // InternalAntiPattern.g:2261:3: rule__IntraCharacteristic__ConventionAssignment_1_3_1
            {
            pushFollow(FOLLOW_2);
            rule__IntraCharacteristic__ConventionAssignment_1_3_1();

            state._fsp--;


            }

             after(grammarAccess.getIntraCharacteristicAccess().getConventionAssignment_1_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__Group_1_3__1__Impl"


    // $ANTLR start "rule__InterCarachteristic__Group__0"
    // InternalAntiPattern.g:2270:1: rule__InterCarachteristic__Group__0 : rule__InterCarachteristic__Group__0__Impl rule__InterCarachteristic__Group__1 ;
    public final void rule__InterCarachteristic__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2274:1: ( rule__InterCarachteristic__Group__0__Impl rule__InterCarachteristic__Group__1 )
            // InternalAntiPattern.g:2275:2: rule__InterCarachteristic__Group__0__Impl rule__InterCarachteristic__Group__1
            {
            pushFollow(FOLLOW_23);
            rule__InterCarachteristic__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__0"


    // $ANTLR start "rule__InterCarachteristic__Group__0__Impl"
    // InternalAntiPattern.g:2282:1: rule__InterCarachteristic__Group__0__Impl : ( ( rule__InterCarachteristic__EAssignment_0 ) ) ;
    public final void rule__InterCarachteristic__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2286:1: ( ( ( rule__InterCarachteristic__EAssignment_0 ) ) )
            // InternalAntiPattern.g:2287:1: ( ( rule__InterCarachteristic__EAssignment_0 ) )
            {
            // InternalAntiPattern.g:2287:1: ( ( rule__InterCarachteristic__EAssignment_0 ) )
            // InternalAntiPattern.g:2288:2: ( rule__InterCarachteristic__EAssignment_0 )
            {
             before(grammarAccess.getInterCarachteristicAccess().getEAssignment_0()); 
            // InternalAntiPattern.g:2289:2: ( rule__InterCarachteristic__EAssignment_0 )
            // InternalAntiPattern.g:2289:3: rule__InterCarachteristic__EAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__EAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getInterCarachteristicAccess().getEAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__0__Impl"


    // $ANTLR start "rule__InterCarachteristic__Group__1"
    // InternalAntiPattern.g:2297:1: rule__InterCarachteristic__Group__1 : rule__InterCarachteristic__Group__1__Impl rule__InterCarachteristic__Group__2 ;
    public final void rule__InterCarachteristic__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2301:1: ( rule__InterCarachteristic__Group__1__Impl rule__InterCarachteristic__Group__2 )
            // InternalAntiPattern.g:2302:2: rule__InterCarachteristic__Group__1__Impl rule__InterCarachteristic__Group__2
            {
            pushFollow(FOLLOW_27);
            rule__InterCarachteristic__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__1"


    // $ANTLR start "rule__InterCarachteristic__Group__1__Impl"
    // InternalAntiPattern.g:2309:1: rule__InterCarachteristic__Group__1__Impl : ( '(' ) ;
    public final void rule__InterCarachteristic__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2313:1: ( ( '(' ) )
            // InternalAntiPattern.g:2314:1: ( '(' )
            {
            // InternalAntiPattern.g:2314:1: ( '(' )
            // InternalAntiPattern.g:2315:2: '('
            {
             before(grammarAccess.getInterCarachteristicAccess().getLeftParenthesisKeyword_1()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getInterCarachteristicAccess().getLeftParenthesisKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__1__Impl"


    // $ANTLR start "rule__InterCarachteristic__Group__2"
    // InternalAntiPattern.g:2324:1: rule__InterCarachteristic__Group__2 : rule__InterCarachteristic__Group__2__Impl rule__InterCarachteristic__Group__3 ;
    public final void rule__InterCarachteristic__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2328:1: ( rule__InterCarachteristic__Group__2__Impl rule__InterCarachteristic__Group__3 )
            // InternalAntiPattern.g:2329:2: rule__InterCarachteristic__Group__2__Impl rule__InterCarachteristic__Group__3
            {
            pushFollow(FOLLOW_19);
            rule__InterCarachteristic__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__2"


    // $ANTLR start "rule__InterCarachteristic__Group__2__Impl"
    // InternalAntiPattern.g:2336:1: rule__InterCarachteristic__Group__2__Impl : ( ( rule__InterCarachteristic__PAssignment_2 ) ) ;
    public final void rule__InterCarachteristic__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2340:1: ( ( ( rule__InterCarachteristic__PAssignment_2 ) ) )
            // InternalAntiPattern.g:2341:1: ( ( rule__InterCarachteristic__PAssignment_2 ) )
            {
            // InternalAntiPattern.g:2341:1: ( ( rule__InterCarachteristic__PAssignment_2 ) )
            // InternalAntiPattern.g:2342:2: ( rule__InterCarachteristic__PAssignment_2 )
            {
             before(grammarAccess.getInterCarachteristicAccess().getPAssignment_2()); 
            // InternalAntiPattern.g:2343:2: ( rule__InterCarachteristic__PAssignment_2 )
            // InternalAntiPattern.g:2343:3: rule__InterCarachteristic__PAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__PAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getInterCarachteristicAccess().getPAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__2__Impl"


    // $ANTLR start "rule__InterCarachteristic__Group__3"
    // InternalAntiPattern.g:2351:1: rule__InterCarachteristic__Group__3 : rule__InterCarachteristic__Group__3__Impl rule__InterCarachteristic__Group__4 ;
    public final void rule__InterCarachteristic__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2355:1: ( rule__InterCarachteristic__Group__3__Impl rule__InterCarachteristic__Group__4 )
            // InternalAntiPattern.g:2356:2: rule__InterCarachteristic__Group__3__Impl rule__InterCarachteristic__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__InterCarachteristic__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__3"


    // $ANTLR start "rule__InterCarachteristic__Group__3__Impl"
    // InternalAntiPattern.g:2363:1: rule__InterCarachteristic__Group__3__Impl : ( ( rule__InterCarachteristic__Group_3__0 )* ) ;
    public final void rule__InterCarachteristic__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2367:1: ( ( ( rule__InterCarachteristic__Group_3__0 )* ) )
            // InternalAntiPattern.g:2368:1: ( ( rule__InterCarachteristic__Group_3__0 )* )
            {
            // InternalAntiPattern.g:2368:1: ( ( rule__InterCarachteristic__Group_3__0 )* )
            // InternalAntiPattern.g:2369:2: ( rule__InterCarachteristic__Group_3__0 )*
            {
             before(grammarAccess.getInterCarachteristicAccess().getGroup_3()); 
            // InternalAntiPattern.g:2370:2: ( rule__InterCarachteristic__Group_3__0 )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==52) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalAntiPattern.g:2370:3: rule__InterCarachteristic__Group_3__0
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__InterCarachteristic__Group_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

             after(grammarAccess.getInterCarachteristicAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__3__Impl"


    // $ANTLR start "rule__InterCarachteristic__Group__4"
    // InternalAntiPattern.g:2378:1: rule__InterCarachteristic__Group__4 : rule__InterCarachteristic__Group__4__Impl rule__InterCarachteristic__Group__5 ;
    public final void rule__InterCarachteristic__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2382:1: ( rule__InterCarachteristic__Group__4__Impl rule__InterCarachteristic__Group__5 )
            // InternalAntiPattern.g:2383:2: rule__InterCarachteristic__Group__4__Impl rule__InterCarachteristic__Group__5
            {
            pushFollow(FOLLOW_21);
            rule__InterCarachteristic__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__4"


    // $ANTLR start "rule__InterCarachteristic__Group__4__Impl"
    // InternalAntiPattern.g:2390:1: rule__InterCarachteristic__Group__4__Impl : ( ')' ) ;
    public final void rule__InterCarachteristic__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2394:1: ( ( ')' ) )
            // InternalAntiPattern.g:2395:1: ( ')' )
            {
            // InternalAntiPattern.g:2395:1: ( ')' )
            // InternalAntiPattern.g:2396:2: ')'
            {
             before(grammarAccess.getInterCarachteristicAccess().getRightParenthesisKeyword_4()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getInterCarachteristicAccess().getRightParenthesisKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__4__Impl"


    // $ANTLR start "rule__InterCarachteristic__Group__5"
    // InternalAntiPattern.g:2405:1: rule__InterCarachteristic__Group__5 : rule__InterCarachteristic__Group__5__Impl rule__InterCarachteristic__Group__6 ;
    public final void rule__InterCarachteristic__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2409:1: ( rule__InterCarachteristic__Group__5__Impl rule__InterCarachteristic__Group__6 )
            // InternalAntiPattern.g:2410:2: rule__InterCarachteristic__Group__5__Impl rule__InterCarachteristic__Group__6
            {
            pushFollow(FOLLOW_10);
            rule__InterCarachteristic__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__5"


    // $ANTLR start "rule__InterCarachteristic__Group__5__Impl"
    // InternalAntiPattern.g:2417:1: rule__InterCarachteristic__Group__5__Impl : ( ( rule__InterCarachteristic__ComparatorAssignment_5 ) ) ;
    public final void rule__InterCarachteristic__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2421:1: ( ( ( rule__InterCarachteristic__ComparatorAssignment_5 ) ) )
            // InternalAntiPattern.g:2422:1: ( ( rule__InterCarachteristic__ComparatorAssignment_5 ) )
            {
            // InternalAntiPattern.g:2422:1: ( ( rule__InterCarachteristic__ComparatorAssignment_5 ) )
            // InternalAntiPattern.g:2423:2: ( rule__InterCarachteristic__ComparatorAssignment_5 )
            {
             before(grammarAccess.getInterCarachteristicAccess().getComparatorAssignment_5()); 
            // InternalAntiPattern.g:2424:2: ( rule__InterCarachteristic__ComparatorAssignment_5 )
            // InternalAntiPattern.g:2424:3: rule__InterCarachteristic__ComparatorAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__ComparatorAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getInterCarachteristicAccess().getComparatorAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__5__Impl"


    // $ANTLR start "rule__InterCarachteristic__Group__6"
    // InternalAntiPattern.g:2432:1: rule__InterCarachteristic__Group__6 : rule__InterCarachteristic__Group__6__Impl ;
    public final void rule__InterCarachteristic__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2436:1: ( rule__InterCarachteristic__Group__6__Impl )
            // InternalAntiPattern.g:2437:2: rule__InterCarachteristic__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__6"


    // $ANTLR start "rule__InterCarachteristic__Group__6__Impl"
    // InternalAntiPattern.g:2443:1: rule__InterCarachteristic__Group__6__Impl : ( ( rule__InterCarachteristic__ValueAssignment_6 ) ) ;
    public final void rule__InterCarachteristic__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2447:1: ( ( ( rule__InterCarachteristic__ValueAssignment_6 ) ) )
            // InternalAntiPattern.g:2448:1: ( ( rule__InterCarachteristic__ValueAssignment_6 ) )
            {
            // InternalAntiPattern.g:2448:1: ( ( rule__InterCarachteristic__ValueAssignment_6 ) )
            // InternalAntiPattern.g:2449:2: ( rule__InterCarachteristic__ValueAssignment_6 )
            {
             before(grammarAccess.getInterCarachteristicAccess().getValueAssignment_6()); 
            // InternalAntiPattern.g:2450:2: ( rule__InterCarachteristic__ValueAssignment_6 )
            // InternalAntiPattern.g:2450:3: rule__InterCarachteristic__ValueAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__ValueAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getInterCarachteristicAccess().getValueAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group__6__Impl"


    // $ANTLR start "rule__InterCarachteristic__Group_3__0"
    // InternalAntiPattern.g:2459:1: rule__InterCarachteristic__Group_3__0 : rule__InterCarachteristic__Group_3__0__Impl rule__InterCarachteristic__Group_3__1 ;
    public final void rule__InterCarachteristic__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2463:1: ( rule__InterCarachteristic__Group_3__0__Impl rule__InterCarachteristic__Group_3__1 )
            // InternalAntiPattern.g:2464:2: rule__InterCarachteristic__Group_3__0__Impl rule__InterCarachteristic__Group_3__1
            {
            pushFollow(FOLLOW_27);
            rule__InterCarachteristic__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group_3__0"


    // $ANTLR start "rule__InterCarachteristic__Group_3__0__Impl"
    // InternalAntiPattern.g:2471:1: rule__InterCarachteristic__Group_3__0__Impl : ( ',' ) ;
    public final void rule__InterCarachteristic__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2475:1: ( ( ',' ) )
            // InternalAntiPattern.g:2476:1: ( ',' )
            {
            // InternalAntiPattern.g:2476:1: ( ',' )
            // InternalAntiPattern.g:2477:2: ','
            {
             before(grammarAccess.getInterCarachteristicAccess().getCommaKeyword_3_0()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getInterCarachteristicAccess().getCommaKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group_3__0__Impl"


    // $ANTLR start "rule__InterCarachteristic__Group_3__1"
    // InternalAntiPattern.g:2486:1: rule__InterCarachteristic__Group_3__1 : rule__InterCarachteristic__Group_3__1__Impl ;
    public final void rule__InterCarachteristic__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2490:1: ( rule__InterCarachteristic__Group_3__1__Impl )
            // InternalAntiPattern.g:2491:2: rule__InterCarachteristic__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group_3__1"


    // $ANTLR start "rule__InterCarachteristic__Group_3__1__Impl"
    // InternalAntiPattern.g:2497:1: rule__InterCarachteristic__Group_3__1__Impl : ( ( rule__InterCarachteristic__PAssignment_3_1 ) ) ;
    public final void rule__InterCarachteristic__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2501:1: ( ( ( rule__InterCarachteristic__PAssignment_3_1 ) ) )
            // InternalAntiPattern.g:2502:1: ( ( rule__InterCarachteristic__PAssignment_3_1 ) )
            {
            // InternalAntiPattern.g:2502:1: ( ( rule__InterCarachteristic__PAssignment_3_1 ) )
            // InternalAntiPattern.g:2503:2: ( rule__InterCarachteristic__PAssignment_3_1 )
            {
             before(grammarAccess.getInterCarachteristicAccess().getPAssignment_3_1()); 
            // InternalAntiPattern.g:2504:2: ( rule__InterCarachteristic__PAssignment_3_1 )
            // InternalAntiPattern.g:2504:3: rule__InterCarachteristic__PAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__InterCarachteristic__PAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getInterCarachteristicAccess().getPAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__Group_3__1__Impl"


    // $ANTLR start "rule__NUMERIC_VALUE__Group_0__0"
    // InternalAntiPattern.g:2513:1: rule__NUMERIC_VALUE__Group_0__0 : rule__NUMERIC_VALUE__Group_0__0__Impl rule__NUMERIC_VALUE__Group_0__1 ;
    public final void rule__NUMERIC_VALUE__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2517:1: ( rule__NUMERIC_VALUE__Group_0__0__Impl rule__NUMERIC_VALUE__Group_0__1 )
            // InternalAntiPattern.g:2518:2: rule__NUMERIC_VALUE__Group_0__0__Impl rule__NUMERIC_VALUE__Group_0__1
            {
            pushFollow(FOLLOW_28);
            rule__NUMERIC_VALUE__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NUMERIC_VALUE__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NUMERIC_VALUE__Group_0__0"


    // $ANTLR start "rule__NUMERIC_VALUE__Group_0__0__Impl"
    // InternalAntiPattern.g:2525:1: rule__NUMERIC_VALUE__Group_0__0__Impl : ( RULE_INT ) ;
    public final void rule__NUMERIC_VALUE__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2529:1: ( ( RULE_INT ) )
            // InternalAntiPattern.g:2530:1: ( RULE_INT )
            {
            // InternalAntiPattern.g:2530:1: ( RULE_INT )
            // InternalAntiPattern.g:2531:2: RULE_INT
            {
             before(grammarAccess.getNUMERIC_VALUEAccess().getINTTerminalRuleCall_0_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getNUMERIC_VALUEAccess().getINTTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NUMERIC_VALUE__Group_0__0__Impl"


    // $ANTLR start "rule__NUMERIC_VALUE__Group_0__1"
    // InternalAntiPattern.g:2540:1: rule__NUMERIC_VALUE__Group_0__1 : rule__NUMERIC_VALUE__Group_0__1__Impl rule__NUMERIC_VALUE__Group_0__2 ;
    public final void rule__NUMERIC_VALUE__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2544:1: ( rule__NUMERIC_VALUE__Group_0__1__Impl rule__NUMERIC_VALUE__Group_0__2 )
            // InternalAntiPattern.g:2545:2: rule__NUMERIC_VALUE__Group_0__1__Impl rule__NUMERIC_VALUE__Group_0__2
            {
            pushFollow(FOLLOW_10);
            rule__NUMERIC_VALUE__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NUMERIC_VALUE__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NUMERIC_VALUE__Group_0__1"


    // $ANTLR start "rule__NUMERIC_VALUE__Group_0__1__Impl"
    // InternalAntiPattern.g:2552:1: rule__NUMERIC_VALUE__Group_0__1__Impl : ( '/' ) ;
    public final void rule__NUMERIC_VALUE__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2556:1: ( ( '/' ) )
            // InternalAntiPattern.g:2557:1: ( '/' )
            {
            // InternalAntiPattern.g:2557:1: ( '/' )
            // InternalAntiPattern.g:2558:2: '/'
            {
             before(grammarAccess.getNUMERIC_VALUEAccess().getSolidusKeyword_0_1()); 
            match(input,55,FOLLOW_2); 
             after(grammarAccess.getNUMERIC_VALUEAccess().getSolidusKeyword_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NUMERIC_VALUE__Group_0__1__Impl"


    // $ANTLR start "rule__NUMERIC_VALUE__Group_0__2"
    // InternalAntiPattern.g:2567:1: rule__NUMERIC_VALUE__Group_0__2 : rule__NUMERIC_VALUE__Group_0__2__Impl ;
    public final void rule__NUMERIC_VALUE__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2571:1: ( rule__NUMERIC_VALUE__Group_0__2__Impl )
            // InternalAntiPattern.g:2572:2: rule__NUMERIC_VALUE__Group_0__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__NUMERIC_VALUE__Group_0__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NUMERIC_VALUE__Group_0__2"


    // $ANTLR start "rule__NUMERIC_VALUE__Group_0__2__Impl"
    // InternalAntiPattern.g:2578:1: rule__NUMERIC_VALUE__Group_0__2__Impl : ( RULE_INT ) ;
    public final void rule__NUMERIC_VALUE__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2582:1: ( ( RULE_INT ) )
            // InternalAntiPattern.g:2583:1: ( RULE_INT )
            {
            // InternalAntiPattern.g:2583:1: ( RULE_INT )
            // InternalAntiPattern.g:2584:2: RULE_INT
            {
             before(grammarAccess.getNUMERIC_VALUEAccess().getINTTerminalRuleCall_0_2()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getNUMERIC_VALUEAccess().getINTTerminalRuleCall_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NUMERIC_VALUE__Group_0__2__Impl"


    // $ANTLR start "rule__Model__PromptsAssignment"
    // InternalAntiPattern.g:2594:1: rule__Model__PromptsAssignment : ( rulePrompt ) ;
    public final void rule__Model__PromptsAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2598:1: ( ( rulePrompt ) )
            // InternalAntiPattern.g:2599:2: ( rulePrompt )
            {
            // InternalAntiPattern.g:2599:2: ( rulePrompt )
            // InternalAntiPattern.g:2600:3: rulePrompt
            {
             before(grammarAccess.getModelAccess().getPromptsPromptParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            rulePrompt();

            state._fsp--;

             after(grammarAccess.getModelAccess().getPromptsPromptParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__PromptsAssignment"


    // $ANTLR start "rule__Prompt__ContentAssignment_2"
    // InternalAntiPattern.g:2609:1: rule__Prompt__ContentAssignment_2 : ( ruleContentPrompt ) ;
    public final void rule__Prompt__ContentAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2613:1: ( ( ruleContentPrompt ) )
            // InternalAntiPattern.g:2614:2: ( ruleContentPrompt )
            {
            // InternalAntiPattern.g:2614:2: ( ruleContentPrompt )
            // InternalAntiPattern.g:2615:3: ruleContentPrompt
            {
             before(grammarAccess.getPromptAccess().getContentContentPromptParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleContentPrompt();

            state._fsp--;

             after(grammarAccess.getPromptAccess().getContentContentPromptParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prompt__ContentAssignment_2"


    // $ANTLR start "rule__ContentPrompt__NbexembleAssignment_0"
    // InternalAntiPattern.g:2624:1: rule__ContentPrompt__NbexembleAssignment_0 : ( ruleExemples ) ;
    public final void rule__ContentPrompt__NbexembleAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2628:1: ( ( ruleExemples ) )
            // InternalAntiPattern.g:2629:2: ( ruleExemples )
            {
            // InternalAntiPattern.g:2629:2: ( ruleExemples )
            // InternalAntiPattern.g:2630:3: ruleExemples
            {
             before(grammarAccess.getContentPromptAccess().getNbexembleExemplesParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleExemples();

            state._fsp--;

             after(grammarAccess.getContentPromptAccess().getNbexembleExemplesParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__NbexembleAssignment_0"


    // $ANTLR start "rule__ContentPrompt__DomainAssignment_1"
    // InternalAntiPattern.g:2639:1: rule__ContentPrompt__DomainAssignment_1 : ( ruleDomain ) ;
    public final void rule__ContentPrompt__DomainAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2643:1: ( ( ruleDomain ) )
            // InternalAntiPattern.g:2644:2: ( ruleDomain )
            {
            // InternalAntiPattern.g:2644:2: ( ruleDomain )
            // InternalAntiPattern.g:2645:3: ruleDomain
            {
             before(grammarAccess.getContentPromptAccess().getDomainDomainParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDomain();

            state._fsp--;

             after(grammarAccess.getContentPromptAccess().getDomainDomainParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__DomainAssignment_1"


    // $ANTLR start "rule__ContentPrompt__ClasseAssignment_2"
    // InternalAntiPattern.g:2654:1: rule__ContentPrompt__ClasseAssignment_2 : ( ruleClasses ) ;
    public final void rule__ContentPrompt__ClasseAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2658:1: ( ( ruleClasses ) )
            // InternalAntiPattern.g:2659:2: ( ruleClasses )
            {
            // InternalAntiPattern.g:2659:2: ( ruleClasses )
            // InternalAntiPattern.g:2660:3: ruleClasses
            {
             before(grammarAccess.getContentPromptAccess().getClasseClassesParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleClasses();

            state._fsp--;

             after(grammarAccess.getContentPromptAccess().getClasseClassesParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__ClasseAssignment_2"


    // $ANTLR start "rule__ContentPrompt__MethodAssignment_3"
    // InternalAntiPattern.g:2669:1: rule__ContentPrompt__MethodAssignment_3 : ( ruleChosenMethod ) ;
    public final void rule__ContentPrompt__MethodAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2673:1: ( ( ruleChosenMethod ) )
            // InternalAntiPattern.g:2674:2: ( ruleChosenMethod )
            {
            // InternalAntiPattern.g:2674:2: ( ruleChosenMethod )
            // InternalAntiPattern.g:2675:3: ruleChosenMethod
            {
             before(grammarAccess.getContentPromptAccess().getMethodChosenMethodParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleChosenMethod();

            state._fsp--;

             after(grammarAccess.getContentPromptAccess().getMethodChosenMethodParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ContentPrompt__MethodAssignment_3"


    // $ANTLR start "rule__Exemples__NbExemplesAssignment_1"
    // InternalAntiPattern.g:2684:1: rule__Exemples__NbExemplesAssignment_1 : ( RULE_INT ) ;
    public final void rule__Exemples__NbExemplesAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2688:1: ( ( RULE_INT ) )
            // InternalAntiPattern.g:2689:2: ( RULE_INT )
            {
            // InternalAntiPattern.g:2689:2: ( RULE_INT )
            // InternalAntiPattern.g:2690:3: RULE_INT
            {
             before(grammarAccess.getExemplesAccess().getNbExemplesINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getExemplesAccess().getNbExemplesINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exemples__NbExemplesAssignment_1"


    // $ANTLR start "rule__Domain__DomainNameAssignment_1"
    // InternalAntiPattern.g:2699:1: rule__Domain__DomainNameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Domain__DomainNameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2703:1: ( ( RULE_ID ) )
            // InternalAntiPattern.g:2704:2: ( RULE_ID )
            {
            // InternalAntiPattern.g:2704:2: ( RULE_ID )
            // InternalAntiPattern.g:2705:3: RULE_ID
            {
             before(grammarAccess.getDomainAccess().getDomainNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getDomainAccess().getDomainNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Domain__DomainNameAssignment_1"


    // $ANTLR start "rule__Classes__NbClassAssignment_1"
    // InternalAntiPattern.g:2714:1: rule__Classes__NbClassAssignment_1 : ( RULE_INT ) ;
    public final void rule__Classes__NbClassAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2718:1: ( ( RULE_INT ) )
            // InternalAntiPattern.g:2719:2: ( RULE_INT )
            {
            // InternalAntiPattern.g:2719:2: ( RULE_INT )
            // InternalAntiPattern.g:2720:3: RULE_INT
            {
             before(grammarAccess.getClassesAccess().getNbClassINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getClassesAccess().getNbClassINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Classes__NbClassAssignment_1"


    // $ANTLR start "rule__Classes___classAssignment_2"
    // InternalAntiPattern.g:2729:1: rule__Classes___classAssignment_2 : ( rule_Class ) ;
    public final void rule__Classes___classAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2733:1: ( ( rule_Class ) )
            // InternalAntiPattern.g:2734:2: ( rule_Class )
            {
            // InternalAntiPattern.g:2734:2: ( rule_Class )
            // InternalAntiPattern.g:2735:3: rule_Class
            {
             before(grammarAccess.getClassesAccess().get_class_ClassParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            rule_Class();

            state._fsp--;

             after(grammarAccess.getClassesAccess().get_class_ClassParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Classes___classAssignment_2"


    // $ANTLR start "rule___Class__ClassNameAssignment_1"
    // InternalAntiPattern.g:2744:1: rule___Class__ClassNameAssignment_1 : ( RULE_ID ) ;
    public final void rule___Class__ClassNameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2748:1: ( ( RULE_ID ) )
            // InternalAntiPattern.g:2749:2: ( RULE_ID )
            {
            // InternalAntiPattern.g:2749:2: ( RULE_ID )
            // InternalAntiPattern.g:2750:3: RULE_ID
            {
             before(grammarAccess.get_ClassAccess().getClassNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.get_ClassAccess().getClassNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule___Class__ClassNameAssignment_1"


    // $ANTLR start "rule__ChosenMethod__ClassAssignment_1"
    // InternalAntiPattern.g:2759:1: rule__ChosenMethod__ClassAssignment_1 : ( rule_Class ) ;
    public final void rule__ChosenMethod__ClassAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2763:1: ( ( rule_Class ) )
            // InternalAntiPattern.g:2764:2: ( rule_Class )
            {
            // InternalAntiPattern.g:2764:2: ( rule_Class )
            // InternalAntiPattern.g:2765:3: rule_Class
            {
             before(grammarAccess.getChosenMethodAccess().getClass_ClassParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            rule_Class();

            state._fsp--;

             after(grammarAccess.getChosenMethodAccess().getClass_ClassParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__ClassAssignment_1"


    // $ANTLR start "rule__ChosenMethod__ConditionsAssignment_4"
    // InternalAntiPattern.g:2774:1: rule__ChosenMethod__ConditionsAssignment_4 : ( ruleCondition ) ;
    public final void rule__ChosenMethod__ConditionsAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2778:1: ( ( ruleCondition ) )
            // InternalAntiPattern.g:2779:2: ( ruleCondition )
            {
            // InternalAntiPattern.g:2779:2: ( ruleCondition )
            // InternalAntiPattern.g:2780:3: ruleCondition
            {
             before(grammarAccess.getChosenMethodAccess().getConditionsConditionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleCondition();

            state._fsp--;

             after(grammarAccess.getChosenMethodAccess().getConditionsConditionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChosenMethod__ConditionsAssignment_4"


    // $ANTLR start "rule__Condition__LinkAssignment_0"
    // InternalAntiPattern.g:2789:1: rule__Condition__LinkAssignment_0 : ( ruleLink ) ;
    public final void rule__Condition__LinkAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2793:1: ( ( ruleLink ) )
            // InternalAntiPattern.g:2794:2: ( ruleLink )
            {
            // InternalAntiPattern.g:2794:2: ( ruleLink )
            // InternalAntiPattern.g:2795:3: ruleLink
            {
             before(grammarAccess.getConditionAccess().getLinkLinkParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleLink();

            state._fsp--;

             after(grammarAccess.getConditionAccess().getLinkLinkParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__LinkAssignment_0"


    // $ANTLR start "rule__Condition__RulesAssignment_2"
    // InternalAntiPattern.g:2804:1: rule__Condition__RulesAssignment_2 : ( ruleRuleType ) ;
    public final void rule__Condition__RulesAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2808:1: ( ( ruleRuleType ) )
            // InternalAntiPattern.g:2809:2: ( ruleRuleType )
            {
            // InternalAntiPattern.g:2809:2: ( ruleRuleType )
            // InternalAntiPattern.g:2810:3: ruleRuleType
            {
             before(grammarAccess.getConditionAccess().getRulesRuleTypeParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleRuleType();

            state._fsp--;

             after(grammarAccess.getConditionAccess().getRulesRuleTypeParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__RulesAssignment_2"


    // $ANTLR start "rule__Condition__RulesAssignment_3_1"
    // InternalAntiPattern.g:2819:1: rule__Condition__RulesAssignment_3_1 : ( ruleRuleType ) ;
    public final void rule__Condition__RulesAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2823:1: ( ( ruleRuleType ) )
            // InternalAntiPattern.g:2824:2: ( ruleRuleType )
            {
            // InternalAntiPattern.g:2824:2: ( ruleRuleType )
            // InternalAntiPattern.g:2825:3: ruleRuleType
            {
             before(grammarAccess.getConditionAccess().getRulesRuleTypeParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleRuleType();

            state._fsp--;

             after(grammarAccess.getConditionAccess().getRulesRuleTypeParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Condition__RulesAssignment_3_1"


    // $ANTLR start "rule__Link__OpAssignment"
    // InternalAntiPattern.g:2834:1: rule__Link__OpAssignment : ( ( 'UNION' ) ) ;
    public final void rule__Link__OpAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2838:1: ( ( ( 'UNION' ) ) )
            // InternalAntiPattern.g:2839:2: ( ( 'UNION' ) )
            {
            // InternalAntiPattern.g:2839:2: ( ( 'UNION' ) )
            // InternalAntiPattern.g:2840:3: ( 'UNION' )
            {
             before(grammarAccess.getLinkAccess().getOpUNIONKeyword_0()); 
            // InternalAntiPattern.g:2841:3: ( 'UNION' )
            // InternalAntiPattern.g:2842:4: 'UNION'
            {
             before(grammarAccess.getLinkAccess().getOpUNIONKeyword_0()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getLinkAccess().getOpUNIONKeyword_0()); 

            }

             after(grammarAccess.getLinkAccess().getOpUNIONKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Link__OpAssignment"


    // $ANTLR start "rule__IntraCharacteristic__MetricAssignment_0_0"
    // InternalAntiPattern.g:2853:1: rule__IntraCharacteristic__MetricAssignment_0_0 : ( ruleMetric ) ;
    public final void rule__IntraCharacteristic__MetricAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2857:1: ( ( ruleMetric ) )
            // InternalAntiPattern.g:2858:2: ( ruleMetric )
            {
            // InternalAntiPattern.g:2858:2: ( ruleMetric )
            // InternalAntiPattern.g:2859:3: ruleMetric
            {
             before(grammarAccess.getIntraCharacteristicAccess().getMetricMetricParserRuleCall_0_0_0()); 
            pushFollow(FOLLOW_2);
            ruleMetric();

            state._fsp--;

             after(grammarAccess.getIntraCharacteristicAccess().getMetricMetricParserRuleCall_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__MetricAssignment_0_0"


    // $ANTLR start "rule__IntraCharacteristic__ComparatorAssignment_0_1"
    // InternalAntiPattern.g:2868:1: rule__IntraCharacteristic__ComparatorAssignment_0_1 : ( ruleComparator ) ;
    public final void rule__IntraCharacteristic__ComparatorAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2872:1: ( ( ruleComparator ) )
            // InternalAntiPattern.g:2873:2: ( ruleComparator )
            {
            // InternalAntiPattern.g:2873:2: ( ruleComparator )
            // InternalAntiPattern.g:2874:3: ruleComparator
            {
             before(grammarAccess.getIntraCharacteristicAccess().getComparatorComparatorParserRuleCall_0_1_0()); 
            pushFollow(FOLLOW_2);
            ruleComparator();

            state._fsp--;

             after(grammarAccess.getIntraCharacteristicAccess().getComparatorComparatorParserRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__ComparatorAssignment_0_1"


    // $ANTLR start "rule__IntraCharacteristic__ValueAssignment_0_2"
    // InternalAntiPattern.g:2883:1: rule__IntraCharacteristic__ValueAssignment_0_2 : ( RULE_INT ) ;
    public final void rule__IntraCharacteristic__ValueAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2887:1: ( ( RULE_INT ) )
            // InternalAntiPattern.g:2888:2: ( RULE_INT )
            {
            // InternalAntiPattern.g:2888:2: ( RULE_INT )
            // InternalAntiPattern.g:2889:3: RULE_INT
            {
             before(grammarAccess.getIntraCharacteristicAccess().getValueINTTerminalRuleCall_0_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getIntraCharacteristicAccess().getValueINTTerminalRuleCall_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__ValueAssignment_0_2"


    // $ANTLR start "rule__IntraCharacteristic__QuantityAssignment_0_3_2"
    // InternalAntiPattern.g:2898:1: rule__IntraCharacteristic__QuantityAssignment_0_3_2 : ( ruleQunatity ) ;
    public final void rule__IntraCharacteristic__QuantityAssignment_0_3_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2902:1: ( ( ruleQunatity ) )
            // InternalAntiPattern.g:2903:2: ( ruleQunatity )
            {
            // InternalAntiPattern.g:2903:2: ( ruleQunatity )
            // InternalAntiPattern.g:2904:3: ruleQunatity
            {
             before(grammarAccess.getIntraCharacteristicAccess().getQuantityQunatityParserRuleCall_0_3_2_0()); 
            pushFollow(FOLLOW_2);
            ruleQunatity();

            state._fsp--;

             after(grammarAccess.getIntraCharacteristicAccess().getQuantityQunatityParserRuleCall_0_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__QuantityAssignment_0_3_2"


    // $ANTLR start "rule__IntraCharacteristic__MAssignment_0_3_3"
    // InternalAntiPattern.g:2913:1: rule__IntraCharacteristic__MAssignment_0_3_3 : ( ruleManner ) ;
    public final void rule__IntraCharacteristic__MAssignment_0_3_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2917:1: ( ( ruleManner ) )
            // InternalAntiPattern.g:2918:2: ( ruleManner )
            {
            // InternalAntiPattern.g:2918:2: ( ruleManner )
            // InternalAntiPattern.g:2919:3: ruleManner
            {
             before(grammarAccess.getIntraCharacteristicAccess().getMMannerParserRuleCall_0_3_3_0()); 
            pushFollow(FOLLOW_2);
            ruleManner();

            state._fsp--;

             after(grammarAccess.getIntraCharacteristicAccess().getMMannerParserRuleCall_0_3_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__MAssignment_0_3_3"


    // $ANTLR start "rule__IntraCharacteristic__QuantityAssignment_0_3_4_1"
    // InternalAntiPattern.g:2928:1: rule__IntraCharacteristic__QuantityAssignment_0_3_4_1 : ( ruleQunatity ) ;
    public final void rule__IntraCharacteristic__QuantityAssignment_0_3_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2932:1: ( ( ruleQunatity ) )
            // InternalAntiPattern.g:2933:2: ( ruleQunatity )
            {
            // InternalAntiPattern.g:2933:2: ( ruleQunatity )
            // InternalAntiPattern.g:2934:3: ruleQunatity
            {
             before(grammarAccess.getIntraCharacteristicAccess().getQuantityQunatityParserRuleCall_0_3_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleQunatity();

            state._fsp--;

             after(grammarAccess.getIntraCharacteristicAccess().getQuantityQunatityParserRuleCall_0_3_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__QuantityAssignment_0_3_4_1"


    // $ANTLR start "rule__IntraCharacteristic__MAssignment_0_3_4_2"
    // InternalAntiPattern.g:2943:1: rule__IntraCharacteristic__MAssignment_0_3_4_2 : ( ruleManner ) ;
    public final void rule__IntraCharacteristic__MAssignment_0_3_4_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2947:1: ( ( ruleManner ) )
            // InternalAntiPattern.g:2948:2: ( ruleManner )
            {
            // InternalAntiPattern.g:2948:2: ( ruleManner )
            // InternalAntiPattern.g:2949:3: ruleManner
            {
             before(grammarAccess.getIntraCharacteristicAccess().getMMannerParserRuleCall_0_3_4_2_0()); 
            pushFollow(FOLLOW_2);
            ruleManner();

            state._fsp--;

             after(grammarAccess.getIntraCharacteristicAccess().getMMannerParserRuleCall_0_3_4_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__MAssignment_0_3_4_2"


    // $ANTLR start "rule__IntraCharacteristic__ConventionAssignment_1_2"
    // InternalAntiPattern.g:2958:1: rule__IntraCharacteristic__ConventionAssignment_1_2 : ( ruleConvention ) ;
    public final void rule__IntraCharacteristic__ConventionAssignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2962:1: ( ( ruleConvention ) )
            // InternalAntiPattern.g:2963:2: ( ruleConvention )
            {
            // InternalAntiPattern.g:2963:2: ( ruleConvention )
            // InternalAntiPattern.g:2964:3: ruleConvention
            {
             before(grammarAccess.getIntraCharacteristicAccess().getConventionConventionParserRuleCall_1_2_0()); 
            pushFollow(FOLLOW_2);
            ruleConvention();

            state._fsp--;

             after(grammarAccess.getIntraCharacteristicAccess().getConventionConventionParserRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__ConventionAssignment_1_2"


    // $ANTLR start "rule__IntraCharacteristic__ConventionAssignment_1_3_1"
    // InternalAntiPattern.g:2973:1: rule__IntraCharacteristic__ConventionAssignment_1_3_1 : ( ruleConvention ) ;
    public final void rule__IntraCharacteristic__ConventionAssignment_1_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2977:1: ( ( ruleConvention ) )
            // InternalAntiPattern.g:2978:2: ( ruleConvention )
            {
            // InternalAntiPattern.g:2978:2: ( ruleConvention )
            // InternalAntiPattern.g:2979:3: ruleConvention
            {
             before(grammarAccess.getIntraCharacteristicAccess().getConventionConventionParserRuleCall_1_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleConvention();

            state._fsp--;

             after(grammarAccess.getIntraCharacteristicAccess().getConventionConventionParserRuleCall_1_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IntraCharacteristic__ConventionAssignment_1_3_1"


    // $ANTLR start "rule__MAXMetric__Metric_valAssignment"
    // InternalAntiPattern.g:2988:1: rule__MAXMetric__Metric_valAssignment : ( ( rule__MAXMetric__Metric_valAlternatives_0 ) ) ;
    public final void rule__MAXMetric__Metric_valAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:2992:1: ( ( ( rule__MAXMetric__Metric_valAlternatives_0 ) ) )
            // InternalAntiPattern.g:2993:2: ( ( rule__MAXMetric__Metric_valAlternatives_0 ) )
            {
            // InternalAntiPattern.g:2993:2: ( ( rule__MAXMetric__Metric_valAlternatives_0 ) )
            // InternalAntiPattern.g:2994:3: ( rule__MAXMetric__Metric_valAlternatives_0 )
            {
             before(grammarAccess.getMAXMetricAccess().getMetric_valAlternatives_0()); 
            // InternalAntiPattern.g:2995:3: ( rule__MAXMetric__Metric_valAlternatives_0 )
            // InternalAntiPattern.g:2995:4: rule__MAXMetric__Metric_valAlternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__MAXMetric__Metric_valAlternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getMAXMetricAccess().getMetric_valAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MAXMetric__Metric_valAssignment"


    // $ANTLR start "rule__MINMetric__Metric_valAssignment"
    // InternalAntiPattern.g:3003:1: rule__MINMetric__Metric_valAssignment : ( ( 'COH' ) ) ;
    public final void rule__MINMetric__Metric_valAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3007:1: ( ( ( 'COH' ) ) )
            // InternalAntiPattern.g:3008:2: ( ( 'COH' ) )
            {
            // InternalAntiPattern.g:3008:2: ( ( 'COH' ) )
            // InternalAntiPattern.g:3009:3: ( 'COH' )
            {
             before(grammarAccess.getMINMetricAccess().getMetric_valCOHKeyword_0()); 
            // InternalAntiPattern.g:3010:3: ( 'COH' )
            // InternalAntiPattern.g:3011:4: 'COH'
            {
             before(grammarAccess.getMINMetricAccess().getMetric_valCOHKeyword_0()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getMINMetricAccess().getMetric_valCOHKeyword_0()); 

            }

             after(grammarAccess.getMINMetricAccess().getMetric_valCOHKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MINMetric__Metric_valAssignment"


    // $ANTLR start "rule__Comparator__CompAssignment"
    // InternalAntiPattern.g:3022:1: rule__Comparator__CompAssignment : ( ( rule__Comparator__CompAlternatives_0 ) ) ;
    public final void rule__Comparator__CompAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3026:1: ( ( ( rule__Comparator__CompAlternatives_0 ) ) )
            // InternalAntiPattern.g:3027:2: ( ( rule__Comparator__CompAlternatives_0 ) )
            {
            // InternalAntiPattern.g:3027:2: ( ( rule__Comparator__CompAlternatives_0 ) )
            // InternalAntiPattern.g:3028:3: ( rule__Comparator__CompAlternatives_0 )
            {
             before(grammarAccess.getComparatorAccess().getCompAlternatives_0()); 
            // InternalAntiPattern.g:3029:3: ( rule__Comparator__CompAlternatives_0 )
            // InternalAntiPattern.g:3029:4: rule__Comparator__CompAlternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__Comparator__CompAlternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getComparatorAccess().getCompAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comparator__CompAssignment"


    // $ANTLR start "rule__Convention__CAssignment"
    // InternalAntiPattern.g:3037:1: rule__Convention__CAssignment : ( ( rule__Convention__CAlternatives_0 ) ) ;
    public final void rule__Convention__CAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3041:1: ( ( ( rule__Convention__CAlternatives_0 ) ) )
            // InternalAntiPattern.g:3042:2: ( ( rule__Convention__CAlternatives_0 ) )
            {
            // InternalAntiPattern.g:3042:2: ( ( rule__Convention__CAlternatives_0 ) )
            // InternalAntiPattern.g:3043:3: ( rule__Convention__CAlternatives_0 )
            {
             before(grammarAccess.getConventionAccess().getCAlternatives_0()); 
            // InternalAntiPattern.g:3044:3: ( rule__Convention__CAlternatives_0 )
            // InternalAntiPattern.g:3044:4: rule__Convention__CAlternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__Convention__CAlternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getConventionAccess().getCAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Convention__CAssignment"


    // $ANTLR start "rule__Qunatity__QAssignment"
    // InternalAntiPattern.g:3052:1: rule__Qunatity__QAssignment : ( ( rule__Qunatity__QAlternatives_0 ) ) ;
    public final void rule__Qunatity__QAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3056:1: ( ( ( rule__Qunatity__QAlternatives_0 ) ) )
            // InternalAntiPattern.g:3057:2: ( ( rule__Qunatity__QAlternatives_0 ) )
            {
            // InternalAntiPattern.g:3057:2: ( ( rule__Qunatity__QAlternatives_0 ) )
            // InternalAntiPattern.g:3058:3: ( rule__Qunatity__QAlternatives_0 )
            {
             before(grammarAccess.getQunatityAccess().getQAlternatives_0()); 
            // InternalAntiPattern.g:3059:3: ( rule__Qunatity__QAlternatives_0 )
            // InternalAntiPattern.g:3059:4: rule__Qunatity__QAlternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__Qunatity__QAlternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getQunatityAccess().getQAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qunatity__QAssignment"


    // $ANTLR start "rule__Manner__MannerAssignment"
    // InternalAntiPattern.g:3067:1: rule__Manner__MannerAssignment : ( ( rule__Manner__MannerAlternatives_0 ) ) ;
    public final void rule__Manner__MannerAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3071:1: ( ( ( rule__Manner__MannerAlternatives_0 ) ) )
            // InternalAntiPattern.g:3072:2: ( ( rule__Manner__MannerAlternatives_0 ) )
            {
            // InternalAntiPattern.g:3072:2: ( ( rule__Manner__MannerAlternatives_0 ) )
            // InternalAntiPattern.g:3073:3: ( rule__Manner__MannerAlternatives_0 )
            {
             before(grammarAccess.getMannerAccess().getMannerAlternatives_0()); 
            // InternalAntiPattern.g:3074:3: ( rule__Manner__MannerAlternatives_0 )
            // InternalAntiPattern.g:3074:4: rule__Manner__MannerAlternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__Manner__MannerAlternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getMannerAccess().getMannerAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Manner__MannerAssignment"


    // $ANTLR start "rule__InterCarachteristic__EAssignment_0"
    // InternalAntiPattern.g:3082:1: rule__InterCarachteristic__EAssignment_0 : ( ( 'ATTRIBUTE_USE' ) ) ;
    public final void rule__InterCarachteristic__EAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3086:1: ( ( ( 'ATTRIBUTE_USE' ) ) )
            // InternalAntiPattern.g:3087:2: ( ( 'ATTRIBUTE_USE' ) )
            {
            // InternalAntiPattern.g:3087:2: ( ( 'ATTRIBUTE_USE' ) )
            // InternalAntiPattern.g:3088:3: ( 'ATTRIBUTE_USE' )
            {
             before(grammarAccess.getInterCarachteristicAccess().getEATTRIBUTE_USEKeyword_0_0()); 
            // InternalAntiPattern.g:3089:3: ( 'ATTRIBUTE_USE' )
            // InternalAntiPattern.g:3090:4: 'ATTRIBUTE_USE'
            {
             before(grammarAccess.getInterCarachteristicAccess().getEATTRIBUTE_USEKeyword_0_0()); 
            match(input,58,FOLLOW_2); 
             after(grammarAccess.getInterCarachteristicAccess().getEATTRIBUTE_USEKeyword_0_0()); 

            }

             after(grammarAccess.getInterCarachteristicAccess().getEATTRIBUTE_USEKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__EAssignment_0"


    // $ANTLR start "rule__InterCarachteristic__PAssignment_2"
    // InternalAntiPattern.g:3101:1: rule__InterCarachteristic__PAssignment_2 : ( ruleParam ) ;
    public final void rule__InterCarachteristic__PAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3105:1: ( ( ruleParam ) )
            // InternalAntiPattern.g:3106:2: ( ruleParam )
            {
            // InternalAntiPattern.g:3106:2: ( ruleParam )
            // InternalAntiPattern.g:3107:3: ruleParam
            {
             before(grammarAccess.getInterCarachteristicAccess().getPParamParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleParam();

            state._fsp--;

             after(grammarAccess.getInterCarachteristicAccess().getPParamParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__PAssignment_2"


    // $ANTLR start "rule__InterCarachteristic__PAssignment_3_1"
    // InternalAntiPattern.g:3116:1: rule__InterCarachteristic__PAssignment_3_1 : ( ruleParam ) ;
    public final void rule__InterCarachteristic__PAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3120:1: ( ( ruleParam ) )
            // InternalAntiPattern.g:3121:2: ( ruleParam )
            {
            // InternalAntiPattern.g:3121:2: ( ruleParam )
            // InternalAntiPattern.g:3122:3: ruleParam
            {
             before(grammarAccess.getInterCarachteristicAccess().getPParamParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleParam();

            state._fsp--;

             after(grammarAccess.getInterCarachteristicAccess().getPParamParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__PAssignment_3_1"


    // $ANTLR start "rule__InterCarachteristic__ComparatorAssignment_5"
    // InternalAntiPattern.g:3131:1: rule__InterCarachteristic__ComparatorAssignment_5 : ( ruleComparator ) ;
    public final void rule__InterCarachteristic__ComparatorAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3135:1: ( ( ruleComparator ) )
            // InternalAntiPattern.g:3136:2: ( ruleComparator )
            {
            // InternalAntiPattern.g:3136:2: ( ruleComparator )
            // InternalAntiPattern.g:3137:3: ruleComparator
            {
             before(grammarAccess.getInterCarachteristicAccess().getComparatorComparatorParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleComparator();

            state._fsp--;

             after(grammarAccess.getInterCarachteristicAccess().getComparatorComparatorParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__ComparatorAssignment_5"


    // $ANTLR start "rule__InterCarachteristic__ValueAssignment_6"
    // InternalAntiPattern.g:3146:1: rule__InterCarachteristic__ValueAssignment_6 : ( ruleNUMERIC_VALUE ) ;
    public final void rule__InterCarachteristic__ValueAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3150:1: ( ( ruleNUMERIC_VALUE ) )
            // InternalAntiPattern.g:3151:2: ( ruleNUMERIC_VALUE )
            {
            // InternalAntiPattern.g:3151:2: ( ruleNUMERIC_VALUE )
            // InternalAntiPattern.g:3152:3: ruleNUMERIC_VALUE
            {
             before(grammarAccess.getInterCarachteristicAccess().getValueNUMERIC_VALUEParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleNUMERIC_VALUE();

            state._fsp--;

             after(grammarAccess.getInterCarachteristicAccess().getValueNUMERIC_VALUEParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InterCarachteristic__ValueAssignment_6"


    // $ANTLR start "rule__Param__PAssignment"
    // InternalAntiPattern.g:3161:1: rule__Param__PAssignment : ( ( rule__Param__PAlternatives_0 ) ) ;
    public final void rule__Param__PAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAntiPattern.g:3165:1: ( ( ( rule__Param__PAlternatives_0 ) ) )
            // InternalAntiPattern.g:3166:2: ( ( rule__Param__PAlternatives_0 ) )
            {
            // InternalAntiPattern.g:3166:2: ( ( rule__Param__PAlternatives_0 ) )
            // InternalAntiPattern.g:3167:3: ( rule__Param__PAlternatives_0 )
            {
             before(grammarAccess.getParamAccess().getPAlternatives_0()); 
            // InternalAntiPattern.g:3168:3: ( rule__Param__PAlternatives_0 )
            // InternalAntiPattern.g:3168:4: rule__Param__PAlternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__Param__PAlternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getParamAccess().getPAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Param__PAssignment"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000020000000002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000800000000002L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0104080000000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0104000000000002L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0104000000000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0640000000007800L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0018000000000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0010000000000002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x00000000000F8000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000006000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000003FF8000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000001F00000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x000001C000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0080000000000000L});

}