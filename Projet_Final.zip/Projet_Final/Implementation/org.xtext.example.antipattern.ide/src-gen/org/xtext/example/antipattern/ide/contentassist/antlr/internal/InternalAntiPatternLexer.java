package org.xtext.example.antipattern.ide.contentassist.antlr.internal;

// Hack: Use our own Lexer superclass by means of import. 
// Currently there is no other way to specify the superclass for the lexer.
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.Lexer;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalAntiPatternLexer extends Lexer {
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators

    public InternalAntiPatternLexer() {;} 
    public InternalAntiPatternLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public InternalAntiPatternLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "InternalAntiPattern.g"; }

    // $ANTLR start "T__11"
    public final void mT__11() throws RecognitionException {
        try {
            int _type = T__11;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:11:7: ( 'LOC' )
            // InternalAntiPattern.g:11:9: 'LOC'
            {
            match("LOC"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__11"

    // $ANTLR start "T__12"
    public final void mT__12() throws RecognitionException {
        try {
            int _type = T__12;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:12:7: ( 'CYC' )
            // InternalAntiPattern.g:12:9: 'CYC'
            {
            match("CYC"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__12"

    // $ANTLR start "T__13"
    public final void mT__13() throws RecognitionException {
        try {
            int _type = T__13;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:13:7: ( 'NOP' )
            // InternalAntiPattern.g:13:9: 'NOP'
            {
            match("NOP"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__13"

    // $ANTLR start "T__14"
    public final void mT__14() throws RecognitionException {
        try {
            int _type = T__14;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:14:7: ( 'DEPTHNESTING' )
            // InternalAntiPattern.g:14:9: 'DEPTHNESTING'
            {
            match("DEPTHNESTING"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__14"

    // $ANTLR start "T__15"
    public final void mT__15() throws RecognitionException {
        try {
            int _type = T__15;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:15:7: ( 'EQUAL' )
            // InternalAntiPattern.g:15:9: 'EQUAL'
            {
            match("EQUAL"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__15"

    // $ANTLR start "T__16"
    public final void mT__16() throws RecognitionException {
        try {
            int _type = T__16;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:16:7: ( 'LESS' )
            // InternalAntiPattern.g:16:9: 'LESS'
            {
            match("LESS"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__16"

    // $ANTLR start "T__17"
    public final void mT__17() throws RecognitionException {
        try {
            int _type = T__17;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:17:7: ( 'LESS_EQUAL' )
            // InternalAntiPattern.g:17:9: 'LESS_EQUAL'
            {
            match("LESS_EQUAL"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__17"

    // $ANTLR start "T__18"
    public final void mT__18() throws RecognitionException {
        try {
            int _type = T__18;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:18:7: ( 'GREATER' )
            // InternalAntiPattern.g:18:9: 'GREATER'
            {
            match("GREATER"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__18"

    // $ANTLR start "T__19"
    public final void mT__19() throws RecognitionException {
        try {
            int _type = T__19;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:19:7: ( 'GREATER_EQUAL' )
            // InternalAntiPattern.g:19:9: 'GREATER_EQUAL'
            {
            match("GREATER_EQUAL"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__19"

    // $ANTLR start "T__20"
    public final void mT__20() throws RecognitionException {
        try {
            int _type = T__20;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:20:7: ( 'NAMING_CONVENTION' )
            // InternalAntiPattern.g:20:9: 'NAMING_CONVENTION'
            {
            match("NAMING_CONVENTION"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__20"

    // $ANTLR start "T__21"
    public final void mT__21() throws RecognitionException {
        try {
            int _type = T__21;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:21:7: ( 'Consistent_Parameter_Naming' )
            // InternalAntiPattern.g:21:9: 'Consistent_Parameter_Naming'
            {
            match("Consistent_Parameter_Naming"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__21"

    // $ANTLR start "T__22"
    public final void mT__22() throws RecognitionException {
        try {
            int _type = T__22;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:22:7: ( 'Single_Responsibility_Principle' )
            // InternalAntiPattern.g:22:9: 'Single_Responsibility_Principle'
            {
            match("Single_Responsibility_Principle"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__22"

    // $ANTLR start "T__23"
    public final void mT__23() throws RecognitionException {
        try {
            int _type = T__23;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:23:7: ( 'Use_of_Comments' )
            // InternalAntiPattern.g:23:9: 'Use_of_Comments'
            {
            match("Use_of_Comments"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__23"

    // $ANTLR start "T__24"
    public final void mT__24() throws RecognitionException {
        try {
            int _type = T__24;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:24:7: ( 'Avoid_Magic_Numbers' )
            // InternalAntiPattern.g:24:9: 'Avoid_Magic_Numbers'
            {
            match("Avoid_Magic_Numbers"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__24"

    // $ANTLR start "T__25"
    public final void mT__25() throws RecognitionException {
        try {
            int _type = T__25;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:25:7: ( 'many' )
            // InternalAntiPattern.g:25:9: 'many'
            {
            match("many"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__25"

    // $ANTLR start "T__26"
    public final void mT__26() throws RecognitionException {
        try {
            int _type = T__26;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:26:7: ( 'few' )
            // InternalAntiPattern.g:26:9: 'few'
            {
            match("few"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__26"

    // $ANTLR start "T__27"
    public final void mT__27() throws RecognitionException {
        try {
            int _type = T__27;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:27:7: ( 'Complex_Logical_Expressions' )
            // InternalAntiPattern.g:27:9: 'Complex_Logical_Expressions'
            {
            match("Complex_Logical_Expressions"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__27"

    // $ANTLR start "T__28"
    public final void mT__28() throws RecognitionException {
        try {
            int _type = T__28;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:28:7: ( 'ifNestedStructures' )
            // InternalAntiPattern.g:28:9: 'ifNestedStructures'
            {
            match("ifNestedStructures"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__28"

    // $ANTLR start "T__29"
    public final void mT__29() throws RecognitionException {
        try {
            int _type = T__29;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:29:7: ( 'switchNestedStructures' )
            // InternalAntiPattern.g:29:9: 'switchNestedStructures'
            {
            match("switchNestedStructures"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__29"

    // $ANTLR start "T__30"
    public final void mT__30() throws RecognitionException {
        try {
            int _type = T__30;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:30:7: ( 'loopNestedStructures' )
            // InternalAntiPattern.g:30:9: 'loopNestedStructures'
            {
            match("loopNestedStructures"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__30"

    // $ANTLR start "T__31"
    public final void mT__31() throws RecognitionException {
        try {
            int _type = T__31;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:31:7: ( 'ExecutableStatments' )
            // InternalAntiPattern.g:31:9: 'ExecutableStatments'
            {
            match("ExecutableStatments"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__31"

    // $ANTLR start "T__32"
    public final void mT__32() throws RecognitionException {
        try {
            int _type = T__32;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:32:7: ( 'Declare_Variables_Separately' )
            // InternalAntiPattern.g:32:9: 'Declare_Variables_Separately'
            {
            match("Declare_Variables_Separately"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__32"

    // $ANTLR start "T__33"
    public final void mT__33() throws RecognitionException {
        try {
            int _type = T__33;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:33:7: ( 'Add_Comments' )
            // InternalAntiPattern.g:33:9: 'Add_Comments'
            {
            match("Add_Comments"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__33"

    // $ANTLR start "T__34"
    public final void mT__34() throws RecognitionException {
        try {
            int _type = T__34;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:34:7: ( 'Exception_Handling' )
            // InternalAntiPattern.g:34:9: 'Exception_Handling'
            {
            match("Exception_Handling"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__34"

    // $ANTLR start "T__35"
    public final void mT__35() throws RecognitionException {
        try {
            int _type = T__35;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:35:7: ( 'Use_Recursion' )
            // InternalAntiPattern.g:35:9: 'Use_Recursion'
            {
            match("Use_Recursion"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__35"

    // $ANTLR start "T__36"
    public final void mT__36() throws RecognitionException {
        try {
            int _type = T__36;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:36:7: ( 'Use_Global_Variables' )
            // InternalAntiPattern.g:36:9: 'Use_Global_Variables'
            {
            match("Use_Global_Variables"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__36"

    // $ANTLR start "T__37"
    public final void mT__37() throws RecognitionException {
        try {
            int _type = T__37;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:37:7: ( 'unrelatedFonctionnalities' )
            // InternalAntiPattern.g:37:9: 'unrelatedFonctionnalities'
            {
            match("unrelatedFonctionnalities"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__37"

    // $ANTLR start "T__38"
    public final void mT__38() throws RecognitionException {
        try {
            int _type = T__38;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:38:7: ( 'method' )
            // InternalAntiPattern.g:38:9: 'method'
            {
            match("method"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__38"

    // $ANTLR start "T__39"
    public final void mT__39() throws RecognitionException {
        try {
            int _type = T__39;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:39:7: ( 'otherClass' )
            // InternalAntiPattern.g:39:9: 'otherClass'
            {
            match("otherClass"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__39"

    // $ANTLR start "T__40"
    public final void mT__40() throws RecognitionException {
        try {
            int _type = T__40;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:40:7: ( 'ownClass' )
            // InternalAntiPattern.g:40:9: 'ownClass'
            {
            match("ownClass"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__40"

    // $ANTLR start "T__41"
    public final void mT__41() throws RecognitionException {
        try {
            int _type = T__41;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:41:7: ( 'Prompt' )
            // InternalAntiPattern.g:41:9: 'Prompt'
            {
            match("Prompt"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__41"

    // $ANTLR start "T__42"
    public final void mT__42() throws RecognitionException {
        try {
            int _type = T__42;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:42:7: ( '{' )
            // InternalAntiPattern.g:42:9: '{'
            {
            match('{'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__42"

    // $ANTLR start "T__43"
    public final void mT__43() throws RecognitionException {
        try {
            int _type = T__43;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:43:7: ( '}' )
            // InternalAntiPattern.g:43:9: '}'
            {
            match('}'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__43"

    // $ANTLR start "T__44"
    public final void mT__44() throws RecognitionException {
        try {
            int _type = T__44;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:44:7: ( 'nbExemples:' )
            // InternalAntiPattern.g:44:9: 'nbExemples:'
            {
            match("nbExemples:"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__44"

    // $ANTLR start "T__45"
    public final void mT__45() throws RecognitionException {
        try {
            int _type = T__45;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:45:7: ( 'Domain:' )
            // InternalAntiPattern.g:45:9: 'Domain:'
            {
            match("Domain:"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__45"

    // $ANTLR start "T__46"
    public final void mT__46() throws RecognitionException {
        try {
            int _type = T__46;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:46:7: ( 'Classes:' )
            // InternalAntiPattern.g:46:9: 'Classes:'
            {
            match("Classes:"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__46"

    // $ANTLR start "T__47"
    public final void mT__47() throws RecognitionException {
        try {
            int _type = T__47;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:47:7: ( 'class:' )
            // InternalAntiPattern.g:47:9: 'class:'
            {
            match("class:"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__47"

    // $ANTLR start "T__48"
    public final void mT__48() throws RecognitionException {
        try {
            int _type = T__48;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:48:7: ( 'Method_In' )
            // InternalAntiPattern.g:48:9: 'Method_In'
            {
            match("Method_In"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__48"

    // $ANTLR start "T__49"
    public final void mT__49() throws RecognitionException {
        try {
            int _type = T__49;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:49:7: ( 'conditions:' )
            // InternalAntiPattern.g:49:9: 'conditions:'
            {
            match("conditions:"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__49"

    // $ANTLR start "T__50"
    public final void mT__50() throws RecognitionException {
        try {
            int _type = T__50;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:50:7: ( '(' )
            // InternalAntiPattern.g:50:9: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__50"

    // $ANTLR start "T__51"
    public final void mT__51() throws RecognitionException {
        try {
            int _type = T__51;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:51:7: ( ')' )
            // InternalAntiPattern.g:51:9: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__51"

    // $ANTLR start "T__52"
    public final void mT__52() throws RecognitionException {
        try {
            int _type = T__52;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:52:7: ( ',' )
            // InternalAntiPattern.g:52:9: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__52"

    // $ANTLR start "T__53"
    public final void mT__53() throws RecognitionException {
        try {
            int _type = T__53;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:53:7: ( 'manners' )
            // InternalAntiPattern.g:53:9: 'manners'
            {
            match("manners"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__53"

    // $ANTLR start "T__54"
    public final void mT__54() throws RecognitionException {
        try {
            int _type = T__54;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:54:7: ( 'violates' )
            // InternalAntiPattern.g:54:9: 'violates'
            {
            match("violates"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__54"

    // $ANTLR start "T__55"
    public final void mT__55() throws RecognitionException {
        try {
            int _type = T__55;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:55:7: ( '/' )
            // InternalAntiPattern.g:55:9: '/'
            {
            match('/'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__55"

    // $ANTLR start "T__56"
    public final void mT__56() throws RecognitionException {
        try {
            int _type = T__56;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:56:7: ( 'UNION' )
            // InternalAntiPattern.g:56:9: 'UNION'
            {
            match("UNION"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__56"

    // $ANTLR start "T__57"
    public final void mT__57() throws RecognitionException {
        try {
            int _type = T__57;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:57:7: ( 'COH' )
            // InternalAntiPattern.g:57:9: 'COH'
            {
            match("COH"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__57"

    // $ANTLR start "T__58"
    public final void mT__58() throws RecognitionException {
        try {
            int _type = T__58;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:58:7: ( 'ATTRIBUTE_USE' )
            // InternalAntiPattern.g:58:9: 'ATTRIBUTE_USE'
            {
            match("ATTRIBUTE_USE"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__58"

    // $ANTLR start "RULE_ID"
    public final void mRULE_ID() throws RecognitionException {
        try {
            int _type = RULE_ID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:3176:9: ( ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* )
            // InternalAntiPattern.g:3176:11: ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            {
            // InternalAntiPattern.g:3176:11: ( '^' )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0=='^') ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalAntiPattern.g:3176:11: '^'
                    {
                    match('^'); 

                    }
                    break;

            }

            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // InternalAntiPattern.g:3176:40: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='0' && LA2_0<='9')||(LA2_0>='A' && LA2_0<='Z')||LA2_0=='_'||(LA2_0>='a' && LA2_0<='z')) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalAntiPattern.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ID"

    // $ANTLR start "RULE_INT"
    public final void mRULE_INT() throws RecognitionException {
        try {
            int _type = RULE_INT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:3178:10: ( ( '0' .. '9' )+ )
            // InternalAntiPattern.g:3178:12: ( '0' .. '9' )+
            {
            // InternalAntiPattern.g:3178:12: ( '0' .. '9' )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>='0' && LA3_0<='9')) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalAntiPattern.g:3178:13: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_INT"

    // $ANTLR start "RULE_STRING"
    public final void mRULE_STRING() throws RecognitionException {
        try {
            int _type = RULE_STRING;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:3180:13: ( ( '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"' | '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\'' ) )
            // InternalAntiPattern.g:3180:15: ( '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"' | '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\'' )
            {
            // InternalAntiPattern.g:3180:15: ( '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"' | '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\'' )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0=='\"') ) {
                alt6=1;
            }
            else if ( (LA6_0=='\'') ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalAntiPattern.g:3180:16: '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"'
                    {
                    match('\"'); 
                    // InternalAntiPattern.g:3180:20: ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )*
                    loop4:
                    do {
                        int alt4=3;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0=='\\') ) {
                            alt4=1;
                        }
                        else if ( ((LA4_0>='\u0000' && LA4_0<='!')||(LA4_0>='#' && LA4_0<='[')||(LA4_0>=']' && LA4_0<='\uFFFF')) ) {
                            alt4=2;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalAntiPattern.g:3180:21: '\\\\' .
                    	    {
                    	    match('\\'); 
                    	    matchAny(); 

                    	    }
                    	    break;
                    	case 2 :
                    	    // InternalAntiPattern.g:3180:28: ~ ( ( '\\\\' | '\"' ) )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;}


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);

                    match('\"'); 

                    }
                    break;
                case 2 :
                    // InternalAntiPattern.g:3180:48: '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\''
                    {
                    match('\''); 
                    // InternalAntiPattern.g:3180:53: ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )*
                    loop5:
                    do {
                        int alt5=3;
                        int LA5_0 = input.LA(1);

                        if ( (LA5_0=='\\') ) {
                            alt5=1;
                        }
                        else if ( ((LA5_0>='\u0000' && LA5_0<='&')||(LA5_0>='(' && LA5_0<='[')||(LA5_0>=']' && LA5_0<='\uFFFF')) ) {
                            alt5=2;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // InternalAntiPattern.g:3180:54: '\\\\' .
                    	    {
                    	    match('\\'); 
                    	    matchAny(); 

                    	    }
                    	    break;
                    	case 2 :
                    	    // InternalAntiPattern.g:3180:61: ~ ( ( '\\\\' | '\\'' ) )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;}


                    	    }
                    	    break;

                    	default :
                    	    break loop5;
                        }
                    } while (true);

                    match('\''); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_STRING"

    // $ANTLR start "RULE_ML_COMMENT"
    public final void mRULE_ML_COMMENT() throws RecognitionException {
        try {
            int _type = RULE_ML_COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:3182:17: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // InternalAntiPattern.g:3182:19: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match("/*"); 

            // InternalAntiPattern.g:3182:24: ( options {greedy=false; } : . )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0=='*') ) {
                    int LA7_1 = input.LA(2);

                    if ( (LA7_1=='/') ) {
                        alt7=2;
                    }
                    else if ( ((LA7_1>='\u0000' && LA7_1<='.')||(LA7_1>='0' && LA7_1<='\uFFFF')) ) {
                        alt7=1;
                    }


                }
                else if ( ((LA7_0>='\u0000' && LA7_0<=')')||(LA7_0>='+' && LA7_0<='\uFFFF')) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalAntiPattern.g:3182:52: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            match("*/"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ML_COMMENT"

    // $ANTLR start "RULE_SL_COMMENT"
    public final void mRULE_SL_COMMENT() throws RecognitionException {
        try {
            int _type = RULE_SL_COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:3184:17: ( '//' (~ ( ( '\\n' | '\\r' ) ) )* ( ( '\\r' )? '\\n' )? )
            // InternalAntiPattern.g:3184:19: '//' (~ ( ( '\\n' | '\\r' ) ) )* ( ( '\\r' )? '\\n' )?
            {
            match("//"); 

            // InternalAntiPattern.g:3184:24: (~ ( ( '\\n' | '\\r' ) ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( ((LA8_0>='\u0000' && LA8_0<='\t')||(LA8_0>='\u000B' && LA8_0<='\f')||(LA8_0>='\u000E' && LA8_0<='\uFFFF')) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalAntiPattern.g:3184:24: ~ ( ( '\\n' | '\\r' ) )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            // InternalAntiPattern.g:3184:40: ( ( '\\r' )? '\\n' )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0=='\n'||LA10_0=='\r') ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalAntiPattern.g:3184:41: ( '\\r' )? '\\n'
                    {
                    // InternalAntiPattern.g:3184:41: ( '\\r' )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0=='\r') ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // InternalAntiPattern.g:3184:41: '\\r'
                            {
                            match('\r'); 

                            }
                            break;

                    }

                    match('\n'); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_SL_COMMENT"

    // $ANTLR start "RULE_WS"
    public final void mRULE_WS() throws RecognitionException {
        try {
            int _type = RULE_WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:3186:9: ( ( ' ' | '\\t' | '\\r' | '\\n' )+ )
            // InternalAntiPattern.g:3186:11: ( ' ' | '\\t' | '\\r' | '\\n' )+
            {
            // InternalAntiPattern.g:3186:11: ( ' ' | '\\t' | '\\r' | '\\n' )+
            int cnt11=0;
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( ((LA11_0>='\t' && LA11_0<='\n')||LA11_0=='\r'||LA11_0==' ') ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalAntiPattern.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||input.LA(1)=='\r'||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt11 >= 1 ) break loop11;
                        EarlyExitException eee =
                            new EarlyExitException(11, input);
                        throw eee;
                }
                cnt11++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_WS"

    // $ANTLR start "RULE_ANY_OTHER"
    public final void mRULE_ANY_OTHER() throws RecognitionException {
        try {
            int _type = RULE_ANY_OTHER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalAntiPattern.g:3188:16: ( . )
            // InternalAntiPattern.g:3188:18: .
            {
            matchAny(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ANY_OTHER"

    public void mTokens() throws RecognitionException {
        // InternalAntiPattern.g:1:8: ( T__11 | T__12 | T__13 | T__14 | T__15 | T__16 | T__17 | T__18 | T__19 | T__20 | T__21 | T__22 | T__23 | T__24 | T__25 | T__26 | T__27 | T__28 | T__29 | T__30 | T__31 | T__32 | T__33 | T__34 | T__35 | T__36 | T__37 | T__38 | T__39 | T__40 | T__41 | T__42 | T__43 | T__44 | T__45 | T__46 | T__47 | T__48 | T__49 | T__50 | T__51 | T__52 | T__53 | T__54 | T__55 | T__56 | T__57 | T__58 | RULE_ID | RULE_INT | RULE_STRING | RULE_ML_COMMENT | RULE_SL_COMMENT | RULE_WS | RULE_ANY_OTHER )
        int alt12=55;
        alt12 = dfa12.predict(input);
        switch (alt12) {
            case 1 :
                // InternalAntiPattern.g:1:10: T__11
                {
                mT__11(); 

                }
                break;
            case 2 :
                // InternalAntiPattern.g:1:16: T__12
                {
                mT__12(); 

                }
                break;
            case 3 :
                // InternalAntiPattern.g:1:22: T__13
                {
                mT__13(); 

                }
                break;
            case 4 :
                // InternalAntiPattern.g:1:28: T__14
                {
                mT__14(); 

                }
                break;
            case 5 :
                // InternalAntiPattern.g:1:34: T__15
                {
                mT__15(); 

                }
                break;
            case 6 :
                // InternalAntiPattern.g:1:40: T__16
                {
                mT__16(); 

                }
                break;
            case 7 :
                // InternalAntiPattern.g:1:46: T__17
                {
                mT__17(); 

                }
                break;
            case 8 :
                // InternalAntiPattern.g:1:52: T__18
                {
                mT__18(); 

                }
                break;
            case 9 :
                // InternalAntiPattern.g:1:58: T__19
                {
                mT__19(); 

                }
                break;
            case 10 :
                // InternalAntiPattern.g:1:64: T__20
                {
                mT__20(); 

                }
                break;
            case 11 :
                // InternalAntiPattern.g:1:70: T__21
                {
                mT__21(); 

                }
                break;
            case 12 :
                // InternalAntiPattern.g:1:76: T__22
                {
                mT__22(); 

                }
                break;
            case 13 :
                // InternalAntiPattern.g:1:82: T__23
                {
                mT__23(); 

                }
                break;
            case 14 :
                // InternalAntiPattern.g:1:88: T__24
                {
                mT__24(); 

                }
                break;
            case 15 :
                // InternalAntiPattern.g:1:94: T__25
                {
                mT__25(); 

                }
                break;
            case 16 :
                // InternalAntiPattern.g:1:100: T__26
                {
                mT__26(); 

                }
                break;
            case 17 :
                // InternalAntiPattern.g:1:106: T__27
                {
                mT__27(); 

                }
                break;
            case 18 :
                // InternalAntiPattern.g:1:112: T__28
                {
                mT__28(); 

                }
                break;
            case 19 :
                // InternalAntiPattern.g:1:118: T__29
                {
                mT__29(); 

                }
                break;
            case 20 :
                // InternalAntiPattern.g:1:124: T__30
                {
                mT__30(); 

                }
                break;
            case 21 :
                // InternalAntiPattern.g:1:130: T__31
                {
                mT__31(); 

                }
                break;
            case 22 :
                // InternalAntiPattern.g:1:136: T__32
                {
                mT__32(); 

                }
                break;
            case 23 :
                // InternalAntiPattern.g:1:142: T__33
                {
                mT__33(); 

                }
                break;
            case 24 :
                // InternalAntiPattern.g:1:148: T__34
                {
                mT__34(); 

                }
                break;
            case 25 :
                // InternalAntiPattern.g:1:154: T__35
                {
                mT__35(); 

                }
                break;
            case 26 :
                // InternalAntiPattern.g:1:160: T__36
                {
                mT__36(); 

                }
                break;
            case 27 :
                // InternalAntiPattern.g:1:166: T__37
                {
                mT__37(); 

                }
                break;
            case 28 :
                // InternalAntiPattern.g:1:172: T__38
                {
                mT__38(); 

                }
                break;
            case 29 :
                // InternalAntiPattern.g:1:178: T__39
                {
                mT__39(); 

                }
                break;
            case 30 :
                // InternalAntiPattern.g:1:184: T__40
                {
                mT__40(); 

                }
                break;
            case 31 :
                // InternalAntiPattern.g:1:190: T__41
                {
                mT__41(); 

                }
                break;
            case 32 :
                // InternalAntiPattern.g:1:196: T__42
                {
                mT__42(); 

                }
                break;
            case 33 :
                // InternalAntiPattern.g:1:202: T__43
                {
                mT__43(); 

                }
                break;
            case 34 :
                // InternalAntiPattern.g:1:208: T__44
                {
                mT__44(); 

                }
                break;
            case 35 :
                // InternalAntiPattern.g:1:214: T__45
                {
                mT__45(); 

                }
                break;
            case 36 :
                // InternalAntiPattern.g:1:220: T__46
                {
                mT__46(); 

                }
                break;
            case 37 :
                // InternalAntiPattern.g:1:226: T__47
                {
                mT__47(); 

                }
                break;
            case 38 :
                // InternalAntiPattern.g:1:232: T__48
                {
                mT__48(); 

                }
                break;
            case 39 :
                // InternalAntiPattern.g:1:238: T__49
                {
                mT__49(); 

                }
                break;
            case 40 :
                // InternalAntiPattern.g:1:244: T__50
                {
                mT__50(); 

                }
                break;
            case 41 :
                // InternalAntiPattern.g:1:250: T__51
                {
                mT__51(); 

                }
                break;
            case 42 :
                // InternalAntiPattern.g:1:256: T__52
                {
                mT__52(); 

                }
                break;
            case 43 :
                // InternalAntiPattern.g:1:262: T__53
                {
                mT__53(); 

                }
                break;
            case 44 :
                // InternalAntiPattern.g:1:268: T__54
                {
                mT__54(); 

                }
                break;
            case 45 :
                // InternalAntiPattern.g:1:274: T__55
                {
                mT__55(); 

                }
                break;
            case 46 :
                // InternalAntiPattern.g:1:280: T__56
                {
                mT__56(); 

                }
                break;
            case 47 :
                // InternalAntiPattern.g:1:286: T__57
                {
                mT__57(); 

                }
                break;
            case 48 :
                // InternalAntiPattern.g:1:292: T__58
                {
                mT__58(); 

                }
                break;
            case 49 :
                // InternalAntiPattern.g:1:298: RULE_ID
                {
                mRULE_ID(); 

                }
                break;
            case 50 :
                // InternalAntiPattern.g:1:306: RULE_INT
                {
                mRULE_INT(); 

                }
                break;
            case 51 :
                // InternalAntiPattern.g:1:315: RULE_STRING
                {
                mRULE_STRING(); 

                }
                break;
            case 52 :
                // InternalAntiPattern.g:1:327: RULE_ML_COMMENT
                {
                mRULE_ML_COMMENT(); 

                }
                break;
            case 53 :
                // InternalAntiPattern.g:1:343: RULE_SL_COMMENT
                {
                mRULE_SL_COMMENT(); 

                }
                break;
            case 54 :
                // InternalAntiPattern.g:1:359: RULE_WS
                {
                mRULE_WS(); 

                }
                break;
            case 55 :
                // InternalAntiPattern.g:1:367: RULE_ANY_OTHER
                {
                mRULE_ANY_OTHER(); 

                }
                break;

        }

    }


    protected DFA12 dfa12 = new DFA12(this);
    static final String DFA12_eotS =
        "\1\uffff\21\45\2\uffff\3\45\3\uffff\1\45\1\116\1\42\2\uffff\2\42\2\uffff\2\45\1\uffff\34\45\2\uffff\4\45\3\uffff\1\45\6\uffff\1\167\1\45\1\171\3\45\1\175\1\176\20\45\1\u0090\14\45\1\uffff\1\u009e\1\uffff\3\45\2\uffff\16\45\1\u00b2\2\45\1\uffff\15\45\1\uffff\7\45\1\u00c9\7\45\1\u00d1\3\45\1\uffff\26\45\1\uffff\7\45\1\uffff\4\45\1\u00f6\6\45\1\u00fd\1\45\1\uffff\12\45\1\uffff\2\45\1\u010c\7\45\1\u0114\1\uffff\6\45\1\uffff\7\45\1\uffff\6\45\1\uffff\7\45\1\uffff\5\45\1\u0134\3\45\1\u0138\25\45\1\uffff\2\45\1\u0150\1\uffff\1\u0151\23\45\1\u0165\2\45\2\uffff\23\45\3\uffff\3\45\1\u017e\11\45\1\u0188\10\45\1\uffff\3\45\1\u0194\2\45\1\u0197\2\45\1\uffff\1\u019a\12\45\1\uffff\2\45\1\uffff\2\45\1\uffff\13\45\1\u01b4\15\45\1\uffff\10\45\1\u01ca\14\45\1\uffff\2\45\1\u01d9\3\45\1\u01dd\6\45\1\u01e4\1\uffff\2\45\1\u01e7\1\uffff\6\45\1\uffff\1\45\1\u01ef\1\uffff\1\45\1\u01f1\5\45\1\uffff\1\45\1\uffff\5\45\1\u01fd\5\45\1\uffff\12\45\1\u020d\4\45\1\uffff\1\u0212\1\u0213\2\45\2\uffff\1\u0216\1\45\1\uffff\2\45\1\u021a\1\uffff";
    static final String DFA12_eofS =
        "\u021b\uffff";
    static final String DFA12_minS =
        "\1\0\1\105\1\117\1\101\1\105\1\121\1\122\1\151\1\116\1\124\1\141\1\145\1\146\1\167\1\157\1\156\1\164\1\162\2\uffff\1\142\1\154\1\145\3\uffff\1\151\1\52\1\101\2\uffff\2\0\2\uffff\1\103\1\123\1\uffff\1\103\1\155\1\141\1\110\1\120\1\115\1\120\1\143\1\155\1\125\1\143\1\105\1\156\1\145\1\111\1\157\1\144\1\124\1\156\1\164\1\167\1\116\1\151\1\157\1\162\1\150\1\156\1\157\2\uffff\1\105\1\141\1\156\1\164\3\uffff\1\157\6\uffff\1\60\1\123\1\60\1\163\1\160\1\163\2\60\1\111\1\124\1\154\1\141\1\101\1\143\1\145\1\101\1\147\1\137\1\117\1\151\1\137\1\122\1\156\1\150\1\60\1\145\1\164\1\160\2\145\1\103\1\155\1\170\1\163\1\144\1\150\1\154\1\uffff\1\60\1\uffff\1\151\1\154\1\163\2\uffff\1\116\1\110\1\141\1\151\1\114\1\165\1\160\1\124\1\154\1\107\1\116\1\144\1\103\1\111\1\60\1\145\1\157\1\uffff\1\163\1\143\1\116\1\154\1\162\1\154\1\160\1\145\1\163\1\151\1\157\1\141\1\105\1\uffff\1\163\2\145\1\107\1\116\1\162\1\156\1\60\2\164\1\105\1\145\1\146\1\145\1\154\1\60\1\137\1\157\1\102\1\uffff\1\162\1\144\1\164\1\150\1\145\1\141\1\103\1\141\1\164\1\155\1\72\1\164\1\144\1\164\1\121\1\164\1\170\1\163\1\137\1\105\1\145\1\72\1\uffff\1\141\1\151\1\122\2\137\1\143\1\157\1\uffff\1\115\1\155\1\125\1\163\1\60\1\145\1\116\1\163\1\164\1\154\1\163\1\60\1\160\1\uffff\1\151\1\137\1\145\1\125\1\145\1\137\1\72\1\103\1\123\1\137\1\uffff\1\142\1\157\1\60\1\122\1\103\1\165\1\142\1\141\1\155\1\124\1\60\1\uffff\1\144\1\145\1\164\1\145\1\141\1\163\1\uffff\1\154\1\157\1\111\1\163\1\101\1\156\1\114\1\uffff\1\117\1\124\1\126\1\154\1\156\1\105\1\uffff\1\145\1\157\1\162\1\141\1\147\1\145\1\105\1\uffff\1\123\1\163\1\145\1\144\1\163\1\60\1\145\2\156\1\60\1\114\1\164\1\157\1\116\1\111\1\141\1\145\1\137\1\121\1\163\1\155\1\163\1\154\1\151\1\156\1\137\2\164\1\144\1\106\1\163\1\uffff\2\163\1\60\1\uffff\1\60\1\137\1\147\1\126\1\116\1\162\1\123\1\110\1\125\1\160\1\155\1\151\1\137\1\143\1\164\1\125\1\162\1\145\1\123\1\157\1\60\2\72\2\uffff\1\120\1\151\1\105\1\107\1\151\1\164\1\141\1\101\1\157\1\145\1\157\1\126\1\137\1\163\1\123\1\165\1\144\1\164\1\156\3\uffff\1\141\1\143\1\116\1\60\2\141\1\156\1\114\3\156\1\141\1\116\1\60\1\105\1\143\1\123\1\162\1\143\1\162\1\141\1\124\1\uffff\1\142\1\164\1\144\1\60\1\163\1\164\1\60\1\162\1\165\1\uffff\1\60\2\164\1\165\1\164\1\141\1\154\1\111\1\154\1\155\1\154\1\uffff\1\151\1\163\1\uffff\1\151\1\155\1\uffff\1\165\1\162\1\143\1\151\1\155\1\137\1\117\2\145\1\151\1\142\1\60\1\141\1\142\1\162\1\165\1\164\1\157\1\145\1\105\1\116\1\163\2\156\1\151\1\uffff\1\142\2\145\1\143\1\165\1\156\1\164\1\170\1\60\1\137\1\164\1\147\2\154\1\162\1\163\1\164\1\162\1\156\1\145\1\160\1\uffff\1\123\1\163\1\60\1\151\1\145\1\163\1\60\1\165\1\145\1\141\2\162\1\145\1\60\1\uffff\1\164\1\163\1\60\1\uffff\1\162\1\163\1\154\1\137\1\145\1\160\1\uffff\1\171\1\60\1\uffff\1\145\1\60\1\151\1\116\1\163\1\141\1\137\1\uffff\1\163\1\uffff\1\164\1\141\1\163\1\162\1\120\1\60\1\151\1\155\1\151\1\141\1\162\1\uffff\1\145\1\151\1\157\1\164\1\151\1\163\2\156\1\145\1\156\1\60\1\147\1\163\1\154\1\143\1\uffff\2\60\1\171\1\151\2\uffff\1\60\1\160\1\uffff\1\154\1\145\1\60\1\uffff";
    static final String DFA12_maxS =
        "\1\uffff\1\117\1\157\1\117\1\157\1\170\1\122\1\151\1\163\1\166\2\145\1\146\1\167\1\157\1\156\1\167\1\162\2\uffff\1\142\1\157\1\145\3\uffff\1\151\1\57\1\172\2\uffff\2\uffff\2\uffff\1\103\1\123\1\uffff\1\103\1\156\1\141\1\110\1\120\1\115\1\120\1\143\1\155\1\125\1\145\1\105\1\156\1\145\1\111\1\157\1\144\1\124\1\156\1\164\1\167\1\116\1\151\1\157\1\162\1\150\1\156\1\157\2\uffff\1\105\1\141\1\156\1\164\3\uffff\1\157\6\uffff\1\172\1\123\1\172\1\163\1\160\1\163\2\172\1\111\1\124\1\154\1\141\1\101\1\143\1\145\1\101\1\147\1\137\1\117\1\151\1\137\1\122\1\171\1\150\1\172\1\145\1\164\1\160\2\145\1\103\1\155\1\170\1\163\1\144\1\150\1\154\1\uffff\1\172\1\uffff\1\151\1\154\1\163\2\uffff\1\116\1\110\1\141\1\151\1\114\1\165\1\160\1\124\1\154\1\157\1\116\1\144\1\103\1\111\1\172\1\145\1\157\1\uffff\1\163\1\143\1\116\1\154\1\162\1\154\1\160\1\145\1\163\1\151\1\157\1\141\1\105\1\uffff\1\163\2\145\1\107\1\116\1\162\1\156\1\172\2\164\1\105\1\145\1\146\1\145\1\154\1\172\1\137\1\157\1\102\1\uffff\1\162\1\144\1\164\1\150\1\145\1\141\1\103\1\141\1\164\1\155\1\72\1\164\1\144\1\164\1\121\1\164\1\170\1\163\1\137\1\105\1\145\1\72\1\uffff\1\141\1\151\1\122\2\137\1\143\1\157\1\uffff\1\115\1\155\1\125\1\163\1\172\1\145\1\116\1\163\1\164\1\154\1\163\1\172\1\160\1\uffff\1\151\1\137\1\145\1\125\1\145\1\137\1\72\1\103\1\123\1\137\1\uffff\1\142\1\157\1\172\1\122\1\103\1\165\1\142\1\141\1\155\1\124\1\172\1\uffff\1\144\1\145\1\164\1\145\1\141\1\163\1\uffff\1\154\1\157\1\111\1\163\1\101\1\156\1\114\1\uffff\1\117\1\124\1\126\1\154\1\156\1\105\1\uffff\1\145\1\157\1\162\1\141\1\147\1\145\1\105\1\uffff\1\123\1\163\1\145\1\144\1\163\1\172\1\145\2\156\1\172\1\114\1\164\1\157\1\116\1\111\1\141\1\145\1\137\1\121\1\163\1\155\1\163\1\154\1\151\1\156\1\137\2\164\1\144\1\106\1\163\1\uffff\2\163\1\172\1\uffff\1\172\1\137\1\147\1\126\1\116\1\162\1\123\1\110\1\125\1\160\1\155\1\151\1\137\1\143\1\164\1\125\1\162\1\145\1\123\1\157\1\172\2\72\2\uffff\1\120\1\151\1\105\1\107\1\151\1\164\1\141\1\101\1\157\1\145\1\157\1\126\1\137\1\163\1\123\1\165\1\144\1\164\1\156\3\uffff\1\141\1\143\1\116\1\172\2\141\1\156\1\114\3\156\1\141\1\116\1\172\1\105\1\143\1\123\1\162\1\143\1\162\1\141\1\124\1\uffff\1\142\1\164\1\144\1\172\1\163\1\164\1\172\1\162\1\165\1\uffff\1\172\2\164\1\165\1\164\1\141\1\154\1\111\1\154\1\155\1\154\1\uffff\1\151\1\163\1\uffff\1\151\1\155\1\uffff\1\165\1\162\1\143\1\151\1\155\1\137\1\117\2\145\1\151\1\142\1\172\1\141\1\142\1\162\1\165\1\164\1\157\1\145\1\105\1\116\1\163\2\156\1\151\1\uffff\1\142\2\145\1\143\1\165\1\156\1\164\1\170\1\172\1\137\1\164\1\147\2\154\1\162\1\163\1\164\1\162\1\156\1\145\1\160\1\uffff\1\123\1\163\1\172\1\151\1\145\1\163\1\172\1\165\1\145\1\141\2\162\1\145\1\172\1\uffff\1\164\1\163\1\172\1\uffff\1\162\1\163\1\154\1\137\1\145\1\160\1\uffff\1\171\1\172\1\uffff\1\145\1\172\1\151\1\116\1\163\1\141\1\137\1\uffff\1\163\1\uffff\1\164\1\141\1\163\1\162\1\120\1\172\1\151\1\155\1\151\1\141\1\162\1\uffff\1\145\1\151\1\157\1\164\1\151\1\163\2\156\1\145\1\156\1\172\1\147\1\163\1\154\1\143\1\uffff\2\172\1\171\1\151\2\uffff\1\172\1\160\1\uffff\1\154\1\145\1\172\1\uffff";
    static final String DFA12_acceptS =
        "\22\uffff\1\40\1\41\3\uffff\1\50\1\51\1\52\3\uffff\1\61\1\62\2\uffff\1\66\1\67\2\uffff\1\61\34\uffff\1\40\1\41\4\uffff\1\50\1\51\1\52\1\uffff\1\64\1\65\1\55\1\62\1\63\1\66\45\uffff\1\1\1\uffff\1\2\3\uffff\1\57\1\3\21\uffff\1\20\15\uffff\1\6\23\uffff\1\17\26\uffff\1\5\7\uffff\1\56\15\uffff\1\45\12\uffff\1\43\13\uffff\1\34\6\uffff\1\37\7\uffff\1\44\6\uffff\1\10\7\uffff\1\53\37\uffff\1\36\3\uffff\1\54\27\uffff\1\46\1\7\23\uffff\1\35\1\42\1\47\26\uffff\1\4\11\uffff\1\27\13\uffff\1\11\2\uffff\1\31\2\uffff\1\60\31\uffff\1\15\25\uffff\1\12\16\uffff\1\30\3\uffff\1\22\6\uffff\1\25\2\uffff\1\16\7\uffff\1\32\1\uffff\1\24\13\uffff\1\23\17\uffff\1\33\4\uffff\1\13\1\21\2\uffff\1\26\3\uffff\1\14";
    static final String DFA12_specialS =
        "\1\0\36\uffff\1\1\1\2\u01fa\uffff}>";
    static final String[] DFA12_transitionS = {
            "\11\42\2\41\2\42\1\41\22\42\1\41\1\42\1\37\4\42\1\40\1\27\1\30\2\42\1\31\2\42\1\33\12\36\7\42\1\11\1\35\1\2\1\4\1\5\1\35\1\6\4\35\1\1\1\26\1\3\1\35\1\21\2\35\1\7\1\35\1\10\5\35\3\42\1\34\1\35\1\42\2\35\1\25\2\35\1\13\2\35\1\14\2\35\1\16\1\12\1\24\1\20\3\35\1\15\1\35\1\17\1\32\4\35\1\22\1\42\1\23\uff82\42",
            "\1\44\11\uffff\1\43",
            "\1\51\11\uffff\1\46\22\uffff\1\50\2\uffff\1\47",
            "\1\53\15\uffff\1\52",
            "\1\54\37\uffff\1\55\11\uffff\1\56",
            "\1\57\46\uffff\1\60",
            "\1\61",
            "\1\62",
            "\1\64\44\uffff\1\63",
            "\1\67\17\uffff\1\66\21\uffff\1\65",
            "\1\70\3\uffff\1\71",
            "\1\72",
            "\1\73",
            "\1\74",
            "\1\75",
            "\1\76",
            "\1\77\2\uffff\1\100",
            "\1\101",
            "",
            "",
            "\1\104",
            "\1\105\2\uffff\1\106",
            "\1\107",
            "",
            "",
            "",
            "\1\113",
            "\1\114\4\uffff\1\115",
            "\32\45\4\uffff\1\45\1\uffff\32\45",
            "",
            "",
            "\0\120",
            "\0\120",
            "",
            "",
            "\1\122",
            "\1\123",
            "",
            "\1\124",
            "\1\126\1\125",
            "\1\127",
            "\1\130",
            "\1\131",
            "\1\132",
            "\1\133",
            "\1\134",
            "\1\135",
            "\1\136",
            "\1\140\1\uffff\1\137",
            "\1\141",
            "\1\142",
            "\1\143",
            "\1\144",
            "\1\145",
            "\1\146",
            "\1\147",
            "\1\150",
            "\1\151",
            "\1\152",
            "\1\153",
            "\1\154",
            "\1\155",
            "\1\156",
            "\1\157",
            "\1\160",
            "\1\161",
            "",
            "",
            "\1\162",
            "\1\163",
            "\1\164",
            "\1\165",
            "",
            "",
            "",
            "\1\166",
            "",
            "",
            "",
            "",
            "",
            "",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\170",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\172",
            "\1\173",
            "\1\174",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\177",
            "\1\u0080",
            "\1\u0081",
            "\1\u0082",
            "\1\u0083",
            "\1\u0084",
            "\1\u0085",
            "\1\u0086",
            "\1\u0087",
            "\1\u0088",
            "\1\u0089",
            "\1\u008a",
            "\1\u008b",
            "\1\u008c",
            "\1\u008e\12\uffff\1\u008d",
            "\1\u008f",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0091",
            "\1\u0092",
            "\1\u0093",
            "\1\u0094",
            "\1\u0095",
            "\1\u0096",
            "\1\u0097",
            "\1\u0098",
            "\1\u0099",
            "\1\u009a",
            "\1\u009b",
            "\1\u009c",
            "",
            "\12\45\7\uffff\32\45\4\uffff\1\u009d\1\uffff\32\45",
            "",
            "\1\u009f",
            "\1\u00a0",
            "\1\u00a1",
            "",
            "",
            "\1\u00a2",
            "\1\u00a3",
            "\1\u00a4",
            "\1\u00a5",
            "\1\u00a6",
            "\1\u00a7",
            "\1\u00a8",
            "\1\u00a9",
            "\1\u00aa",
            "\1\u00ad\12\uffff\1\u00ac\34\uffff\1\u00ab",
            "\1\u00ae",
            "\1\u00af",
            "\1\u00b0",
            "\1\u00b1",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u00b3",
            "\1\u00b4",
            "",
            "\1\u00b5",
            "\1\u00b6",
            "\1\u00b7",
            "\1\u00b8",
            "\1\u00b9",
            "\1\u00ba",
            "\1\u00bb",
            "\1\u00bc",
            "\1\u00bd",
            "\1\u00be",
            "\1\u00bf",
            "\1\u00c0",
            "\1\u00c1",
            "",
            "\1\u00c2",
            "\1\u00c3",
            "\1\u00c4",
            "\1\u00c5",
            "\1\u00c6",
            "\1\u00c7",
            "\1\u00c8",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u00ca",
            "\1\u00cb",
            "\1\u00cc",
            "\1\u00cd",
            "\1\u00ce",
            "\1\u00cf",
            "\1\u00d0",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u00d2",
            "\1\u00d3",
            "\1\u00d4",
            "",
            "\1\u00d5",
            "\1\u00d6",
            "\1\u00d7",
            "\1\u00d8",
            "\1\u00d9",
            "\1\u00da",
            "\1\u00db",
            "\1\u00dc",
            "\1\u00dd",
            "\1\u00de",
            "\1\u00df",
            "\1\u00e0",
            "\1\u00e1",
            "\1\u00e2",
            "\1\u00e3",
            "\1\u00e4",
            "\1\u00e5",
            "\1\u00e6",
            "\1\u00e7",
            "\1\u00e8",
            "\1\u00e9",
            "\1\u00ea",
            "",
            "\1\u00eb",
            "\1\u00ec",
            "\1\u00ed",
            "\1\u00ee",
            "\1\u00ef",
            "\1\u00f0",
            "\1\u00f1",
            "",
            "\1\u00f2",
            "\1\u00f3",
            "\1\u00f4",
            "\1\u00f5",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u00f7",
            "\1\u00f8",
            "\1\u00f9",
            "\1\u00fa",
            "\1\u00fb",
            "\1\u00fc",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u00fe",
            "",
            "\1\u00ff",
            "\1\u0100",
            "\1\u0101",
            "\1\u0102",
            "\1\u0103",
            "\1\u0104",
            "\1\u0105",
            "\1\u0106",
            "\1\u0107",
            "\1\u0108",
            "",
            "\1\u0109",
            "\1\u010a",
            "\12\45\7\uffff\32\45\4\uffff\1\u010b\1\uffff\32\45",
            "\1\u010d",
            "\1\u010e",
            "\1\u010f",
            "\1\u0110",
            "\1\u0111",
            "\1\u0112",
            "\1\u0113",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "",
            "\1\u0115",
            "\1\u0116",
            "\1\u0117",
            "\1\u0118",
            "\1\u0119",
            "\1\u011a",
            "",
            "\1\u011b",
            "\1\u011c",
            "\1\u011d",
            "\1\u011e",
            "\1\u011f",
            "\1\u0120",
            "\1\u0121",
            "",
            "\1\u0122",
            "\1\u0123",
            "\1\u0124",
            "\1\u0125",
            "\1\u0126",
            "\1\u0127",
            "",
            "\1\u0128",
            "\1\u0129",
            "\1\u012a",
            "\1\u012b",
            "\1\u012c",
            "\1\u012d",
            "\1\u012e",
            "",
            "\1\u012f",
            "\1\u0130",
            "\1\u0131",
            "\1\u0132",
            "\1\u0133",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0135",
            "\1\u0136",
            "\1\u0137",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0139",
            "\1\u013a",
            "\1\u013b",
            "\1\u013c",
            "\1\u013d",
            "\1\u013e",
            "\1\u013f",
            "\1\u0140",
            "\1\u0141",
            "\1\u0142",
            "\1\u0143",
            "\1\u0144",
            "\1\u0145",
            "\1\u0146",
            "\1\u0147",
            "\1\u0148",
            "\1\u0149",
            "\1\u014a",
            "\1\u014b",
            "\1\u014c",
            "\1\u014d",
            "",
            "\1\u014e",
            "\1\u014f",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0152",
            "\1\u0153",
            "\1\u0154",
            "\1\u0155",
            "\1\u0156",
            "\1\u0157",
            "\1\u0158",
            "\1\u0159",
            "\1\u015a",
            "\1\u015b",
            "\1\u015c",
            "\1\u015d",
            "\1\u015e",
            "\1\u015f",
            "\1\u0160",
            "\1\u0161",
            "\1\u0162",
            "\1\u0163",
            "\1\u0164",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0166",
            "\1\u0167",
            "",
            "",
            "\1\u0168",
            "\1\u0169",
            "\1\u016a",
            "\1\u016b",
            "\1\u016c",
            "\1\u016d",
            "\1\u016e",
            "\1\u016f",
            "\1\u0170",
            "\1\u0171",
            "\1\u0172",
            "\1\u0173",
            "\1\u0174",
            "\1\u0175",
            "\1\u0176",
            "\1\u0177",
            "\1\u0178",
            "\1\u0179",
            "\1\u017a",
            "",
            "",
            "",
            "\1\u017b",
            "\1\u017c",
            "\1\u017d",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u017f",
            "\1\u0180",
            "\1\u0181",
            "\1\u0182",
            "\1\u0183",
            "\1\u0184",
            "\1\u0185",
            "\1\u0186",
            "\1\u0187",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0189",
            "\1\u018a",
            "\1\u018b",
            "\1\u018c",
            "\1\u018d",
            "\1\u018e",
            "\1\u018f",
            "\1\u0190",
            "",
            "\1\u0191",
            "\1\u0192",
            "\1\u0193",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0195",
            "\1\u0196",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0198",
            "\1\u0199",
            "",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u019b",
            "\1\u019c",
            "\1\u019d",
            "\1\u019e",
            "\1\u019f",
            "\1\u01a0",
            "\1\u01a1",
            "\1\u01a2",
            "\1\u01a3",
            "\1\u01a4",
            "",
            "\1\u01a5",
            "\1\u01a6",
            "",
            "\1\u01a7",
            "\1\u01a8",
            "",
            "\1\u01a9",
            "\1\u01aa",
            "\1\u01ab",
            "\1\u01ac",
            "\1\u01ad",
            "\1\u01ae",
            "\1\u01af",
            "\1\u01b0",
            "\1\u01b1",
            "\1\u01b2",
            "\1\u01b3",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u01b5",
            "\1\u01b6",
            "\1\u01b7",
            "\1\u01b8",
            "\1\u01b9",
            "\1\u01ba",
            "\1\u01bb",
            "\1\u01bc",
            "\1\u01bd",
            "\1\u01be",
            "\1\u01bf",
            "\1\u01c0",
            "\1\u01c1",
            "",
            "\1\u01c2",
            "\1\u01c3",
            "\1\u01c4",
            "\1\u01c5",
            "\1\u01c6",
            "\1\u01c7",
            "\1\u01c8",
            "\1\u01c9",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u01cb",
            "\1\u01cc",
            "\1\u01cd",
            "\1\u01ce",
            "\1\u01cf",
            "\1\u01d0",
            "\1\u01d1",
            "\1\u01d2",
            "\1\u01d3",
            "\1\u01d4",
            "\1\u01d5",
            "\1\u01d6",
            "",
            "\1\u01d7",
            "\1\u01d8",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u01da",
            "\1\u01db",
            "\1\u01dc",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u01de",
            "\1\u01df",
            "\1\u01e0",
            "\1\u01e1",
            "\1\u01e2",
            "\1\u01e3",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "",
            "\1\u01e5",
            "\1\u01e6",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "",
            "\1\u01e8",
            "\1\u01e9",
            "\1\u01ea",
            "\1\u01eb",
            "\1\u01ec",
            "\1\u01ed",
            "",
            "\1\u01ee",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "",
            "\1\u01f0",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u01f2",
            "\1\u01f3",
            "\1\u01f4",
            "\1\u01f5",
            "\1\u01f6",
            "",
            "\1\u01f7",
            "",
            "\1\u01f8",
            "\1\u01f9",
            "\1\u01fa",
            "\1\u01fb",
            "\1\u01fc",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u01fe",
            "\1\u01ff",
            "\1\u0200",
            "\1\u0201",
            "\1\u0202",
            "",
            "\1\u0203",
            "\1\u0204",
            "\1\u0205",
            "\1\u0206",
            "\1\u0207",
            "\1\u0208",
            "\1\u0209",
            "\1\u020a",
            "\1\u020b",
            "\1\u020c",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u020e",
            "\1\u020f",
            "\1\u0210",
            "\1\u0211",
            "",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0214",
            "\1\u0215",
            "",
            "",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            "\1\u0217",
            "",
            "\1\u0218",
            "\1\u0219",
            "\12\45\7\uffff\32\45\4\uffff\1\45\1\uffff\32\45",
            ""
    };

    static final short[] DFA12_eot = DFA.unpackEncodedString(DFA12_eotS);
    static final short[] DFA12_eof = DFA.unpackEncodedString(DFA12_eofS);
    static final char[] DFA12_min = DFA.unpackEncodedStringToUnsignedChars(DFA12_minS);
    static final char[] DFA12_max = DFA.unpackEncodedStringToUnsignedChars(DFA12_maxS);
    static final short[] DFA12_accept = DFA.unpackEncodedString(DFA12_acceptS);
    static final short[] DFA12_special = DFA.unpackEncodedString(DFA12_specialS);
    static final short[][] DFA12_transition;

    static {
        int numStates = DFA12_transitionS.length;
        DFA12_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA12_transition[i] = DFA.unpackEncodedString(DFA12_transitionS[i]);
        }
    }

    class DFA12 extends DFA {

        public DFA12(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 12;
            this.eot = DFA12_eot;
            this.eof = DFA12_eof;
            this.min = DFA12_min;
            this.max = DFA12_max;
            this.accept = DFA12_accept;
            this.special = DFA12_special;
            this.transition = DFA12_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__11 | T__12 | T__13 | T__14 | T__15 | T__16 | T__17 | T__18 | T__19 | T__20 | T__21 | T__22 | T__23 | T__24 | T__25 | T__26 | T__27 | T__28 | T__29 | T__30 | T__31 | T__32 | T__33 | T__34 | T__35 | T__36 | T__37 | T__38 | T__39 | T__40 | T__41 | T__42 | T__43 | T__44 | T__45 | T__46 | T__47 | T__48 | T__49 | T__50 | T__51 | T__52 | T__53 | T__54 | T__55 | T__56 | T__57 | T__58 | RULE_ID | RULE_INT | RULE_STRING | RULE_ML_COMMENT | RULE_SL_COMMENT | RULE_WS | RULE_ANY_OTHER );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            IntStream input = _input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA12_0 = input.LA(1);

                        s = -1;
                        if ( (LA12_0=='L') ) {s = 1;}

                        else if ( (LA12_0=='C') ) {s = 2;}

                        else if ( (LA12_0=='N') ) {s = 3;}

                        else if ( (LA12_0=='D') ) {s = 4;}

                        else if ( (LA12_0=='E') ) {s = 5;}

                        else if ( (LA12_0=='G') ) {s = 6;}

                        else if ( (LA12_0=='S') ) {s = 7;}

                        else if ( (LA12_0=='U') ) {s = 8;}

                        else if ( (LA12_0=='A') ) {s = 9;}

                        else if ( (LA12_0=='m') ) {s = 10;}

                        else if ( (LA12_0=='f') ) {s = 11;}

                        else if ( (LA12_0=='i') ) {s = 12;}

                        else if ( (LA12_0=='s') ) {s = 13;}

                        else if ( (LA12_0=='l') ) {s = 14;}

                        else if ( (LA12_0=='u') ) {s = 15;}

                        else if ( (LA12_0=='o') ) {s = 16;}

                        else if ( (LA12_0=='P') ) {s = 17;}

                        else if ( (LA12_0=='{') ) {s = 18;}

                        else if ( (LA12_0=='}') ) {s = 19;}

                        else if ( (LA12_0=='n') ) {s = 20;}

                        else if ( (LA12_0=='c') ) {s = 21;}

                        else if ( (LA12_0=='M') ) {s = 22;}

                        else if ( (LA12_0=='(') ) {s = 23;}

                        else if ( (LA12_0==')') ) {s = 24;}

                        else if ( (LA12_0==',') ) {s = 25;}

                        else if ( (LA12_0=='v') ) {s = 26;}

                        else if ( (LA12_0=='/') ) {s = 27;}

                        else if ( (LA12_0=='^') ) {s = 28;}

                        else if ( (LA12_0=='B'||LA12_0=='F'||(LA12_0>='H' && LA12_0<='K')||LA12_0=='O'||(LA12_0>='Q' && LA12_0<='R')||LA12_0=='T'||(LA12_0>='V' && LA12_0<='Z')||LA12_0=='_'||(LA12_0>='a' && LA12_0<='b')||(LA12_0>='d' && LA12_0<='e')||(LA12_0>='g' && LA12_0<='h')||(LA12_0>='j' && LA12_0<='k')||(LA12_0>='p' && LA12_0<='r')||LA12_0=='t'||(LA12_0>='w' && LA12_0<='z')) ) {s = 29;}

                        else if ( ((LA12_0>='0' && LA12_0<='9')) ) {s = 30;}

                        else if ( (LA12_0=='\"') ) {s = 31;}

                        else if ( (LA12_0=='\'') ) {s = 32;}

                        else if ( ((LA12_0>='\t' && LA12_0<='\n')||LA12_0=='\r'||LA12_0==' ') ) {s = 33;}

                        else if ( ((LA12_0>='\u0000' && LA12_0<='\b')||(LA12_0>='\u000B' && LA12_0<='\f')||(LA12_0>='\u000E' && LA12_0<='\u001F')||LA12_0=='!'||(LA12_0>='#' && LA12_0<='&')||(LA12_0>='*' && LA12_0<='+')||(LA12_0>='-' && LA12_0<='.')||(LA12_0>=':' && LA12_0<='@')||(LA12_0>='[' && LA12_0<=']')||LA12_0=='`'||LA12_0=='|'||(LA12_0>='~' && LA12_0<='\uFFFF')) ) {s = 34;}

                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA12_31 = input.LA(1);

                        s = -1;
                        if ( ((LA12_31>='\u0000' && LA12_31<='\uFFFF')) ) {s = 80;}

                        else s = 34;

                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA12_32 = input.LA(1);

                        s = -1;
                        if ( ((LA12_32>='\u0000' && LA12_32<='\uFFFF')) ) {s = 80;}

                        else s = 34;

                        if ( s>=0 ) return s;
                        break;
            }
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 12, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

}