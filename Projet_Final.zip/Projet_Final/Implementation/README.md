# Guide

Le but de ce guide est est de montrer les différentes parties de notre projet ou d'assister quelqu'un à créer le même projet a partir de zéro. Le projet a été effectué sous Eclipse IDE for Java and DSL Developers-2023-09.
Pour exécuter et tester le projet, on commence par créer un projet xtext. On va voir étape par étape les différentes parties du projet.

## Grammaire
Ceci est la grammaire de notre DSL sous xtext. On l’exécute pour ensuite implémenter le modèle dans la section suivante. De preference, on applique *.smell comme extension des modèles (ou comme vous le souhaiteriez). La grammaire se trouve dans dans le chemin du projet: 
```bash
.\Projet_Final\Implementation\org.xtext.example.antipattern\src\org\xtext\example\antipattern\Antipattern.xtext
```
Le fichier Ecore du projet également:
```bash
.\Projet_Final\Implementation\org.xtext.example.antipattern\model\generated\AntiPattern.ecore
```
la voici également ci-bas:  
```java
grammar org.xtext.example.antipattern.AntiPattern with org.eclipse.xtext.common.Terminals

generate antiPattern "http://www.xtext.org/example/antipattern/AntiPattern"
import "http://www.eclipse.org/xtext/xbase/Xbase" as xbase


Model:
    prompts+=Prompt*;

Prompt:
    'Prompt' 
    '{'
        content=ContentPrompt
    '}';
    
ContentPrompt:
    nbexemble=Exemples
    domain= Domain
    classe = Classes
    method= ChosenMethod
;
Exemples:
    "nbExemples:" 
    nbExemples= INT
;
Domain:
    'Domain:' 
    DomainName= ID
;
Classes:
    'Classes:' 
        nbClass=INT
        _class+= _Class*
;
_Class:
    'class:'
     ClassName=ID 
;
ChosenMethod:
    'Method_In' class=_Class
    "conditions:" "{"conditions+=Condition*"}"
    
    ; 
    
Condition:
     link=Link? '(' rules+=RuleType ( ',' rules+=RuleType)* ')'?;

Link:
    op=('UNION');    

RuleType:
    IntraCharacteristic | InterCarachteristic  ; 

IntraCharacteristic:
    metric= Metric comparator=Comparator value=INT  ('manners' '(' quantity+=Qunatity m+=Manner (',' quantity+=Qunatity m+=Manner)* ')')? | 'violates' '(' convention+=Convention (',' convention+=Convention)* ')' ;
     
Metric:
    MAXMetric | MINMetric 
;
MAXMetric:
    metric_val=("LOC" | "CYC" |"NOP"|"DEPTHNESTING")
    ;
MINMetric:
    metric_val=("COH")
;
Comparator:
    comp=("EQUAL" | "LESS" | "LESS_EQUAL" | "GREATER" | "GREATER_EQUAL")
;

Convention:
    c=('NAMING_CONVENTION'| 'Consistent_Parameter_Naming' | 'Single_Responsibility_Principle' | 'Use_of_Comments' |'Avoid_Magic_Numbers')
;

Qunatity:
    q=("many"|"few")
;
Manner: 
    manner= ("Complex_Logical_Expressions" | "ifNestedStructures" | "switchNestedStructures" 
        | "loopNestedStructures" |"ExecutableStatments"|"Declare_Variables_Separately"|"Add_Comments"|"Exception_Handling"|"Use_Recursion"|"Use_Global_Variables"|"unrelatedFonctionnalities"
    )
;

InterCarachteristic:
    e="ATTRIBUTE_USE" '(' p+=Param (',' p+=Param)* ')'comparator=Comparator value=NUMERIC_VALUE
;
  
Param:
    p=("method"|"otherClass"|"ownClass")
;
NUMERIC_VALUE :
   INT '/' INT   // Fractional value like 1/3
  | INT          // Integer value
  ;
```
## Les modèles du DSL
Donc, voici aussi le modèle qui est une instance du DSL et dont l'extension est *.smell .
```java
 Prompt { 
     nbExemples: 5
     Domain: Ecommerce
     Classes: 1 class: order 
     Method_In class: order conditions: {
          UNION (LOC GREATER 20 manners (many ExecutableStatments , many unrelatedFonctionnalities)
              ,CYC GREATER 3 manners ( many loopNestedStructures , many ifNestedStructures)
              )          
     }
}

 Prompt { 
     nbExemples: 5
     Domain: Finance
     Classes: 2 class: Account class: Transaction 
     Method_In class: Transaction conditions: {
          UNION (ATTRIBUTE_USE (method,otherClass)GREATER 5
          , ATTRIBUTE_USE ( method , ownClass )  LESS 1/3
              )
     }
} 

 Prompt { 
    nbExemples: 10
    Domain: Travel
    Classes: 1
    class: Passenger
    Method_In  class: Passenger
    conditions: {
         ( violates ( NAMING_CONVENTION) )
    }
    
}
```
## Convertir les modèles en format xmi
On convertit le fichier contenant les modèles en format *.xmi grâce à ce code java, dans le même package que les fichiers de la transformation:
```java
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;

public class Helper {
    public static void saveResourceAsXmi(Resource resource) {
        try {
            Map<String, String> saveOptions = new HashMap<String, String>();
            Resource xmlResource = new XMIResourceImpl(URI.createURI(resource.getURI().toString().replace("smell", "xmi")));
            xmlResource.getContents().add(resource.getContents().get(0));
            saveOptions.put(org.eclipse.emf.ecore.xmi.XMLResource.OPTION_ENCODING,"UTF-8");
            xmlResource.save(saveOptions);
            System.out.println("XMI file created.");
        } catch (IOException e) {
            System.out.println("Error during the creation of XMI.");
        e.printStackTrace();
        }
    }
}
```
Voici le chemein du fichier dans le projet:
```bash
.\Projet_Final\Implementation\org.xtext.example.antipattern\src\org\xtext\example\antipattern\generator\Helper.java
```
Le fichier xmi dans le projet et le fichier output de la transformation:
```bash
.\Projet_Final\Implementation\org.xtext.example.antipattern\smells.xmi
```
```bash
.\Projet_Final\Implementation\org.xtext.example.antipattern\smell.text
```

Apres la conversion en xmi, on copie ce dernier (qui serait dans le meme dossier que le modèle) dans le projet et on crée dans le même dossier un fichier *.text pour le output de la transformation.
## Transformation
On a utilisé xtend pour la transformation du modèle des smells en prompt qui est un langage naturel, voici le code ci-bas:
```java
/*
 * generated by Xtext 2.32.0
 */
package org.xtext.example.antipattern.generator

import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.generator.AbstractGenerator
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext
import java.io.FileWriter
import org.eclipse.emf.ecore.resource.ResourceSet
import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl
import org.eclipse.emf.common.util.URI
import org.xtext.example.antipattern.antiPattern.AntiPatternPackage
import org.xtext.example.antipattern.antiPattern.Model
import org.xtext.example.antipattern.antiPattern.Metric
import org.xtext.example.antipattern.antiPattern.Condition
import org.xtext.example.antipattern.antiPattern.ContentPrompt
import org.xtext.example.antipattern.antiPattern.Classes
import org.xtext.example.antipattern.antiPattern._Class
import org.xtext.example.antipattern.antiPattern.IntraCharacteristic
import org.xtext.example.antipattern.antiPattern.InterCarachteristic
import java.util.ArrayList
import org.xtext.example.antipattern.antiPattern.RuleType

/**
 * Generates code from your model files on save.
 * 
 * See https://www.eclipse.org/Xtext/documentation/303_runtime_concepts.html#code-generation
 */
class AntiPatternGenerator extends AbstractGenerator {

	override void doGenerate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
//		fsa.generateFile('greetings.txt', 'People to greet: ' + 
//			resource.allContents
//				.filter(Greeting)
//				.map[name]
//				.join(', '))

		Helper.saveResourceAsXmi(resource)
	}
	
	def static void main(String[] args) {

        val output = new AntiPatternGenerator()

        output.doEMFSetup("smell.text")

    }
    
    ResourceSet resourceSet 
	Resource resource
	EPackage myPackage
	Resource myResource
	

	def doEMFSetup(String out){

		val resourceSet = new ResourceSetImpl();

        resourceSet.resourceFactoryRegistry.extensionToFactoryMap.put("xmi", new XMIResourceFactoryImpl());

        EPackage.Registry.INSTANCE.put(AntiPatternPackage.eINSTANCE.nsURI, AntiPatternPackage.eINSTANCE);

        val uri = URI.createURI("smells.xmi");

        val resource = resourceSet.getResource(uri, true);

        val smell = resource.contents.get(0) as Model;

        val parsedSmellFile = help(smell).toString();

        printLatex(out, parsedSmellFile);

	}



	def help(Model model){
			 var nbExemples = 0
			 var domainName = ''
			 var nbClass = 0
			 var class_name = new ArrayList<String>()
			 var operator = ''
			 var metric_val = new ArrayList<String>()
			 var comparator = new ArrayList<String>()
			 var value = new ArrayList<String>()
			 var quantity = new ArrayList<String>()
			 var manner = new ArrayList<String>()
			 var convention = new ArrayList<String>()
			 var inter_charac = ''
			 var parameter = new ArrayList<String>()
			 var rule = -1
			 
			for (prompts : model.prompts){
				val content = prompts.content as ContentPrompt
				nbExemples = content.nbexemble.nbExemples
				domainName = content.domain.domainName 
				nbClass = content.classe.nbClass
				for (_class : content.classe._class){ 
					class_name.add(_class.className) 
				}
				for (cond : content.method.conditions){
					if (cond.link !== null)
					{
						cond.link.op="simultaneously"
						operator = cond.link.op
					} 
					for (rules : cond.rules){
						if (rules instanceof IntraCharacteristic){
							// we use rule=0 for intraCharacteristic template with 'manners'
							rule = 0
							val intra = rules as IntraCharacteristic
							if (intra.metric !== null)
							{
                   				switch intra.metric.metric_val {
  									case 'LOC' : intra.metric.metric_val="number of lines"
  									case 'CYC' : intra.metric.metric_val="cyclomatic complexity"
  									case 'NOP' : intra.metric.metric_val="number of parameters"
  									case 'DEPTHNESTING' : intra.metric.metric_val="depth nesting"
  									case 'COH' : intra.metric.metric_val="cohesion"
								}
								metric_val.add(intra.metric.metric_val)
							}
							if (intra.comparator !== null)
							{
                   				switch intra.comparator.comp {
  									case 'EQUAL' : intra.comparator.comp="equal to"
  									case 'LESS' : intra.comparator.comp="less than"
  									case 'LESS_EQUAL' : intra.comparator.comp="less equal to"
  									case 'GREATER' : intra.comparator.comp="greater than"
  									case 'GREATER_EQUAL' : intra.comparator.comp="greater equal"
								}
								comparator.add(intra.comparator.comp)
							}
							value.add(intra.value.toString)
							for (qte : intra.quantity){
								quantity.add(qte.q)
							}
							for (man : intra.m){
								switch man.manner {
  									case 'Complex_Logical_Expressions' : man.manner="complex logical expression"
  									case 'ifNestedStructures' : man.manner="if nested structures"
  									case 'switchNestedStructures' : man.manner="switch nested structures"
  									case 'loopNestedStructures' : man.manner="loop nested structures"
  									case 'ExecutableStatments' : man.manner="executables statements"
  									case 'Declare_Variables_Separately' : man.manner="declare variables separately"
  									case 'Add_Comments' : man.manner="add comments"
  									case 'Exception_Handling' : man.manner="exception handling"
  									case 'Use_Recursion' : man.manner="use recursion"
  									case 'Use_Global_Variables' : man.manner="use global variables"
  									case 'unrelatedFonctionnalities' : man.manner="unrelated functionalities"
								}
								manner.add(man.manner)
							}
							
							//if this condition is true, it means that we use 'violates' alternative in the IntraCharacteristic
							if (intra.metric == null && intra.comparator == null){
								// we use rule=2 for intraCharacteristic template with 'violates'
								rule = 2
								for (conv : intra.convention){
									switch conv.c {
  										case 'NAMING_CONVENTION' : conv.c="naming convention"
  										case 'Consistent_Parameter_Naming' : conv.c="consistent parameter naming"
  										case 'Single_Responsibility_Principle' : conv.c="single responsibility principle"
  										case 'Use_of_Comments' : conv.c="use of comments"
  										case 'Avoid_Magic_Numbers' : conv.c="avoid magic numbers"
									}
									convention.add(conv.c)
								}	
							}
						}
						
						if (rules instanceof InterCarachteristic){
							// we use rule=1 for interCharacteristic template
							rule = 1
							val inter = rules as InterCarachteristic
							inter_charac = inter.e
							for (param : inter.p){
								switch param.p {
  									case 'method' : param.p="method"
  									case 'otherClass' : param.p="other class"
  									case 'ownClass' : param.p="own class"
								}
								parameter.add(param.p)
							}
							if (inter.comparator !== null)
							{
                   				switch inter.comparator.comp {
  									case 'EQUAL' : inter.comparator.comp="equal to"
  									case 'LESS' : inter.comparator.comp="less than"
  									case 'GREATER' : inter.comparator.comp="more than"
								}
								comparator.add(inter.comparator.comp)
							}
							value.add(inter.value.toString)
						}
					}
				}
				
			}
			'''	
			«IF rule == 0»
				Generate «nbExemples» different java code exemples composed of  «nbClass» class(es) «class_name.get(0)», «class_name.get(1)» for an «domainName» system. 
				A method in the «class_name.get(0)» class should «operator» meets the following criteria:
				-the «metric_val.get(0)» of the method should be «comparator.get(0)» «value.get(0)». Try to use «quantity.get(0)» «manner.get(0)», «quantity.get(1)» «manner.get(1)».
				- the  «metric_val.get(1)» of the method should be «comparator.get(1)» «value.get(1)». Try to use  use «quantity.get(2)» «manner.get(2)», «quantity.get(3)» «manner.get(3)».
				Feel free to add any additional features or logic to make the method more comprehensive.				
			«ENDIF»	
			«IF rule == 2»
				Generate «nbExemples» different java code «domainName» exemples composed of «nbClass» class(es) «class_name.get(0)». 
				A method in the «class_name.get(0)» class should «operator» meets the following criteria:
				-the method should violate the «convention.get(0)». 
				Feel free to add any additional features or logic to make the method more comprehensive
			«ENDIF»	
			«IF rule == 1»
				Generate «nbExemples» different java code «domainName» exemples composed of  «nbClass» class(es) «class_name.get(0)», «class_name.get(1)».
				 A method in the «class_name.get(0)» class should  «operator» meets the following criteria:
				-the method should use «comparator.get(0)» «value.get(0)» attributes from the other class 
				-the method should use «comparator.get(1)» «value.get(1)» attributes of its own class
				Feel free to add any additional features or logic to make the method more comprehensive
			«ENDIF»	
			'''

	}

	def printLatex(String path, String content){

        try (val writer = new FileWriter(path)) {

            writer.write(content)

        } catch (Exception e) {

             e.printStackTrace()

        }

    }
}
```
Voici le chemein du fichier dans le projet:
```bash
.\Projet_Final\Implementation\org.xtext.example.antipattern\src\org\xtext\example\antipattern\generator\AntiPatternGenerator.xtend
```
Ensuite,on exécute ce fichier de la transformation pour avoir le résultat, voir le output dans le ficher *.text qu'on a crée précédemment.


MERCI !!!!!!!!!!!!!! :)

```
